public class Product
{
    private String name, brand, description;
    private int unitPrice, discount;

    /**
     * Constructor for objects of class Product
     */
    public Product()
    {

    }

    
}
