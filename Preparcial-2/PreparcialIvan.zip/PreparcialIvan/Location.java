public class Location
{
    private String city, neighborhood;
    /**
     * Constructor for objects of class Location
     */
    public Location(String city, String neighborhood) throws ECITroniksException
    {
        if (city == null || neighborhood == null){
            throw new ECITroniksException(ECITroniksException.CITY_AND_NEIGHBORHOOD_REQUIRED);
        }
        this.city = city;
        this.neighborhood = neighborhood;
        
    }
}
