import java.time.LocalDate;

public class MobileStore extends Store
{
    // instance variables - replace the example below with your own
    private int transferRate;
    private LocalDate lastTransferDate; 

    /**
     * Constructor for objects of class MobileStore
     */
    public MobileStore()
    {

    }
    
    @Override
    public LocalDate calculateTransferDate(){
        LocalDate medTransferDate = lastTransferDate.plusDays(transferRate);
        return medTransferDate;
    }
}
