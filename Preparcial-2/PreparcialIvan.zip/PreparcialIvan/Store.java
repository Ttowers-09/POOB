import java.util.HashMap;
import java.util.ArrayList;
import java.time.LocalDate;

public class Store
{
    private String name, address, atentionSchedule;
    
    HashMap<String, Product> products;
    ArrayList <Supplier> suppliers;
    Location Location;
    
    public Store()
    {
    }
    
    public Product getProduct(String name) throws ECITroniksException{
        Product p = products.get(name);
        if (p != null){
            return p;
        }else{
           throw new ECITroniksException (ECITroniksException. PRODUCT_NOT_FOUND);
        }
    }
    
    public LocalDate calculateTransferDate() throws ECITroniksException{
        return null;
    }
    
    public void moveLocation(String city, String neighborhood) throws ECITroniksException{
        Location = new Location (city, neighborhood);
    }
}
