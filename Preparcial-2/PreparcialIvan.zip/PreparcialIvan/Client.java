public class Client
{
    private Integer id;
    private String name, address, cellphone, email;


    /**
     * Constructor for objects of class Client
     */
    public Client()
    {
    }

}
