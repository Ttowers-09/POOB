public class ECITroniksException extends Exception
{
    public static final String CITY_AND_NEIGHBORHOOD_REQUIRED = "The city or neighborhood are invalid";
    public static final String NOT_ALLOWED_TRANSFER = "The transfer rate for the store has not been met yet or if no store could be transferred";
    public static final String PRODUCT_NOT_FOUND = "There is no product with that name";
    /**
     * Constructor for objects of class ECITroniksException
     */
    public ECITroniksException(String message){
        super(message);
    }

}
