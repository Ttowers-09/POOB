import java.util.ArrayList;
import java.util.HashSet;

public class SpecializedStore extends Store {
    private Location location;
    private ArrayList<String> employees;
    private HashSet<Client> exclusiveClients;

    public SpecializedStore(Location location, ArrayList<String> employees, HashSet<Client> exclusiveClients) {
        this.location = location;
        this.employees = employees;
        this.exclusiveClients = exclusiveClients;
    }

    public Location getLocation() { return location; }
    public ArrayList<String> getEmployees() { return employees; }
    public HashSet<Client> getExclusiveClients() { return exclusiveClients; }
}
