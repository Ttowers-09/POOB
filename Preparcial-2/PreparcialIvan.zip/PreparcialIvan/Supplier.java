import java.util.HashMap;

public class Supplier
{
    // instance variables - replace the example below with your own
    private String name;
    private int contactNumber;
    
    HashMap <String, Product> products;
    /**
     * Constructor for objects of class Supplier
     */
    public Supplier()
    {
    }
}
