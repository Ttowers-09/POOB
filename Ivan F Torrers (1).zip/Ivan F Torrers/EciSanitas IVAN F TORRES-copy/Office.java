public class Office {
    private int number;
    private int type;
    
    public Office(int number, int type){
        this.type = type;
        this.number = number;
    }
    
    public int getType(){
        return number;
    }
}
