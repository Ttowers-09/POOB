import java.time.LocalDate;
import java.util.ArrayList;

public class MedicalHistory {
	private LocalDate startDate;
	private Patient patient;
	private ArrayList<PatientIllness> patientIllnesses;
}
