public class Treatment {
    private String name;
    private String description;
    private String duration;
    
    //CONSTRUCTOR
    public Treatment(String name,String description,String duration){
        this.name = name;
        this.description = description;
        this.duration = duration;
    }
    
}
