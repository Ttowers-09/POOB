import java.util.Collection;
import java.util.TreeMap;

public class ECISanitas {
    
    private TreeMap <String, Patient> patients;
    private TreeMap <String, Hospital> hospitals;
    private TreeMap <String, Illness> illness;

    /**
     * This method add  treatments for an illness in all hospitals that have a certain capacity  
     * for a certain type of office.
     * 
     * @param capacity: minimum offices that the hospital to get the new treatment;
     * @param type:  type of office that hospital must have;
     * @param illness: name of the illness the treatment cures;
     * @param name: treatment name;
     * @param description: treatment description
     */   
    public void addTreatmentsToHospitalsWithCapacityType (
        int capacity, 
        int type, 
        String illness,
        String name,
        String description){
            
            Illness i = new Illness();
            i.getillness();
            
            if (i != null){
                Treatment t = new Treatment(name, description);
                
                for (String h : hospitals.keySet()){
                    int officesAmount= hospitals.get(h).getOfficesAmountByType();
                    
                    if (officesAmount >= capacity){
                        hospitals.addTreatment(t);
                    }
                }
                
                Illness.addTreatment(t);
            }
    }
}
