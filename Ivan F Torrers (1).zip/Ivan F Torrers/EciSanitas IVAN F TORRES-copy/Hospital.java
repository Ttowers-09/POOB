import java.util.ArrayList;

public class Hospital {
    private String name;
    private String address;
    private ArrayList<Office> offices;
    private ArrayList<Doctor> doctors;
    private Location location;
    private ArrayList<Treatment> treatments;
    
    public int getOfficesAmountByType(){
        for(Office o: offices){
            return o.getType();
        }
    }
    
    public void addTreatment(){
        
    }
}
