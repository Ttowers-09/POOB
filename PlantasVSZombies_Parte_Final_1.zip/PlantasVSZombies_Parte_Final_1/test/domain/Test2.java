package domain;

import org.junit.Before;
import org.junit.Test;

import javax.swing.*;
import java.util.Arrays;
import java.util.List;

import static org.junit.Assert.*;

public class Test2 {

    private Tablero tablero;
    private JTextField sunsScore;

    @Before
    public void setUp() {
        // Inicialización de los datos de prueba
        List<String> plantasSeleccionadas = Arrays.asList("Peashooter", "Nut", "ECIPlant", "Mine", "SunFlower");
        List<String> zombiesSeleccionados = Arrays.asList("NormalZombie", "ConoZombie", "CubeZombie", "ECIZombie");
        // Inicialización del tablero con los parámetros adecuados
        tablero = new Tablero("Dia", "PlayerVSMachine", plantasSeleccionadas, zombiesSeleccionados, 100, 3000, 5);
        sunsScore = new JTextField();
    }

    @Test
public void testAddZombiePlayerInValidPosition() {
    Zombie zombie = new NormalZombie(tablero);

    // Aseguramos que haya suficientes cerebros para colocar el zombie
    System.out.println("Cerebros antes de intentar añadir el zombie: " + tablero.getCerebros());  // Verifica los cerebros disponibles
    System.out.println("Costo del zombie: " + zombie.getCost());

    // Intentamos colocar el zombie en una posición inválida (columna 7)
    tablero.addZombiePlayer(0, 7, zombie);

    // Verifica si el zombie no fue colocado en la posición (0, 7)
    Zombie placedZombie = tablero.getZombiePosition(0, 7);
    assertNull("El zombie debería no haber sido añadido en (0, 7)", placedZombie);

    // Verifica que la cantidad de cerebros no haya cambiado
    System.out.println("Cerebros después de intentar añadir el zombie: " + tablero.getCerebros());
    assertEquals("La cantidad de cerebros no debería haber cambiado", 3000, tablero.getCerebros());
}

    @Test
public void testAddZombiePlayerInValidPosition2() {
    Zombie zombie = new ConoZombie(tablero);

    // Aseguramos que haya suficientes cerebros para colocar el zombie
    System.out.println("Cerebros antes de intentar añadir el zombie: " + tablero.getCerebros());  // Verifica los cerebros disponibles
    System.out.println("Costo del zombie: " + zombie.getCost());

    // Intentamos colocar el zombie en una posición inválida (columna 7)
    tablero.addZombiePlayer(0, 7, zombie);

    // Verifica si el zombie no fue colocado en la posición (0, 7)
    Zombie placedZombie = tablero.getZombiePosition(0, 7);
    assertNull("El zombie debería no haber sido añadido en (0, 7)", placedZombie);

    // Verifica que la cantidad de cerebros no haya cambiado
    System.out.println("Cerebros después de intentar añadir el zombie: " + tablero.getCerebros());
    assertEquals("La cantidad de cerebros no debería haber cambiado", 3000, tablero.getCerebros());
}

@Test
public void testAddZombiePlayerValidPosition1() {
    Zombie zombie = new ConoZombie(tablero);

    // Aseguramos que haya suficientes cerebros para colocar el zombie
    System.out.println("Cerebros antes de añadir el zombie: " + tablero.getCerebros());  // Verifica los cerebros disponibles
    System.out.println("Costo del zombie: " + zombie.getCost());

    // Colocar un zombie en una posición válida (columna 9, fila 2)
    tablero.addZombiePlayer(2, 9, zombie);

    // Verifica si el zombie se coloca en la posición correcta
    Zombie placedZombie = tablero.getZombiePosition(2, 9);
    assertNotNull("El zombie no fue añadido correctamente en (2, 9)", placedZombie);
    assertEquals("El zombie colocado no es el esperado", zombie, placedZombie);

    // Verifica que la cantidad de cerebros haya sido reducida correctamente
    System.out.println("Cerebros después de añadir el zombie: " + tablero.getCerebros());
}

@Test
public void testAddZombiePlayerValidPosition2() {
    Zombie zombie = new NormalZombie(tablero);

    // Aseguramos que haya suficientes cerebros para colocar el zombie
    System.out.println("Cerebros antes de añadir el zombie: " + tablero.getCerebros());  // Verifica los cerebros disponibles
    System.out.println("Costo del zombie: " + zombie.getCost());

    // Colocar un zombie en una posición válida (columna 9, fila 2)
    tablero.addZombiePlayer(3, 9, zombie);

    // Verifica si el zombie se coloca en la posición correcta
    Zombie placedZombie = tablero.getZombiePosition(3, 9);
    assertNotNull("El zombie no fue añadido correctamente en (3, 9)", placedZombie);
    assertEquals("El zombie colocado no es el esperado", zombie, placedZombie);

    // Verifica que la cantidad de cerebros haya sido reducida correctamente
    System.out.println("Cerebros después de añadir el zombie: " + tablero.getCerebros());
}

@Test
public void testAddZombiePlayerValidPosition3() {
    Zombie zombie = new CubeZombie(tablero);

    // Aseguramos que haya suficientes cerebros para colocar el zombie
    System.out.println("Cerebros antes de añadir el zombie: " + tablero.getCerebros());  // Verifica los cerebros disponibles
    System.out.println("Costo del zombie: " + zombie.getCost());

    // Colocar un zombie en una posición válida (columna 9, fila 2)
    tablero.addZombiePlayer(3, 9, zombie);

    // Verifica si el zombie se coloca en la posición correcta
    Zombie placedZombie = tablero.getZombiePosition(3, 9);
    assertNotNull("El zombie no fue añadido correctamente en (3, 9)", placedZombie);
    assertEquals("El zombie colocado no es el esperado", zombie, placedZombie);

    // Verifica que la cantidad de cerebros haya sido reducida correctamente
    System.out.println("Cerebros después de añadir el zombie: " + tablero.getCerebros());
}

@Test
public void testAddZombiePlayerValidPosition4() {
    Zombie zombie = new ECIZombie(tablero);

    // Aseguramos que haya suficientes cerebros para colocar el zombie
    System.out.println("Cerebros antes de añadir el zombie: " + tablero.getCerebros());  // Verifica los cerebros disponibles
    System.out.println("Costo del zombie: " + zombie.getCost());

    // Colocar un zombie en una posición válida (columna 9, fila 2)
    tablero.addZombiePlayer(3, 9, zombie);

    // Verifica si el zombie se coloca en la posición correcta
    Zombie placedZombie = tablero.getZombiePosition(3, 9);
    assertNotNull("El zombie no fue añadido correctamente en (3, 9)", placedZombie);
    assertEquals("El zombie colocado no es el esperado", zombie, placedZombie);

    // Verifica que la cantidad de cerebros haya sido reducida correctamente
    System.out.println("Cerebros después de añadir el zombie: " + tablero.getCerebros());
}


    @Test
public void testAddZombiePlayerInValidPosition3() {
    Zombie zombie = new CubeZombie(tablero);

    // Aseguramos que haya suficientes cerebros para colocar el zombie
    System.out.println("Cerebros antes de intentar añadir el zombie: " + tablero.getCerebros());  // Verifica los cerebros disponibles
    System.out.println("Costo del zombie: " + zombie.getCost());

    tablero.addZombiePlayer(2, 7, zombie);


    Zombie placedZombie = tablero.getZombiePosition(2, 7);
    assertNull("El zombie debería no haber sido añadido en (2, 7)", placedZombie);

    // Verifica que la cantidad de cerebros no haya cambiado
    System.out.println("Cerebros después de intentar añadir el zombie: " + tablero.getCerebros());
    assertEquals("La cantidad de cerebros no debería haber cambiado", 3000, tablero.getCerebros());
}

    @Test
public void testAddZombiePlayerInValidPosition4() {
    Zombie zombie = new ECIZombie(tablero);

    // Aseguramos que haya suficientes cerebros para colocar el zombie
    System.out.println("Cerebros antes de intentar añadir el zombie: " + tablero.getCerebros());  // Verifica los cerebros disponibles
    System.out.println("Costo del zombie: " + zombie.getCost());

    tablero.addZombiePlayer(2, 7, zombie);


    Zombie placedZombie = tablero.getZombiePosition(2, 7);
    assertNull("El zombie debería no haber sido añadido en (2, 7)", placedZombie);

    // Verifica que la cantidad de cerebros no haya cambiado
    System.out.println("Cerebros después de intentar añadir el zombie: " + tablero.getCerebros());
    assertEquals("La cantidad de cerebros no debería haber cambiado", 3000, tablero.getCerebros());
}
}
