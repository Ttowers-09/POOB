package domain;

import org.junit.Before;
import org.junit.Test;

import javax.swing.*;
import java.util.Arrays;
import java.util.List;

import static org.junit.Assert.*;

public class TableroTest {

    private Tablero tablero;
    private JTextField sunsScore;
        

    @Before
    public void setUp() {
        List<String> plantasSeleccionadas = Arrays.asList("Peashooter", "Nut", "ECIPlant", "Mine", "SunFlower");
        List<String> zombiesSeleccionados = Arrays.asList("NormalZombie", "ConoZombie", "CubeZombie", "ECIZombie");
        tablero = new Tablero("Dia", "PlayerVSMachine", plantasSeleccionadas, zombiesSeleccionados, 100000, 3, 5);
        sunsScore = new JTextField();
    }

    @Test
    public void testAddPlantInInvalidPosition() {
        Planta planta = new Girasol(tablero, sunsScore);

        // Probar añadir planta en posición (0, 0)
        try {
            tablero.addPlant(0, 0, planta);
            fail("Se esperaba una excepción al intentar añadir una planta en la posición inválida (0, 0)");
        } catch (IllegalArgumentException e) {
            assertEquals("Posición fuera de los límites permitidos: (0, 0)", e.getMessage());
        }

        // Probar añadir planta en posición (0, 9)
        try {
            tablero.addPlant(0, 9, planta);
            fail("Se esperaba una excepción al intentar añadir una planta en la posición inválida (0, 9)");
        } catch (IllegalArgumentException e) {
            assertEquals("Posición fuera de los límites permitidos: (0, 9)", e.getMessage());
        }
    }

    @Test
    public void testAddPlantValidPosition() {
        Planta planta = new Girasol(tablero, sunsScore);

        // Intentar añadir planta en una posición válida (0, 1), no debería lanzar excepción
        try {
            tablero.addPlant(0, 1, planta);
        } catch (IllegalArgumentException e) {
            fail("No se esperaba una excepción al intentar añadir una planta en la posición válida (0, 1): " + e.getMessage());
        }

        // Verificar que la planta fue añadida correctamente en la posición (0, 1)
        assertNotNull("La planta no fue añadida correctamente en (0, 1)", tablero.getPlantPositon(0, 1));
    }
    
    @Test
    public void testAddPlantValidPosition2() {
        Planta planta = new Girasol(tablero, sunsScore);
                // Intentar añadir planta en una posición válida (1, 1), no debería lanzar excepción
        try {
            tablero.addPlant(1, 1, planta);
        } catch (IllegalArgumentException e) {
            fail("No se esperaba una excepción al intentar añadir una planta en la posición válida (1, 1): " + e.getMessage());
        }

        // Verificar que la planta fue añadida correctamente en la posición (1, 1)
        assertNotNull("La planta no fue añadida correctamente en (1, 1)", tablero.getPlantPositon(1, 1));

    }

    @Test
    public void testAddPlantValidPosition3(){
         Planta planta = new Girasol(tablero, sunsScore);
        // Verificar si podemos añadir una planta en la posición (2, 1)
        try {
            tablero.addPlant(2, 1, planta);
        } catch (IllegalArgumentException e) {
            fail("No se esperaba una excepción al intentar añadir una planta en la posición válida (2, 1): " + e.getMessage());
        }

        // Verificar que la planta fue añadida correctamente en la posición (2, 1)
        assertNotNull("La planta no fue añadida correctamente en (2, 1)", tablero.getPlantPositon(2, 1));
    }
    
    @Test
    public void testAddPlantValidPosition4(){
         Planta planta = new Papapum(tablero);
        // Verificar si podemos añadir una planta en la posición (2, 1)
        try {
            tablero.addPlant(2, 1, planta);
        } catch (IllegalArgumentException e) {
            fail("No se esperaba una excepción al intentar añadir una planta en la posición válida (2, 1): " + e.getMessage());
        }

        // Verificar que la planta fue añadida correctamente en la posición (2, 1)
        assertNotNull("La planta no fue añadida correctamente en (2, 1)", tablero.getPlantPositon(2, 1));
    }
    
    @Test
    public void testAddPlantValidPosition5(){
         Planta planta = new ECIPlant(tablero, sunsScore);
        // Verificar si podemos añadir una planta en la posición (2, 1)
        try {
            tablero.addPlant(2, 1, planta);
        } catch (IllegalArgumentException e) {
            fail("No se esperaba una excepción al intentar añadir una planta en la posición válida (2, 1): " + e.getMessage());
        }

        // Verificar que la planta fue añadida correctamente en la posición (2, 1)
        assertNotNull("La planta no fue añadida correctamente en (2, 1)", tablero.getPlantPositon(2, 1));
    }
    
        @Test
    public void testAddPlantValidPosition6(){
         Planta planta = new Nuez(tablero);
        // Verificar si podemos añadir una planta en la posición (2, 1)
        try {
            tablero.addPlant(2, 1, planta);
        } catch (IllegalArgumentException e) {
            fail("No se esperaba una excepción al intentar añadir una planta en la posición válida (2, 1): " + e.getMessage());
        }

        // Verificar que la planta fue añadida correctamente en la posición (2, 1)
        assertNotNull("La planta no fue añadida correctamente en (2, 1)", tablero.getPlantPositon(2, 1));
    }
    
            @Test
    public void testAddPlantValidPosition7(){
         Planta planta = new LanzaGuisantes(tablero);
        // Verificar si podemos añadir una planta en la posición (2, 1)
        try {
            tablero.addPlant(2, 1, planta);
        } catch (IllegalArgumentException e) {
            fail("No se esperaba una excepción al intentar añadir una planta en la posición válida (2, 1): " + e.getMessage());
        }

        // Verificar que la planta fue añadida correctamente en la posición (2, 1)
        assertNotNull("La planta no fue añadida correctamente en (2, 1)", tablero.getPlantPositon(2, 1));
    }
    
        @Test
    public void testAddPlantInInvalidPosition2() {
        Planta planta = new ECIPlant(tablero, sunsScore);

        // Probar añadir planta en posición (0, 0)
        try {
            tablero.addPlant(0, 0, planta);
            fail("Se esperaba una excepción al intentar añadir una planta en la posición inválida (0, 0)");
        } catch (IllegalArgumentException e) {
            assertEquals("Posición fuera de los límites permitidos: (0, 0)", e.getMessage());
        }

        // Probar añadir planta en posición (0, 9)
        try {
            tablero.addPlant(0, 9, planta);
            fail("Se esperaba una excepción al intentar añadir una planta en la posición inválida (0, 9)");
        } catch (IllegalArgumentException e) {
            assertEquals("Posición fuera de los límites permitidos: (0, 9)", e.getMessage());
        }
    }
    
            @Test
    public void testAddPlantInInvalidPosition3() {
        Planta planta = new Nuez(tablero);

        // Probar añadir planta en posición (0, 0)
        try {
            tablero.addPlant(0, 0, planta);
            fail("Se esperaba una excepción al intentar añadir una planta en la posición inválida (0, 0)");
        } catch (IllegalArgumentException e) {
            assertEquals("Posición fuera de los límites permitidos: (0, 0)", e.getMessage());
        }

        // Probar añadir planta en posición (0, 9)
        try {
            tablero.addPlant(0, 9, planta);
            fail("Se esperaba una excepción al intentar añadir una planta en la posición inválida (0, 9)");
        } catch (IllegalArgumentException e) {
            assertEquals("Posición fuera de los límites permitidos: (0, 9)", e.getMessage());
        }
    }
            @Test
    public void testAddPlantInInvalidPosition4() {
        Planta planta = new LanzaGuisantes(tablero);

        // Probar añadir planta en posición (0, 0)
        try {
            tablero.addPlant(0, 0, planta);
            fail("Se esperaba una excepción al intentar añadir una planta en la posición inválida (0, 0)");
        } catch (IllegalArgumentException e) {
            assertEquals("Posición fuera de los límites permitidos: (0, 0)", e.getMessage());
        }

        // Probar añadir planta en posición (0, 9)
        try {
            tablero.addPlant(0, 9, planta);
            fail("Se esperaba una excepción al intentar añadir una planta en la posición inválida (0, 9)");
        } catch (IllegalArgumentException e) {
            assertEquals("Posición fuera de los límites permitidos: (0, 9)", e.getMessage());
        }
    }

            @Test
    public void testAddPlantInInvalidPosition6() {
        Planta planta = new Papapum(tablero);

        // Probar añadir planta en posición (0, 0)
        try {
            tablero.addPlant(0, 0, planta);
            fail("Se esperaba una excepción al intentar añadir una planta en la posición inválida (0, 0)");
        } catch (IllegalArgumentException e) {
            assertEquals("Posición fuera de los límites permitidos: (0, 0)", e.getMessage());
        }

        // Probar añadir planta en posición (0, 9)
        try {
            tablero.addPlant(0, 9, planta);
            fail("Se esperaba una excepción al intentar añadir una planta en la posición inválida (0, 9)");
        } catch (IllegalArgumentException e) {
            assertEquals("Posición fuera de los límites permitidos: (0, 9)", e.getMessage());
        }
    }
    
    @Test
    public void testRemovePlantaAt() {
        Planta planta = new Papapum(tablero);
        tablero.addPlant(0, 2, planta);
        tablero.removePlantAt(0, 2);
        assertNull(tablero.getPlantPositon(0, 2));
    }
    
    @Test
    public void testRemovePlantaAt2() {
        Planta planta = new LanzaGuisantes(tablero);
        tablero.addPlant(0, 2, planta);
        tablero.removePlantAt(0, 2);
        assertNull(tablero.getPlantPositon(0, 2));
    }
    
    @Test
    public void testRemovePlantaAt3() {
        Planta planta = new Nuez(tablero);
        tablero.addPlant(0, 2, planta);
        tablero.removePlantAt(0, 2);
        assertNull(tablero.getPlantPositon(0, 2));
    }
    
    @Test
    public void testRemovePlantaAt4() {
        Planta planta = new ECIPlant(tablero, sunsScore);
        tablero.addPlant(0, 2, planta);
        tablero.removePlantAt(0, 2);
        assertNull(tablero.getPlantPositon(0, 2));
    }
    
    @Test
    public void testRemovePlantaAt5() {
        Planta planta = new Girasol(tablero, sunsScore);
        tablero.addPlant(0, 2, planta);
        tablero.removePlantAt(0, 2);
        assertNull(tablero.getPlantPositon(0, 2));
    }
}
