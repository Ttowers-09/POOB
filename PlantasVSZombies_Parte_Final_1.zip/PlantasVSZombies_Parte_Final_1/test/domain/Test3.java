package domain;

import org.junit.Before;
import org.junit.Test;

import javax.swing.*;
import java.util.Arrays;
import java.util.List;

import static org.junit.Assert.*;

public class Test3 {

    private Tablero tablero;
    private JTextField sunsScore;
    private JTextField cerebrosScore;

    @Before
    public void setUp() {
        // Inicialización de los datos de prueba
        List<String> plantasSeleccionadas = Arrays.asList("Peashooter", "Nut", "ECIPlant", "Mine", "SunFlower");
        List<String> zombiesSeleccionados = Arrays.asList("NormalZombie", "ConoZombie", "CubeZombie", "ECIZombie");
        // Inicialización del tablero con los parámetros adecuados (0 soles y 0 cerebros)
        tablero = new Tablero("Dia", "PlayerVSMachine", plantasSeleccionadas, zombiesSeleccionados, 0, 0, 5);
        sunsScore = new JTextField();
    }
    
    @Test
    public void testAddPlantValidPositionNotSuns() {
        Planta planta = new Girasol(tablero, sunsScore);

        // Intentar añadir una planta en la posición (2, 1) cuando no hay soles
        try {
            tablero.addPlant(2, 1, planta);
            fail("Se esperaba una excepción al intentar añadir una planta sin suficientes soles");
        } catch (IllegalArgumentException e) {
            assertEquals("No hay suficientes soles para colocar la planta", e.getMessage());
        }

        // Verificar que la planta no fue añadida en la posición (2, 1)
        assertNull("La planta no debería haber sido añadida en (2, 1)", tablero.getPlantPositon(2, 1));
    }
@Test
    public void testAddPlantValidPositionNotSuns2() {
        Planta planta = new ECIPlant(tablero, sunsScore);

        // Intentar añadir una planta en la posición (2, 1) cuando no hay soles
        try {
            tablero.addPlant(2, 1, planta);
            fail("Se esperaba una excepción al intentar añadir una planta sin suficientes soles");
        } catch (IllegalArgumentException e) {
            assertEquals("No hay suficientes soles para colocar la planta", e.getMessage());
        }

        // Verificar que la planta no fue añadida en la posición (2, 1)
        assertNull("La planta no debería haber sido añadida en (2, 1)", tablero.getPlantPositon(2, 1));
    }
    
@Test
    public void testAddPlantValidPositionNotSuns3() {
        Planta planta = new LanzaGuisantes(tablero);

        // Intentar añadir una planta en la posición (2, 1) cuando no hay soles
        try {
            tablero.addPlant(2, 1, planta);
            fail("Se esperaba una excepción al intentar añadir una planta sin suficientes soles");
        } catch (IllegalArgumentException e) {
            assertEquals("No hay suficientes soles para colocar la planta", e.getMessage());
        }

        // Verificar que la planta no fue añadida en la posición (2, 1)
        assertNull("La planta no debería haber sido añadida en (2, 1)", tablero.getPlantPositon(2, 1));
    }

@Test
    public void testAddPlantValidPositionNotSuns4() {
        Planta planta = new Nuez(tablero);

        // Intentar añadir una planta en la posición (2, 1) cuando no hay soles
        try {
            tablero.addPlant(2, 1, planta);
            fail("Se esperaba una excepción al intentar añadir una planta sin suficientes soles");
        } catch (IllegalArgumentException e) {
            assertEquals("No hay suficientes soles para colocar la planta", e.getMessage());
        }

        // Verificar que la planta no fue añadida en la posición (2, 1)
        assertNull("La planta no debería haber sido añadida en (2, 1)", tablero.getPlantPositon(2, 1));
    }

    

@Test
    public void testAddPlantValidPositionNotSuns5() {
        Planta planta = new Papapum(tablero);

        // Intentar añadir una planta en la posición (2, 1) cuando no hay soles
        try {
            tablero.addPlant(2, 1, planta);
            fail("Se esperaba una excepción al intentar añadir una planta sin suficientes soles");
        } catch (IllegalArgumentException e) {
            assertEquals("No hay suficientes soles para colocar la planta", e.getMessage());
        }

        // Verificar que la planta no fue añadida en la posición (2, 1)
        assertNull("La planta no debería haber sido añadida en (2, 1)", tablero.getPlantPositon(2, 1));
    }
    
@Test
public void testAddZombiePlayerValidPositionNotCerebros() {
    Zombie zombie = new NormalZombie(tablero);

    // Intentar añadir un zombie en la posición (2, 9) cuando no hay cerebros
    try {
        tablero.addZombiePlayer(2, 9, zombie);
        fail("Se esperaba una excepción al intentar añadir un zombie sin suficientes cerebros");
    } catch (IllegalArgumentException e) {
        // Cambiar el mensaje esperado para coincidir con el que se lanza
        assertEquals("No hay suficientes puntos de cerebro para colocar este zombie", e.getMessage());
    }

    // Verificar que el zombie no fue añadido en la posición (2, 9)
    assertNull("El zombie no debería haber sido añadido en (2, 9)", tablero.getZombiePosition(2, 9));
}

@Test
public void testAddZombiePlayerValidPositionNotCerebros2() {
    Zombie zombie = new ConoZombie(tablero);

    // Intentar añadir un zombie en la posición (2, 9) cuando no hay cerebros
    try {
        tablero.addZombiePlayer(2, 9, zombie);
        fail("Se esperaba una excepción al intentar añadir un zombie sin suficientes cerebros");
    } catch (IllegalArgumentException e) {
        // Cambiar el mensaje esperado para coincidir con el que se lanza
        assertEquals("No hay suficientes puntos de cerebro para colocar este zombie", e.getMessage());
    }

    // Verificar que el zombie no fue añadido en la posición (2, 9)
    assertNull("El zombie no debería haber sido añadido en (2, 9)", tablero.getZombiePosition(2, 9));
}

@Test
public void testAddZombiePlayerValidPositionNotCerebros3() {
    Zombie zombie = new CubeZombie(tablero);

    // Intentar añadir un zombie en la posición (2, 9) cuando no hay cerebros
    try {
        tablero.addZombiePlayer(2, 9, zombie);
        fail("Se esperaba una excepción al intentar añadir un zombie sin suficientes cerebros");
    } catch (IllegalArgumentException e) {
        // Cambiar el mensaje esperado para coincidir con el que se lanza
        assertEquals("No hay suficientes puntos de cerebro para colocar este zombie", e.getMessage());
    }

    // Verificar que el zombie no fue añadido en la posición (2, 9)
    assertNull("El zombie no debería haber sido añadido en (2, 9)", tablero.getZombiePosition(2, 9));
}

@Test
public void testAddZombiePlayerValidPositionNotCerebros4() {
    Zombie zombie = new BrainsteinZombie(tablero, cerebrosScore);

    // Intentar añadir un zombie en la posición (2, 9) cuando no hay cerebros
    try {
        tablero.addZombiePlayer(2, 9, zombie);
        fail("Se esperaba una excepción al intentar añadir un zombie sin suficientes cerebros");
    } catch (IllegalArgumentException e) {
        // Cambiar el mensaje esperado para coincidir con el que se lanza
        assertEquals("No hay suficientes puntos de cerebro para colocar este zombie", e.getMessage());
    }

    // Verificar que el zombie no fue añadido en la posición (2, 9)
    assertNull("El zombie no debería haber sido añadido en (2, 9)", tablero.getZombiePosition(2, 9));
}

@Test
public void testAddSun() {
    int initialSun = tablero.getSun();  // Obtiene la cantidad inicial de soles
    tablero.addSun(50);  // Añade 50 soles
    assertEquals(initialSun + 50, tablero.getSun());  // Verifica si la cantidad de soles aumentó en 50
}

    @Test
public void testAddCerebros() {
        int initialCerebros = tablero.getCerebros();
        tablero.addCerebros(5);
        assertEquals(initialCerebros + 5, tablero.getCerebros());
    }
}
