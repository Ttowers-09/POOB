package domain;

import java.io.Serializable;

public class Game implements Serializable {
    private String nombre;

    public Game(String nombre) {
        this.nombre = nombre;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
}