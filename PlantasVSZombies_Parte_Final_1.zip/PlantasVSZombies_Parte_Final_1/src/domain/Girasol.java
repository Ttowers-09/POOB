/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package domain;
import java.util.ArrayList;
import java.awt.Image;
import java.awt.Toolkit;
import java.io.Serializable;
import javax.swing.*;

/**
 *
 * @author LENOVO
 */
public class Girasol extends Planta implements Serializable{
    private int fila;
    private int columna;
    private Image image;
    private int sunProduction = 25;
    private Tablero tablero;
    private Timer production;
    private int tiempo = 20000;
    private JTextField SunsScore;
    
    public Girasol(Tablero tablero, JTextField SunsScore){
        super("Girasol",300,50,20,0,false,"imagenes/SunFlower.gif");
        this.fila = fila;
        this.columna = columna;
        this.tablero = tablero; 
        this.SunsScore = SunsScore;
        
       
    }
  
    public void generateSun(){
        tablero.addSun(sunProduction);  // Aumenta los soles en el tablero
        System.out.println("Generando " + sunProduction + " soles.");
        updateSunsScore();
    }
    
    private void updateSunsScore() {
        SwingUtilities.invokeLater(() -> SunsScore.setText("Soles: " + tablero.getSun()));
    }
    
    
    // Obtener la fila del Girasol
    public int getFila() {
        return fila;
    }
    
    // Obtener la columna del Girasol
    public int getColumna() {
        return columna;
    }
     @Override
    public void realizarAccion() {
         if (production == null) {
        production = new Timer(tiempo, e -> {
            generateSun();
            updateSunsScore();
        });
        production.start();
        System.out.println("Producción de soles iniciada para el Girasol.");
    }
    }
    
    

@Override
     public void stopAction(){
          if (production != null) {
        production.stop();
        production = null; 
        System.out.println("Producción de soles detenida para el Girasol.");
    }
     }
   
    @Override
    public String getImagePath() {
        return "/imagenes/SunFlower1.gif"; // Ruta relativa de la imagen
    }
}
