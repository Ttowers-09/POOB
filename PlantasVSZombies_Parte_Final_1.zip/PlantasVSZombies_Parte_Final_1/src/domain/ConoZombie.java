/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package domain;
import java.awt.Image;
import java.awt.Toolkit;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import javax.swing.Timer;
import java.io.Serializable;
/**
 *
 * @author LENOVO
 */
public class ConoZombie extends Zombie implements Serializable {
    
    private int fila;
    private int columna;
    private Image image;
    private Tablero tablero;
    private Timer movement;
    private int tiempo = 5000;


    
    
    public ConoZombie(Tablero tablero){
        super("ConoZombie",380,150,0.5,100,true,"images/ConeheadZombie.gif");
        this.tablero = tablero; 

       
    }
    
    // Obtener la fila del Girasol
    public int getFila() {
        return fila;
    }

    // Obtener la columna del Girasol
    public int getColumna() {
        return columna;
    }
    
    @Override
    public String getImagePath() {
        return "/imagenes/ConeheadZombie.gif"; // Ruta relativa de la imagen
    } @Override
    public void actionZombie(){
        
    }
    
    @Override
    public void moveZombie() {
        if (movement == null) {
        movement = new Timer(tiempo, e -> {
              if (tablero.posicionvalidaZombies(x, y - 1)) {
                    if (tablero.getPlantPositon(x, y - 1) == null) {
                        tablero.removeZombieAt(x, y); // Remueve el zombie de la posición actual
                        y--; // Mueve el zombie hacia la izquierda
                        tablero.addZombie(x, y, this); // Actualiza el tablero con la nueva posición
                    }
            }
        });
        movement.start();
    }
    
}
@Override
    public void stopMovement(){
        movement.stop();
        movement = null;
    }
}
