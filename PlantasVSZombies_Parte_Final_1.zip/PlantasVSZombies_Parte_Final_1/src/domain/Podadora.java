/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package domain;
import java.io.Serializable;

/**
 *
 * @author LENOVO
 */
public class Podadora implements Serializable {
     private int fila;
    private Tablero tablero;

    public Podadora(int fila, Tablero tablero) {
        this.fila = fila;
        this.tablero = tablero;
    }

    public void activar() {
           System.out.println("¡Podadora activada en la fila " + fila + "!");
    for (int j = 0; j < tablero.ANCHO; j++) {
        Zombie zombie = tablero.getZombiePosition(fila, j);
        if (zombie != null) {
            zombie.stopMovement(); // Detenemos el movimiento del zombie
            tablero.removeZombieAt(fila, j); // Eliminamos el zombie del tablero
        }
    }
    tablero.imprimirTableroCompleto();
    }

}
