package domain;



import presentation.*;

import java.util.*;
import java.io.*;




public class Tablero implements Serializable{
    public final int LARGO = 5;
    public final int ANCHO = 10;
    private String modoSeleccionado;
    private String modoJugadores;
    public List<String> selectedPlants;
    private List<String> selectedZombies;
    public int cantidadDeSoles;
    private int cantidadDeCerebros;
    private int tiempo;
    
    public Planta[][] plantas;
    public  Zombie[][] zombies;
    private Podadora[] podadoras;
    

    
    List <String> NombreDeZombies = new ArrayList<>();





    
    public Tablero (String modoSeleccionado, String modoJugadores, List<String> selectedPlants, List<String> selectedZombies, int cantidadDeSoles, int cantidadDeCerebros,int tiempo){
        this.modoSeleccionado = modoSeleccionado;
        this.modoJugadores = modoJugadores;
        this.selectedPlants = selectedPlants;
        this.selectedZombies = selectedZombies;
        this.cantidadDeCerebros = cantidadDeCerebros;
        this.tiempo = tiempo * 60;
        this.cantidadDeSoles = cantidadDeSoles;
        this.plantas = new Planta[LARGO][ANCHO];
        this.zombies = new Zombie[LARGO][ANCHO];
        this.podadoras = new Podadora[LARGO];
        for (int i = 0; i < LARGO; i++) {
        this.podadoras[i] = new Podadora(i, this); 
    }
        Random random = new Random();
        NombreDeZombies = selectedZombies;
           

        //Tableros Dia y jugabilidad
        if(modoSeleccionado.equals("Dia") && modoJugadores.equals("PlayerVSMachine")){
            TableroDiaPLVSMH tableroDia = new TableroDiaPLVSMH(this);
            tableroDia.setVisible(true);
        }
        
        if(modoSeleccionado.equals("Dia") && modoJugadores.equals("MachineVSMachine")){
            TableroDiaMHVSMH tableroDia = new TableroDiaMHVSMH(this);
            tableroDia.setVisible(true);
        }
        if(modoSeleccionado.equals("Dia") && modoJugadores.equals("PlayerVSPlayer")){
            TableroDiaPLVSPL tableroDia = new TableroDiaPLVSPL(this);
            tableroDia.setVisible(true);
        }
        
        
        //Tableros noche y jugabilidad
        if(modoSeleccionado.equals("Noche") && modoJugadores.equals("PlayerVSMachine")){
            TableroNochePLVSMH tableroNoche = new TableroNochePLVSMH(this);
            tableroNoche.setVisible(true);
        }
        if(modoSeleccionado.equals("Noche") && modoJugadores.equals("MachineVSMachine")){
            TableroNocheMHVSMH tableroNoche = new TableroNocheMHVSMH(this);
            tableroNoche.setVisible(true);
        }
        if(modoSeleccionado.equals("Noche") && modoJugadores.equals("PlayerVSPlayer")){
            TableroNochePLVSPL tableroNoche = new TableroNochePLVSPL();
            tableroNoche.setVisible(true);
        }
}
    
    public boolean posicionValida(int largo, int ancho) {
        return largo >= 0 && largo < LARGO && ancho >= 0 && ancho < ANCHO;
    }
    
    public boolean posicionvalidaZombies(int largo, int ancho){
        return largo >= 0 && largo <= LARGO && ancho < ANCHO;
    }
    
    public void removeZombieAt(int row, int col) {
        if (posicionValida(row, col)) {
        Zombie zombie = zombies[row][col];
        if (zombie != null) {
            zombies[row][col] = null; // Removemos el zombie de la matriz
        }
    }
    } 

     public void addPlant(int x, int y, Planta pl) {
    if (posicionValida(x, y) && y >= 1 && y <= 8 && plantas[x][y] == null) {  // Delegamos la validación a posicionValida
        if (cantidadDeSoles >= pl.getCost()) {
            plantas[x][y] = pl;
            cantidadDeSoles -= pl.getCost();
            pl.realizarAccion();
            System.out.println("Plant added at position (" + x + ", " + y + ")");
            System.out.println("La cantidad de soles son: " + cantidadDeSoles);
            System.out.println(NombreDeZombies);
        } else {
            throw new IllegalArgumentException("No hay suficientes soles para colocar la planta");
        }
    } else {
        throw new IllegalArgumentException("Posición fuera de los límites permitidos: (" + x + ", " + y + ")");
    }
}
    
    public  void addZombie(int x, int y, Zombie zl ){
         if (posicionvalidaZombies(x, y)) {
        zombies[x][y] = zl;
        zl.setPosition(x, y);
        zl.actionZombie();
        zl.moveZombie();
        imprimirTableroCompleto();
        System.out.println("Zombie added at position (" + x + ", " + y + ")");
    } else {
        System.out.println("no zombie");
    }
    if (y == 0) { 
    if (podadoras[x] != null) { 
        podadoras[x].activar(); 
        podadoras[x] = null; 
    } else {
        detenerJuego(); 
    }
    return; 
    }
    }
public void addZombiePlayer(int x, int y, Zombie zl) {
    if (!posicionvalidaZombies(x, y)) {
        System.out.println("Posición no válida para colocar zombies.");
        return;
    }
    
    if (y != 9) {
        System.out.println("Los zombies solo pueden colocarse en la columna 9.");
        return;
    }
    
    if (cantidadDeCerebros < zl.getCost()) {
        System.out.println("No hay suficientes puntos de cerebro para colocar este zombie.");
        return;
    }

    // Si pasa todas las validaciones, se coloca el zombie
    zombies[x][y] = zl;
    cantidadDeCerebros -= zl.getCost();
    zl.setPosition(x,y);
    zl.actionZombie();
    zl.moveZombie();
    System.out.println("Zombie añadido en la posición (" + x + ", " + y + ").");
    System.out.println("La cantidad de cerebros restantes es: " + cantidadDeCerebros);
}
    
public String getRandomPlant(){
    if(!selectedPlants.isEmpty()){
        Random random2 = new Random();
        int randomPl = random2.nextInt(selectedPlants.size());
        return selectedPlants.get(randomPl);
    }
    if(selectedPlants.isEmpty()){
        selectedPlants.add("Peashooter");
        selectedPlants.add("Mine");
        selectedPlants.add("Nut");
        Random random2 = new Random();
        int randomIndex = random2.nextInt(selectedPlants.size());
        return selectedPlants.get(randomIndex);
    }
    return null;
}
    
    public String getRandomZombie() {
    if (!NombreDeZombies.isEmpty()) {
        Random random = new Random();
        int randomIndex = random.nextInt(NombreDeZombies.size());
        return NombreDeZombies.get(randomIndex);
    }
    if(NombreDeZombies.isEmpty()){
        NombreDeZombies.add("NormalZombie");
        NombreDeZombies.add("ConoZombie");
        NombreDeZombies.add("CubeZombie");
        Random random = new Random();
        int randomIndex = random.nextInt(NombreDeZombies.size());
        return NombreDeZombies.get(randomIndex);

    }
    return null; 
}

    public void removePlantAt(int row, int col) {
        if (posicionValida(row, col)) {
        Planta planta = plantas[row][col];
        if (planta != null) {
            planta.stopAction(); 
        }
        plantas[row][col] = null; 
        System.out.println("Planta eliminada de la posición (" + row + ", " + col + ")");
    }
    }
    
    public Planta getPlantPositon(int row, int col) {
        if (posicionValida(row, col)) {
            return plantas[row][col];
        }
        return null;
    }
    
    public Zombie getZombiePosition(int row, int col) {
        if (posicionValida(row, col)) {
            return zombies[row][col];
        }
        return null;
    }
    
    public int getSun() {
        return cantidadDeSoles;  
    }
    public void addSun(int points) {
        cantidadDeSoles += points;
    }
    
    public void addCerebros(int points){
        cantidadDeCerebros += points;
    }
    
    public int getCerebros(){
        return cantidadDeCerebros;
    }
    
    public void imprimirTablero() {
    for (int i = 0; i < plantas.length; i++) {
        for (int j = 0; j < plantas[i].length; j++) {
            if (plantas[i][j] != null) {
                System.out.print("[" + plantas[i][j].getName() + "] "); 
            } else if (zombies[i][j] != null) {
                System.out.print("[" + zombies[i][j].getName() + "] ");
            } else {
                System.out.print("[  ] "); 
            }
        }
        System.out.println(); 
    }
}


    public boolean isEmpty(int row, int col) {
        return posicionValida(row, col) && plantas[row][col] == null;
    }
   
      
    public void detenerJuego(){
        for (int i = 0; i < LARGO; i++) {
        for (int j = 0; j < ANCHO; j++) {
            if (zombies[i][j] != null) {
                zombies[i][j].stopMovement(); // Detenemos el movimiento de cada zombie
                zombies[i][j] = null; // Eliminamos el zombie
            }
        }
    }
    if (TableroDiaPLVSMH.timer != null) {
        TableroDiaPLVSMH.timer.stop();
        TableroDiaPLVSMH.timer = null;
    }
    if(TableroDiaMHVSMH.timer != null && TableroDiaMHVSMH.timer2!=null){
        TableroDiaMHVSMH.timer.stop();
        TableroDiaMHVSMH.timer = null;
        TableroDiaMHVSMH.timer2.stop();
        TableroDiaMHVSMH.timer2 = null;
    }
    System.out.println("Zombies ganan");
}
    
    public void imprimirTableroCompleto() {
    System.out.println("Tablero Completo:");

    for (int i = 0; i < LARGO; i++) {
        for (int j = 0; j < ANCHO; j++) {
            if (plantas[i][j] != null) {
                // Primera letra del nombre de la clase de la planta
                System.out.print("[" + plantas[i][j].getClass().getSimpleName().charAt(0) + "] ");
            } else if (zombies[i][j] != null) {
                // Primera letra del nombre de la clase del zombie
                System.out.print("[" + zombies[i][j].getClass().getSimpleName().charAt(0) + "] ");
            } else {
                System.out.print("[ ] "); // Espacio vacío
            }
        }

        // Imprimir la podadora correspondiente al final de la fila
        if (podadoras[i] != null) {
            System.out.print("Podadora: [P]"); // Representar podadora con "P"
        } else {
            System.out.print("Podadora: [ ]");
        }

        System.out.println(); // Nueva línea después de cada fila
    }
}

    public int disminuirTiempo(){
        while (tiempo > 0){
            return tiempo -= 1;
        }
        return 0;   
    }

}

