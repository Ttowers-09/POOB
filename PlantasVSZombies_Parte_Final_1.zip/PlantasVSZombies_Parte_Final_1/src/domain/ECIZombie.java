/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package domain;
import java.awt.Image;
import java.awt.Toolkit;
import java.io.Serializable;
import javax.swing.Timer;
/**
 *
 * @author ivans
 */
public class ECIZombie extends Zombie implements Serializable {
    private int fila;
    private int columna;
    private Image image;
    private Tablero tablero;
    private Timer movement;
    private int tiempo = 5000;

    
    
    public ECIZombie(Tablero tablero){
        super("ECIZombie",200,250,3.0,50,true,"images/FlagZombie.gif");
        this.fila = fila;
        this.columna = columna;
        this.tablero = tablero; 
    }
    
    // Obtener la fila del Girasol
    public int getFila() {
        return fila;
    }

    // Obtener la columna del Girasol
    public int getColumna() {
        return columna;
    }
    
    @Override
    public String getImagePath() {
        return "/imagenes/FlagZombie.gif"; // Ruta relativa de la imagen
    }
    @Override
    public void actionZombie(){
        
    }
    
    
    @Override
    public void moveZombie() {
        if (movement == null) {
        movement = new Timer(tiempo, e -> {
              if (tablero.posicionvalidaZombies(x, y - 1)) {
                    if (tablero.getPlantPositon(x, y - 1) == null) {
                        tablero.removeZombieAt(x, y); // Remueve el zombie de la posición actual
                        y--; // Mueve el zombie hacia la izquierda
                        tablero.addZombie(x, y, this); // Actualiza el tablero con la nueva posición
                    }}
        });
        movement.start();
    }
    
}
@Override
    public void stopMovement(){
        movement.stop();
        movement = null;
    }
}
