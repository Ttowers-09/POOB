/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package domain;
import java.awt.Image;
import java.awt.Toolkit;
import java.io.Serializable;
import javax.swing.Timer;
/**
 *
 * @author LENOVO
 */
public class NormalZombie extends Zombie implements Serializable{
   private int fila;
    private int columna;
    private Image image;
    private Tablero tablero;
    private Timer movement;
    private int tiempo = 5000;


    
    
    public NormalZombie(Tablero tablero){
        super("NormalZombie",100,100,0.5,100,true,"images/Zombie.gif");
        this.tablero = tablero; 
    }
    
    public int getFila() {
        return fila;
    }

    public int getColumna() {
        return columna;
    }
    
    @Override
    public String getImagePath() {
        return "/imagenes/Zombie.gif"; // Ruta relativa de la imagen
    }
    
     @Override
    public void actionZombie(){
        
    }
    
    @Override
    public void moveZombie() {
        System.out.println(x);
                System.out.println(y);

         if (movement == null) {
        movement = new Timer(tiempo, e -> {
              if (tablero.posicionvalidaZombies(x, y - 1)) {
                    if (tablero.getPlantPositon(x, y - 1) == null) {
                        tablero.removeZombieAt(x, y); // Remueve el zombie de la posición actual
                        y--; // Mueve el zombie hacia la izquierda
                        tablero.addZombie(x, y, this); // Actualiza el tablero con la nueva posición
                    }}
        });
        movement.start();
     }
    }
    @Override
    public void stopMovement(){
        movement.stop();
        movement = null;
    }
}