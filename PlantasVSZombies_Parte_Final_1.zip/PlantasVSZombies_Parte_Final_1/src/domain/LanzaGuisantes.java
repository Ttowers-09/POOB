/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package domain;
import java.awt.Image;
import java.awt.Toolkit;
import java.io.Serializable;
/**
 *
 * @author LENOVO
 */
public class LanzaGuisantes extends Planta implements Serializable{
    public LanzaGuisantes(Tablero tablero){
        super("Lanzaguisantes",300,100,1.5,20,true,"imagenes/Peashooter.gif");
    }
      @Override
    public void realizarAccion() {
       
}
    @Override
    public String getImagePath() {
        return "/imagenes/Peashooter.gif"; // Ruta relativa de la imagen
    }
    @Override
     public void stopAction(){
         
     }
}
