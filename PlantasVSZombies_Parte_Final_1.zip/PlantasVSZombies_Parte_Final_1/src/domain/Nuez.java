/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package domain;
import java.awt.Image;
import java.awt.Toolkit;
import java.io.Serializable;
/**
 *
 * @author LENOVO
 */
public class Nuez extends Planta implements Serializable{
    public Nuez(Tablero tablero){
        super("Nuez",4000,50,0,0,false,"imagenes/nut.gif");
    }
     @Override
    public void realizarAccion() {
    
    }
    @Override
    public String getImagePath() {
        return "/imagenes/nut.gif"; // Ruta relativa de la imagen
    }
    @Override
     public void stopAction(){
         
     }
}
