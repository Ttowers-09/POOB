/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package domain;
import java.awt.Image;
import java.awt.Toolkit;
import java.io.Serializable;
import javax.swing.Timer;
/**
 *
 * @author LENOVO
 */
public class Papapum  extends Planta implements Serializable{
    private boolean armada = false; 
    private Timer armar;
    private int tiempo = 15000;
    private Tablero tablero;

    
    public Papapum(Tablero tablero){
        super("Papapum",300,25,14,1000,true,"imagenes/PotatoMine.gif");
        this.tablero = tablero;
    }
     @Override
    public void realizarAccion() {
     if (armada == false && armar == null) { 
            armar = new Timer(tiempo, e -> {
                armada = true;
                System.out.println("Esta armada");
                detonar();
                armar.stop(); 
            });
            armar.start(); 
        }
    }

    
    private void detonar() {
        System.out.println("Boom");
}
    @Override
     public void stopAction(){
    
    
     }
    @Override
    public String getImagePath() {
        return "/imagenes/PotatoMine.gif"; // Ruta relativa de la imagen
    }
}
