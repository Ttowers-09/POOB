/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package domain;
import java.awt.Image;
import java.awt.Toolkit;
import java.io.Serializable;
/**
 *
 * @author LENOVO
 */
public abstract class Planta implements Serializable{
    public String name;
    public int health;
    public int cost;
    public double tiempoRecarga;
    public int damage;
    public boolean attack;
    public String imagen;

    
    public Planta(String name, int health, int cost, double tiempoRecarga, int damage, boolean attack, String rutaImagen) {
        this.name = name;
        this.damage = damage;
        this.cost = cost;
        this.tiempoRecarga = tiempoRecarga;
        this.damage = damage;
        this.attack = attack;
        this.imagen = rutaImagen;

    }

    public String getName(){
        return name;
    }
    public int getCost(){
        return cost;
    }
    
    public int getHealth(){
        return health;
    }
    public int getDamage() {
        return damage;
    }
    
    public double getTiempoRecarga() {
        return tiempoRecarga;
    }
    
    public boolean getAttack(){
        return attack;
    }
    
    public abstract String getImagePath(); // Método que deben implementar las subclases

    
    //Metodo para manejar la función de cada planta
    public abstract void realizarAccion();
    public abstract void stopAction();


}


