/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package domain;
import java.util.ArrayList;
import java.awt.Image;
import java.awt.Toolkit;
import java.io.Serializable;
import javax.swing.*;

/**
 *
 * @author ivans
 */
public class BrainsteinZombie extends Zombie implements Serializable{
    private int fila;
    private int columna;
    private Image image;
    private int cerebroProduction = 25;
    private Tablero tablero;
    private Timer production;
    private int tiempo = 20000;
    private JTextField cerebrosScore;
    private Timer movement;
    private int tiempoM = 5000;

    
    
    public BrainsteinZombie(Tablero tablero, JTextField cerebrosScore){
        super("BrainsteinZombie",300,50,20.0,0,false,"images/Brainstein Zombies.gif");
        this.fila = fila;
        this.columna = columna;
        this.tablero = tablero; 
        this.cerebrosScore = cerebrosScore;
        
        
    }
    public void generateCerebros(){
        tablero.addCerebros(cerebroProduction);  
        System.out.println("Generando " + cerebroProduction + " Cerebros.");
        updateCerebrosScore();
    }

    private void updateCerebrosScore() {
        SwingUtilities.invokeLater(() -> cerebrosScore.setText("Cerebros: " + tablero.getCerebros()));
    }
    
    // Obtener la fila del Girasol
    public int getFila() {
        return fila;
    }

    // Obtener la columna del Girasol
    public int getColumna() {
        return columna;
    }
    
    @Override
    public String getImagePath() {
        return "/imagenes/Brainstein Zombies.gif"; // Ruta relativa de la imagen
    }
     @Override
    public void actionZombie(){
         if (production == null) {
             production = new Timer(tiempo, e -> {
            generateCerebros();
            updateCerebrosScore();
        });
        production.start();
        System.out.println("Producción de soles iniciada para el Zombie Brainstein.");
    }
    }
    
    @Override
    public void moveZombie() {
        if (movement == null) {
        movement = new Timer(tiempo, e -> {
              if (tablero.posicionvalidaZombies(x, y - 1)) {
                    if (tablero.getPlantPositon(x, y - 1) == null) {
                        tablero.removeZombieAt(x, y); // Remueve el zombie de la posición actual
                        y--; // Mueve el zombie hacia la izquierda
                        tablero.addZombie(x, y, this); // Actualiza el tablero con la nueva posición
                    }
            }
        });
        movement.start();
    }
    
}
@Override
    public void stopMovement(){
        movement.stop();
        movement = null;
    }
}
