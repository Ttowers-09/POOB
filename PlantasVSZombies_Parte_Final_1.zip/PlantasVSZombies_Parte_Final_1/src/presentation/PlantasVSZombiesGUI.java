package presentation;

import javax.swing.*;
import java.awt.*;
import java.util.Timer;
import java.util.TimerTask;
import java.io.Serializable;

public class PlantasVSZombiesGUI implements Serializable{

    private JFrame frame;
    private JLabel imageLabel;

    public PlantasVSZombiesGUI() {
        // Inicializar los elementos de la ventana
        PrepareElements prepareElements = new PrepareElements();
        frame = prepareElements.createMainFrame();
        imageLabel = prepareElements.createImageLabel();
        frame.add(imageLabel, BorderLayout.CENTER);
        
        // Hacer visible la ventana antes de cargar imágenes
        frame.setVisible(true);
        
        // Mostrar la primera imagen
        SwingUtilities.invokeLater(() -> showImage("C:\\Users\\ivans\\OneDrive\\Escritorio\\PlantasVsZombies\\resources\\titleScreen.png"));
        
        // Usar un temporizador para cambiar la imagen después de 3 segundos
        Timer timer = new Timer();
        timer.schedule(new TimerTask() {
            @Override
            public void run() {
                // Cambiar a la segunda imagen
                SwingUtilities.invokeLater(() -> {
                    showMainMenu();
                    // Preparar el menú con el botón QUIT
                    PrepareElementsMenu prepareMenu = new PrepareElementsMenu();
                    prepareMenu.createQuitButton(frame);
                });
            }
        }, 3000); // 3000 ms = 3 segundos
    }

    private void showImage(String imagePath) {
        // Cargar la imagen desde la ruta
        ImageIcon icon = new ImageIcon(imagePath);
        // Obtener las dimensiones de la ventana
        int width = frame.getWidth();
        int height = frame.getHeight();
        
        // Redimensionar la imagen para que ocupe todo el espacio de la ventana
        Image image = icon.getImage().getScaledInstance(width, height, Image.SCALE_SMOOTH);
        
        // Actualizar el JLabel con la nueva imagen escalada
        imageLabel.setIcon(new ImageIcon(image));
        
        // Asegurarse de repintar la ventana después de actualizar la imagen
        frame.revalidate();
        frame.repaint();
    }

    private void showMainMenu() {
        // Cambiar la imagen a la del menú principal
        showImage("C:\\Users\\ivans\\OneDrive\\Escritorio\\PlantasVsZombies\\resources\\MainMenu.png");
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(PlantasVSZombiesGUI::new);
    }
}

// Clase para preparar los elementos de la ventana (tamaño, etiquetas)
class PrepareElements {

    public JFrame createMainFrame() {
        // Crear la ventana principal
        JFrame frame = new JFrame("POOB vs Zombies GUI");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setExtendedState(JFrame.MAXIMIZED_BOTH);  // Maximizar la ventana a pantalla completa
        frame.setLayout(null);  // Usamos null layout para poder posicionar los componentes libremente
        return frame;
    }

    public JLabel createImageLabel() {
        // Crear un JLabel para mostrar las imágenes
        JLabel imageLabel = new JLabel();
        imageLabel.setHorizontalAlignment(JLabel.CENTER);  // Centrar la imagen
        imageLabel.setBounds(0, 0, 100, 100);  // Necesitamos establecer un tamaño inicial para que el JLabel se ubique bien
        return imageLabel;
    }
}

// Clase para manejar las acciones del programa (como cerrar la ventana)
class PrepareActions {

    public void prepareQuitAction(JFrame frame) {
        // Crear el botón QUIT
        JButton quitButton = new JButton("QUIT");
        
        // Establecer un tamaño pequeño para el botón
        quitButton.setPreferredSize(new Dimension(100, 50));  // Tamaño pequeño: 100x50 píxeles
        
        // Hacer el fondo del botón transparente
        quitButton.setOpaque(false);
        quitButton.setContentAreaFilled(false);
        quitButton.setBorderPainted(false);

        // Asignar acción al botón QUIT
        quitButton.addActionListener(e -> System.exit(0));  // Cierra la aplicación al hacer clic
        
        // Crear un contenedor para manejar la ubicación del botón (sin layout)
        JPanel panel = new JPanel();
        panel.setLayout(null);  // Sin layout para colocar el botón donde queramos

        // Colocar el botón en cualquier parte de la ventana usando setBounds (x, y, width, height)
        quitButton.setBounds(50, 50, 100, 50);  // Aquí lo ubicamos en la posición (50, 50)
        
        // Agregar el botón al panel
        panel.add(quitButton);
        
        // Agregar el panel con el botón al frame
        frame.add(panel); // Se coloca donde lo hayamos definido
        
        // Actualizar el layout
        frame.revalidate();
        frame.repaint();
    }
}

// Clase para preparar los elementos del menú en la segunda pantalla (botones, etc.)
class PrepareElementsMenu {

    public void createQuitButton(JFrame frame) {
        // Crear un objeto PrepareActions para manejar las acciones
        PrepareActions prepareActions = new PrepareActions();
        prepareActions.prepareQuitAction(frame);
    }
}
