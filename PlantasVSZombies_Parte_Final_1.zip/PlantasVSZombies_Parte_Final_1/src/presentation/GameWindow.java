/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package presentation;

import java.io.Serializable;
import domain.Game;
import javax.swing.*;

/**
 *
 * @author ivans
 */
public class GameWindow extends javax.swing.JFrame implements Serializable{
    private Game game;

    public GameWindow(Game game) {
        this.game = game;
        initComponents();
    }

    private void initComponents() {
        setTitle("Juego Cargado");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(800, 600);
        setLocationRelativeTo(null);

        // Configurar elementos visuales según el estado del juego
        // Por ejemplo: mostrar personajes, plantas, zombies, etc.
        JLabel label = new JLabel("Juego cargado con éxito: " + game.getNombre());
        add(label);
    }
}

