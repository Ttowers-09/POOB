/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package presentation;

import domain.*;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.Timer;

/**
 *
 * @author ivans
 */
public class TableroDiaMHVSMH extends javax.swing.JFrame implements Serializable{
    private PlantsSelect plantsSelect;
    private Planta selectedPlant = null;
    private static Tablero tablero;
    private JButton selectedButton = null; // Para manejar el botón seleccionado
    public int solesTotal = 0;
    public boolean palaIsActive = false;
    public static Timer timer, timer2;
    
    private int tiempo = 10000;
    private int tiempo2 = 10000;
    
    private Map<String, ImageIcon> zombieImages = new HashMap<>();
    private Map<String, ImageIcon> plantImages = new HashMap<>();

    /**
     * Creates new form TableroDia
     */
    public TableroDiaMHVSMH(Tablero tablero) {
            this.tablero = tablero;
        initComponents();
        JButton[] botones = {button49, button09, button19, button29, button39};
        JButton[] botonesPlanta = {button01,button02,button03,button04,button05,button06,button07,button08,button11,button12,
        button13,button14,button15,button16,button17,button18,button21,button22,button23,button24,button25,button26,button27,button28,
        button31,button32,button33,button34,button35,button36,button37,button38,button41,button42,button43,button44,button45,button46,
        button47,button48};
        cargarImagenes();
        
        
        Random random = new Random();
        Random random2 = new Random();
        button49.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Acción que se ejecuta cuando se hace clic en el botón
                System.out.println("Botón 49 clickeado");
            }
        }); 
        button09.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Acción que se ejecuta cuando se hace clic en el botón
                System.out.println("Botón 09 clickeado");
            }
        }); 
        button01.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Acción que se ejecuta cuando se hace clic en el botón
                System.out.println("Botón 01 clickeado");
            }
        }); 
        button02.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Acción que se ejecuta cuando se hace clic en el botón
                System.out.println("Botón 02 clickeado");
            }
        }); 
        button03.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Acción que se ejecuta cuando se hace clic en el botón
                System.out.println("Botón 03 clickeado");
            }
        }); 
        button04.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Acción que se ejecuta cuando se hace clic en el botón
                System.out.println("Botón 04 clickeado");
            }
        }); 
        button05.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Acción que se ejecuta cuando se hace clic en el botón
                System.out.println("Botón 05 clickeado");
            }
        }); 
       
        button06.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Acción que se ejecuta cuando se hace clic en el botón
                System.out.println("Botón 06 clickeado");
            }
        }); 
        button07.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Acción que se ejecuta cuando se hace clic en el botón
                System.out.println("Botón 07 clickeado");
            }
        }); 
        button08.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Acción que se ejecuta cuando se hace clic en el botón
                System.out.println("Botón 08 clickeado");
            }
        }); 
        button11.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Acción que se ejecuta cuando se hace clic en el botón
                System.out.println("Botón 11 clickeado");
            }
        }); 
        button12.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Acción que se ejecuta cuando se hace clic en el botón
                System.out.println("Botón 12 clickeado");
            }
        }); 
        button13.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Acción que se ejecuta cuando se hace clic en el botón
                System.out.println("Botón 13 clickeado");
            }
        }); 
        button14.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Acción que se ejecuta cuando se hace clic en el botón
                System.out.println("Botón 14 clickeado");
            }
        }); 
        button15.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Acción que se ejecuta cuando se hace clic en el botón
                System.out.println("Botón 15 clickeado");
            }
        }); 
        button16.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Acción que se ejecuta cuando se hace clic en el botón
                System.out.println("Botón 16 clickeado");
            }
        }); 
        button17.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Acción que se ejecuta cuando se hace clic en el botón
                System.out.println("Botón 17 clickeado");
            }
        }); 
        button18.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Acción que se ejecuta cuando se hace clic en el botón
                System.out.println("Botón 18 clickeado");
            }
        }); 
        button21.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Acción que se ejecuta cuando se hace clic en el botón
                System.out.println("Botón 21 clickeado");
            }
        }); 
        button22.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Acción que se ejecuta cuando se hace clic en el botón
                System.out.println("Botón 22 clickeado");
            }
        }); 
        button23.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Acción que se ejecuta cuando se hace clic en el botón
                System.out.println("Botón 23 clickeado");
            }
        }); 
        button24.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Acción que se ejecuta cuando se hace clic en el botón
                System.out.println("Botón 24 clickeado");
            }
        }); 
        button25.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Acción que se ejecuta cuando se hace clic en el botón
                System.out.println("Botón 25 clickeado");
            }
        }); 
        button26.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Acción que se ejecuta cuando se hace clic en el botón
                System.out.println("Botón 26 clickeado");
            }
        }); 
        button27.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Acción que se ejecuta cuando se hace clic en el botón
                System.out.println("Botón 27 clickeado");
            }
        }); 
        button28.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Acción que se ejecuta cuando se hace clic en el botón
                System.out.println("Botón 28 clickeado");
            }
        }); 
        button31.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Acción que se ejecuta cuando se hace clic en el botón
                System.out.println("Botón 31 clickeado");
            }
        }); 
        button32.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Acción que se ejecuta cuando se hace clic en el botón
                System.out.println("Botón 32 clickeado");
            }
        }); 
        
        button33.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Acción que se ejecuta cuando se hace clic en el botón
                System.out.println("Botón 33 clickeado");
            }
        });
        button34.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Acción que se ejecuta cuando se hace clic en el botón
                System.out.println("Botón 34 clickeado");
            }
        }); 
        button35.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Acción que se ejecuta cuando se hace clic en el botón
                System.out.println("Botón 35 clickeado");
            }
        }); 
        button36.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Acción que se ejecuta cuando se hace clic en el botón
                System.out.println("Botón 36 clickeado");
            }
        }); 
        button37.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Acción que se ejecuta cuando se hace clic en el botón
                System.out.println("Botón 37 clickeado");
            }
        }); 
        button38.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Acción que se ejecuta cuando se hace clic en el botón
                System.out.println("Botón 38 clickeado");
            }
        }); 
        button41.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Acción que se ejecuta cuando se hace clic en el botón
                System.out.println("Botón 41 clickeado");
            }
        }); 
        button42.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Acción que se ejecuta cuando se hace clic en el botón
                System.out.println("Botón 42 clickeado");
            }
        }); 
        button43.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Acción que se ejecuta cuando se hace clic en el botón
                System.out.println("Botón 43 clickeado");
            }
        }); 
        button44.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Acción que se ejecuta cuando se hace clic en el botón
                System.out.println("Botón 44 clickeado");
            }
        }); 
        button45.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Acción que se ejecuta cuando se hace clic en el botón
                System.out.println("Botón 45 clickeado");
            }
        }); 
        button46.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Acción que se ejecuta cuando se hace clic en el botón
                System.out.println("Botón 46 clickeado");
            }
        }); 
        button47.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Acción que se ejecuta cuando se hace clic en el botón
                System.out.println("Botón 47 clickeado");
            }
        }); 
        button48.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Acción que se ejecuta cuando se hace clic en el botón
                System.out.println("Botón 48 clickeado");
            }
        }); 
        button19.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Acción que se ejecuta cuando se hace clic en el botón
                System.out.println("Botón 20 clickeado");
            }
        }); 
        button29.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Acción que se ejecuta cuando se hace clic en el botón
                System.out.println("Botón 30 clickeado");
            }
        }); 
        button39.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Acción que se ejecuta cuando se hace clic en el botón
                System.out.println("Botón 40 clickeado");
            }
        }); 
    
                
        timer = new Timer(tiempo, e -> {
        int indiceAleatorio = random.nextInt(botones.length);
        botones[indiceAleatorio].doClick();
    });  
        timer2 = new Timer(tiempo, e ->{
            int indicePlanta = random2.nextInt(botonesPlanta.length);
            botonesPlanta[indicePlanta].doClick();
        });

timer.start();
timer2.start();
}   
    
    
    public Image getIconImage(){
        Image retValue = Toolkit.getDefaultToolkit().getImage(ClassLoader.getSystemResource("imagenes/Icon.png"));
        return retValue;
        
    }
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        podadoraFila1 = new javax.swing.JLabel();
        podadoraFila4 = new javax.swing.JLabel();
        podadoraFila5 = new javax.swing.JLabel();
        podadoraFila2 = new javax.swing.JLabel();
        MenuButton = new javax.swing.JButton();
        podadoraFila3 = new javax.swing.JLabel();
        panelTablero = new javax.swing.JPanel();
        button00 = new javax.swing.JButton();
        button01 = new javax.swing.JButton();
        button02 = new javax.swing.JButton();
        button03 = new javax.swing.JButton();
        button04 = new javax.swing.JButton();
        button05 = new javax.swing.JButton();
        button06 = new javax.swing.JButton();
        button07 = new javax.swing.JButton();
        button08 = new javax.swing.JButton();
        button09 = new javax.swing.JButton();
        button10 = new javax.swing.JButton();
        button11 = new javax.swing.JButton();
        button12 = new javax.swing.JButton();
        button13 = new javax.swing.JButton();
        button14 = new javax.swing.JButton();
        button15 = new javax.swing.JButton();
        button16 = new javax.swing.JButton();
        button17 = new javax.swing.JButton();
        button18 = new javax.swing.JButton();
        button19 = new javax.swing.JButton();
        button20 = new javax.swing.JButton();
        button21 = new javax.swing.JButton();
        button22 = new javax.swing.JButton();
        button23 = new javax.swing.JButton();
        button24 = new javax.swing.JButton();
        button25 = new javax.swing.JButton();
        button26 = new javax.swing.JButton();
        button27 = new javax.swing.JButton();
        button28 = new javax.swing.JButton();
        button29 = new javax.swing.JButton();
        button30 = new javax.swing.JButton();
        button31 = new javax.swing.JButton();
        button32 = new javax.swing.JButton();
        button33 = new javax.swing.JButton();
        button34 = new javax.swing.JButton();
        button35 = new javax.swing.JButton();
        button36 = new javax.swing.JButton();
        button37 = new javax.swing.JButton();
        button38 = new javax.swing.JButton();
        button39 = new javax.swing.JButton();
        button40 = new javax.swing.JButton();
        button41 = new javax.swing.JButton();
        button42 = new javax.swing.JButton();
        button43 = new javax.swing.JButton();
        button44 = new javax.swing.JButton();
        button45 = new javax.swing.JButton();
        button46 = new javax.swing.JButton();
        button47 = new javax.swing.JButton();
        button48 = new javax.swing.JButton();
        button49 = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();
        jMenu2 = new javax.swing.JMenu();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setIconImage(getIconImage());
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        podadoraFila1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/Podadora.png"))); // NOI18N
        getContentPane().add(podadoraFila1, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 130, -1, -1));

        podadoraFila4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/Podadora.png"))); // NOI18N
        getContentPane().add(podadoraFila4, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 670, -1, -1));

        podadoraFila5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/Podadora.png"))); // NOI18N
        getContentPane().add(podadoraFila5, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 850, 90, -1));

        podadoraFila2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/Podadora.png"))); // NOI18N
        getContentPane().add(podadoraFila2, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 320, -1, -1));

        MenuButton.setBackground(new java.awt.Color(0, 0, 0));
        MenuButton.setFont(new java.awt.Font("Segoe UI", 3, 25)); // NOI18N
        MenuButton.setForeground(new java.awt.Color(51, 255, 0));
        MenuButton.setText("MENU");
        MenuButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MenuButtonActionPerformed(evt);
            }
        });
        getContentPane().add(MenuButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(1800, 10, -1, -1));

        podadoraFila3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/Podadora.png"))); // NOI18N
        getContentPane().add(podadoraFila3, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 500, -1, -1));

        panelTablero.setOpaque(false);
        panelTablero.setLayout(new java.awt.GridLayout(5, 10));

        button00.setContentAreaFilled(false);
        button00.setEnabled(false);
        panelTablero.add(button00);

        button01.setBorderPainted(false);
        button01.setContentAreaFilled(false);
        button01.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                button01ActionPerformed(evt);
            }
        });
        panelTablero.add(button01);

        button02.setBorderPainted(false);
        button02.setContentAreaFilled(false);
        button02.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                button02ActionPerformed(evt);
            }
        });
        panelTablero.add(button02);

        button03.setBorderPainted(false);
        button03.setContentAreaFilled(false);
        button03.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                button03ActionPerformed(evt);
            }
        });
        panelTablero.add(button03);

        button04.setBorderPainted(false);
        button04.setContentAreaFilled(false);
        button04.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                button04ActionPerformed(evt);
            }
        });
        panelTablero.add(button04);

        button05.setBorderPainted(false);
        button05.setContentAreaFilled(false);
        button05.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                button05ActionPerformed(evt);
            }
        });
        panelTablero.add(button05);

        button06.setContentAreaFilled(false);
        button06.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                button06ActionPerformed(evt);
            }
        });
        panelTablero.add(button06);

        button07.setContentAreaFilled(false);
        button07.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                button07ActionPerformed(evt);
            }
        });
        panelTablero.add(button07);

        button08.setContentAreaFilled(false);
        button08.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                button08ActionPerformed(evt);
            }
        });
        panelTablero.add(button08);

        button09.setToolTipText("");
        button09.setAutoscrolls(true);
        button09.setContentAreaFilled(false);
        button09.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                button09ActionPerformed(evt);
            }
        });
        panelTablero.add(button09);

        button10.setContentAreaFilled(false);
        panelTablero.add(button10);

        button11.setContentAreaFilled(false);
        button11.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                button11ActionPerformed(evt);
            }
        });
        panelTablero.add(button11);

        button12.setContentAreaFilled(false);
        button12.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                button12ActionPerformed(evt);
            }
        });
        panelTablero.add(button12);

        button13.setToolTipText("");
        button13.setContentAreaFilled(false);
        button13.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                button13ActionPerformed(evt);
            }
        });
        panelTablero.add(button13);

        button14.setContentAreaFilled(false);
        button14.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                button14ActionPerformed(evt);
            }
        });
        panelTablero.add(button14);

        button15.setContentAreaFilled(false);
        button15.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                button15ActionPerformed(evt);
            }
        });
        panelTablero.add(button15);

        button16.setContentAreaFilled(false);
        button16.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                button16ActionPerformed(evt);
            }
        });
        panelTablero.add(button16);

        button17.setContentAreaFilled(false);
        button17.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                button17ActionPerformed(evt);
            }
        });
        panelTablero.add(button17);

        button18.setContentAreaFilled(false);
        button18.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                button18ActionPerformed(evt);
            }
        });
        panelTablero.add(button18);

        button19.setContentAreaFilled(false);
        button19.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                button19ActionPerformed(evt);
            }
        });
        panelTablero.add(button19);

        button20.setContentAreaFilled(false);
        panelTablero.add(button20);

        button21.setContentAreaFilled(false);
        button21.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                button21ActionPerformed(evt);
            }
        });
        panelTablero.add(button21);

        button22.setContentAreaFilled(false);
        button22.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                button22ActionPerformed(evt);
            }
        });
        panelTablero.add(button22);

        button23.setContentAreaFilled(false);
        button23.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                button23ActionPerformed(evt);
            }
        });
        panelTablero.add(button23);

        button24.setContentAreaFilled(false);
        button24.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                button24ActionPerformed(evt);
            }
        });
        panelTablero.add(button24);

        button25.setContentAreaFilled(false);
        button25.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                button25ActionPerformed(evt);
            }
        });
        panelTablero.add(button25);

        button26.setContentAreaFilled(false);
        button26.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                button26ActionPerformed(evt);
            }
        });
        panelTablero.add(button26);

        button27.setContentAreaFilled(false);
        button27.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                button27ActionPerformed(evt);
            }
        });
        panelTablero.add(button27);

        button28.setContentAreaFilled(false);
        button28.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                button28ActionPerformed(evt);
            }
        });
        panelTablero.add(button28);

        button29.setContentAreaFilled(false);
        button29.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                button29ActionPerformed(evt);
            }
        });
        panelTablero.add(button29);

        button30.setContentAreaFilled(false);
        panelTablero.add(button30);

        button31.setContentAreaFilled(false);
        button31.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                button31ActionPerformed(evt);
            }
        });
        panelTablero.add(button31);

        button32.setContentAreaFilled(false);
        button32.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                button32ActionPerformed(evt);
            }
        });
        panelTablero.add(button32);

        button33.setContentAreaFilled(false);
        button33.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                button33ActionPerformed(evt);
            }
        });
        panelTablero.add(button33);

        button34.setContentAreaFilled(false);
        button34.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                button34ActionPerformed(evt);
            }
        });
        panelTablero.add(button34);

        button35.setContentAreaFilled(false);
        button35.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                button35ActionPerformed(evt);
            }
        });
        panelTablero.add(button35);

        button36.setContentAreaFilled(false);
        button36.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                button36ActionPerformed(evt);
            }
        });
        panelTablero.add(button36);

        button37.setContentAreaFilled(false);
        button37.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                button37ActionPerformed(evt);
            }
        });
        panelTablero.add(button37);

        button38.setContentAreaFilled(false);
        button38.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                button38ActionPerformed(evt);
            }
        });
        panelTablero.add(button38);

        button39.setContentAreaFilled(false);
        button39.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                button39ActionPerformed(evt);
            }
        });
        panelTablero.add(button39);

        button40.setToolTipText("");
        button40.setBorderPainted(false);
        button40.setContentAreaFilled(false);
        panelTablero.add(button40);

        button41.setContentAreaFilled(false);
        button41.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                button41ActionPerformed(evt);
            }
        });
        panelTablero.add(button41);

        button42.setContentAreaFilled(false);
        button42.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                button42ActionPerformed(evt);
            }
        });
        panelTablero.add(button42);

        button43.setContentAreaFilled(false);
        button43.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                button43ActionPerformed(evt);
            }
        });
        panelTablero.add(button43);

        button44.setContentAreaFilled(false);
        button44.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                button44ActionPerformed(evt);
            }
        });
        panelTablero.add(button44);

        button45.setContentAreaFilled(false);
        button45.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                button45ActionPerformed(evt);
            }
        });
        panelTablero.add(button45);

        button46.setContentAreaFilled(false);
        button46.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                button46ActionPerformed(evt);
            }
        });
        panelTablero.add(button46);

        button47.setContentAreaFilled(false);
        button47.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                button47ActionPerformed(evt);
            }
        });
        panelTablero.add(button47);

        button48.setContentAreaFilled(false);
        button48.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                button48ActionPerformed(evt);
            }
        });
        panelTablero.add(button48);

        button49.setContentAreaFilled(false);
        button49.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                button49ActionPerformed(evt);
            }
        });
        panelTablero.add(button49);

        getContentPane().add(panelTablero, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 110, 1120, 880));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/TableroDia.png"))); // NOI18N
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, -30, 1910, 1060));

        jMenu1.setText("File");
        jMenuBar1.add(jMenu1);

        jMenu2.setText("Edit");
        jMenuBar1.add(jMenu2);

        setJMenuBar(jMenuBar1);

        pack();
    }// </editor-fold>//GEN-END:initComponents
private void cargarImagenes() {
        zombieImages.put("NormalZombie", new ImageIcon(getClass().getResource("/imagenes/Zombie.gif")));
        zombieImages.put("ConoZombie", new ImageIcon(getClass().getResource("/imagenes/ConeheadZombie.gif")));
        zombieImages.put("CubeZombie", new ImageIcon(getClass().getResource("/imagenes/BucketheadZombie.gif")));
        zombieImages.put("ECIZombie", new ImageIcon(getClass().getResource("/imagenes/FlagZombie.gif")));
        plantImages.put("Lanzaguisantes",new ImageIcon(getClass().getResource("/imagenes/Peashooter.gif")));
        plantImages.put("Nuez", new ImageIcon(getClass().getResource("/imagenes/nut.gif")));
        plantImages.put("Papapum",new ImageIcon(getClass().getResource("/imagenes/PotatoMine.gif")));
}

    private void MenuButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MenuButtonActionPerformed
        GamePaused gamePaused = new GamePaused(tablero);
        gamePaused.setVisible(true);

    }//GEN-LAST:event_MenuButtonActionPerformed

    private void button01ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_button01ActionPerformed
        String randomPlant = tablero.getRandomPlant();
        System.out.println("Planta seleccuinada: " + randomPlant);
        Planta selectedPlant = null;
        if (selectedPlant == null ) {
            if(randomPlant.equals("Peashooter")){
                selectedPlant = new LanzaGuisantes(tablero);

            }else if(randomPlant.equals("Nut")) {
                selectedPlant = new Nuez(tablero);

            }else if (randomPlant.equals("Mine")){
                selectedPlant = new Papapum(tablero);
            }
            tablero.addPlant(0, 1, selectedPlant);

            String plantName = selectedPlant.getName();
            if (plantImages.containsKey(plantName)) {
                // Establecer la imagen en el botón
                button01.setIcon(plantImages.get(plantName));
                button01.revalidate();
                button01.repaint();

            }else{
                System.out.println("no se esta cargando la imagen");
            }
        }  
    }//GEN-LAST:event_button01ActionPerformed

    private void button02ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_button02ActionPerformed
        String randomPlant = tablero.getRandomPlant();
        System.out.println("Planta seleccuinada: " + randomPlant);
        Planta selectedPlant = null;
        if (selectedPlant == null ) {
            if(randomPlant.equals("Peashooter")){
                selectedPlant = new LanzaGuisantes(tablero);

            }else if(randomPlant.equals("Nut")) {
                selectedPlant = new Nuez(tablero);

            }else if (randomPlant.equals("Mine")){
                selectedPlant = new Papapum(tablero);
            }
            tablero.addPlant(0, 2, selectedPlant);

            String plantName = selectedPlant.getName();
            if (plantImages.containsKey(plantName)) {
                // Establecer la imagen en el botón
                button02.setIcon(plantImages.get(plantName));
                button02.revalidate();
                button02.repaint();

            }else{
                System.out.println("no se esta cargando la imagen");
            }
        }  
        
    }//GEN-LAST:event_button02ActionPerformed

    private void button03ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_button03ActionPerformed
        String randomPlant = tablero.getRandomPlant();
        System.out.println("Planta seleccuinada: " + randomPlant);
        Planta selectedPlant = null;
        if (selectedPlant == null ) {
            if(randomPlant.equals("Peashooter")){
                selectedPlant = new LanzaGuisantes(tablero);

            }else if(randomPlant.equals("Nut")) {
                selectedPlant = new Nuez(tablero);

            }else if (randomPlant.equals("Mine")){
                selectedPlant = new Papapum(tablero);
            }
            tablero.addPlant(0, 3, selectedPlant);

            String plantName = selectedPlant.getName();
            if (plantImages.containsKey(plantName)) {
                // Establecer la imagen en el botón
                button03.setIcon(plantImages.get(plantName));
                button03.revalidate();
                button03.repaint();

            }else{
                System.out.println("no se esta cargando la imagen");
            }
        }  
        
    }//GEN-LAST:event_button03ActionPerformed

    private void button04ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_button04ActionPerformed
        String randomPlant = tablero.getRandomPlant();
        System.out.println("Planta seleccuinada: " + randomPlant);
        Planta selectedPlant = null;
        if (selectedPlant == null ) {
            if(randomPlant.equals("Peashooter")){
                selectedPlant = new LanzaGuisantes(tablero);

            }else if(randomPlant.equals("Nut")) {
                selectedPlant = new Nuez(tablero);

            }else if (randomPlant.equals("Mine")){
                selectedPlant = new Papapum(tablero);
            }
            tablero.addPlant(0, 4, selectedPlant);

            String plantName = selectedPlant.getName();
            if (plantImages.containsKey(plantName)) {
                // Establecer la imagen en el botón
                button04.setIcon(plantImages.get(plantName));
                button04.revalidate();
                button04.repaint();

            }else{
                System.out.println("no se esta cargando la imagen");
            }
        }  
        
    }//GEN-LAST:event_button04ActionPerformed

    private void button05ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_button05ActionPerformed
        String randomPlant = tablero.getRandomPlant();
        System.out.println("Planta seleccuinada: " + randomPlant);
        Planta selectedPlant = null;
        if (selectedPlant == null ) {
            if(randomPlant.equals("Peashooter")){
                selectedPlant = new LanzaGuisantes(tablero);

            }else if(randomPlant.equals("Nut")) {
                selectedPlant = new Nuez(tablero);

            }else if (randomPlant.equals("Mine")){
                selectedPlant = new Papapum(tablero);
            }
            tablero.addPlant(0, 5, selectedPlant);

            String plantName = selectedPlant.getName();
            if (plantImages.containsKey(plantName)) {
                // Establecer la imagen en el botón
                button05.setIcon(plantImages.get(plantName));
                button05.revalidate();
                button05.repaint();

            }else{
                System.out.println("no se esta cargando la imagen");
            }
        }  
        
    }//GEN-LAST:event_button05ActionPerformed

    private void button06ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_button06ActionPerformed
        String randomPlant = tablero.getRandomPlant();
        System.out.println("Planta seleccuinada: " + randomPlant);
        Planta selectedPlant = null;
        if (selectedPlant == null ) {
            if(randomPlant.equals("Peashooter")){
                selectedPlant = new LanzaGuisantes(tablero);

            }else if(randomPlant.equals("Nut")) {
                selectedPlant = new Nuez(tablero);

            }else if (randomPlant.equals("Mine")){
                selectedPlant = new Papapum(tablero);
            }
            tablero.addPlant(0, 6, selectedPlant);

            String plantName = selectedPlant.getName();
            if (plantImages.containsKey(plantName)) {
                // Establecer la imagen en el botón
                button06.setIcon(plantImages.get(plantName));
                button06.revalidate();
                button06.repaint();

            }else{
                System.out.println("no se esta cargando la imagen");
            }
        }  
        
    }//GEN-LAST:event_button06ActionPerformed

    private void button07ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_button07ActionPerformed
        String randomPlant = tablero.getRandomPlant();
        System.out.println("Planta seleccuinada: " + randomPlant);
        Planta selectedPlant = null;
        if (selectedPlant == null ) {
            if(randomPlant.equals("Peashooter")){
                selectedPlant = new LanzaGuisantes(tablero);

            }else if(randomPlant.equals("Nut")) {
                selectedPlant = new Nuez(tablero);

            }else if (randomPlant.equals("Mine")){
                selectedPlant = new Papapum(tablero);
            }
            tablero.addPlant(0, 7, selectedPlant);

            String plantName = selectedPlant.getName();
            if (plantImages.containsKey(plantName)) {
                // Establecer la imagen en el botón
                button07.setIcon(plantImages.get(plantName));
                button07.revalidate();
                button07.repaint();

            }else{
                System.out.println("no se esta cargando la imagen");
            }
        }  
        
    }//GEN-LAST:event_button07ActionPerformed

    private void button08ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_button08ActionPerformed
        String randomPlant = tablero.getRandomPlant();
        System.out.println("Planta seleccuinada: " + randomPlant);
        Planta selectedPlant = null;
        if (selectedPlant == null ) {
            if(randomPlant.equals("Peashooter")){
                selectedPlant = new LanzaGuisantes(tablero);

            }else if(randomPlant.equals("Nut")) {
                selectedPlant = new Nuez(tablero);

            }else if (randomPlant.equals("Mine")){
                selectedPlant = new Papapum(tablero);
            }
            tablero.addPlant(0, 8, selectedPlant);

             String plantName = selectedPlant.getName();
            if (plantImages.containsKey(plantName)) {
                // Establecer la imagen en el botón
                button08.setIcon(plantImages.get(plantName));
                button08.revalidate();
                button08.repaint();

            }else{
                System.out.println("no se esta cargando la imagen");
            }
        }  
        
    }//GEN-LAST:event_button08ActionPerformed

    private void button09ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_button09ActionPerformed
        String randomZombie = tablero.getRandomZombie();
        System.out.println("Zombie seleccionado: " + randomZombie);
        Zombie zombieSpawn = null;
        if (randomZombie != null) {
            if(randomZombie.equals("NormalZombie")){
                zombieSpawn = new NormalZombie(tablero);

            }else if(randomZombie.equals("ConoZombie")) {
                zombieSpawn = new ConoZombie(tablero);

            }else if (randomZombie.equals("CubeZombie")){
                zombieSpawn = new CubeZombie(tablero);
            }else if(randomZombie.equals("ECIZombie")){
                zombieSpawn = new ECIZombie(tablero);
            }
            tablero.addZombie(0, 9, zombieSpawn);
            String zombieName = zombieSpawn.getName();
            if (zombieImages.containsKey(zombieName)) {
                // Establecer la imagen en el botón
                button09.setIcon(zombieImages.get(zombieName));
                button09.revalidate();
                button09.repaint();

            }else{
                System.out.println("no se esta cargando la imagen");
            }

        }
    }//GEN-LAST:event_button09ActionPerformed

    private void button11ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_button11ActionPerformed
        String randomPlant = tablero.getRandomPlant();
        System.out.println("Planta seleccuinada: " + randomPlant);
        Planta selectedPlant = null;
        if (selectedPlant == null ) {
            if(randomPlant.equals("Peashooter")){
                selectedPlant = new LanzaGuisantes(tablero);

            }else if(randomPlant.equals("Nut")) {
                selectedPlant = new Nuez(tablero);

            }else if (randomPlant.equals("Mine")){
                selectedPlant = new Papapum(tablero);
            }
            tablero.addPlant(1, 1, selectedPlant);

            String plantName = selectedPlant.getName();
            if (plantImages.containsKey(plantName)) {
                // Establecer la imagen en el botón
                button11.setIcon(plantImages.get(plantName));
                button11.revalidate();
                button11.repaint();

            }else{
                System.out.println("no se esta cargando la imagen");
            }
        }  
        
    }//GEN-LAST:event_button11ActionPerformed

    private void button12ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_button12ActionPerformed
      String randomPlant = tablero.getRandomPlant();
        System.out.println("Planta seleccuinada: " + randomPlant);
        Planta selectedPlant = null;
        if (selectedPlant == null ) {
            if(randomPlant.equals("Peashooter")){
                selectedPlant = new LanzaGuisantes(tablero);

            }else if(randomPlant.equals("Nut")) {
                selectedPlant = new Nuez(tablero);

            }else if (randomPlant.equals("Mine")){
                selectedPlant = new Papapum(tablero);
            }
            tablero.addPlant(1, 2, selectedPlant);

             String plantName = selectedPlant.getName();
            if (plantImages.containsKey(plantName)) {
                // Establecer la imagen en el botón
                button12.setIcon(plantImages.get(plantName));
                button12.revalidate();
                button12.repaint();

            }else{
                System.out.println("no se esta cargando la imagen");
            }
        }  
       
    }//GEN-LAST:event_button12ActionPerformed

    private void button13ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_button13ActionPerformed
       String randomPlant = tablero.getRandomPlant();
        System.out.println("Planta seleccuinada: " + randomPlant);
        Planta selectedPlant = null;
        if (selectedPlant == null ) {
            if(randomPlant.equals("Peashooter")){
                selectedPlant = new LanzaGuisantes(tablero);

            }else if(randomPlant.equals("Nut")) {
                selectedPlant = new Nuez(tablero);

            }else if (randomPlant.equals("Mine")){
                selectedPlant = new Papapum(tablero);
            }
            tablero.addPlant(1, 3, selectedPlant);

            String plantName = selectedPlant.getName();
            if (plantImages.containsKey(plantName)) {
                // Establecer la imagen en el botón
                button13.setIcon(plantImages.get(plantName));
                button13.revalidate();
                button13.repaint();

            }else{
                System.out.println("no se esta cargando la imagen");
            }
        }  
        
    }//GEN-LAST:event_button13ActionPerformed

    private void button14ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_button14ActionPerformed
       String randomPlant = tablero.getRandomPlant();
        System.out.println("Planta seleccuinada: " + randomPlant);
        Planta selectedPlant = null;
        if (selectedPlant == null ) {
            if(randomPlant.equals("Peashooter")){
                selectedPlant = new LanzaGuisantes(tablero);

            }else if(randomPlant.equals("Nut")) {
                selectedPlant = new Nuez(tablero);

            }else if (randomPlant.equals("Mine")){
                selectedPlant = new Papapum(tablero);
            }
            tablero.addPlant(1, 4, selectedPlant);

             String plantName = selectedPlant.getName();
            if (plantImages.containsKey(plantName)) {
                // Establecer la imagen en el botón
                button14.setIcon(plantImages.get(plantName));
                button14.revalidate();
                button14.repaint();

            }else{
                System.out.println("no se esta cargando la imagen");
            }
        }  
        
    }//GEN-LAST:event_button14ActionPerformed

    private void button15ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_button15ActionPerformed
        String randomPlant = tablero.getRandomPlant();
        System.out.println("Planta seleccuinada: " + randomPlant);
        Planta selectedPlant = null;
        if (selectedPlant == null ) {
            if(randomPlant.equals("Peashooter")){
                selectedPlant = new LanzaGuisantes(tablero);

            }else if(randomPlant.equals("Nut")) {
                selectedPlant = new Nuez(tablero);

            }else if (randomPlant.equals("Mine")){
                selectedPlant = new Papapum(tablero);
            }
            tablero.addPlant(1, 5, selectedPlant);

             String plantName = selectedPlant.getName();
            if (plantImages.containsKey(plantName)) {
                // Establecer la imagen en el botón
                button15.setIcon(plantImages.get(plantName));
                button15.revalidate();
                button15.repaint();

            }else{
                System.out.println("no se esta cargando la imagen");
            }
        }  
        
    }//GEN-LAST:event_button15ActionPerformed

    private void button16ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_button16ActionPerformed
       String randomPlant = tablero.getRandomPlant();
        System.out.println("Planta seleccuinada: " + randomPlant);
        Planta selectedPlant = null;
        if (selectedPlant == null ) {
            if(randomPlant.equals("Peashooter")){
                selectedPlant = new LanzaGuisantes(tablero);

            }else if(randomPlant.equals("Nut")) {
                selectedPlant = new Nuez(tablero);

            }else if (randomPlant.equals("Mine")){
                selectedPlant = new Papapum(tablero);
            }
            tablero.addPlant(1, 6, selectedPlant);

            String plantName = selectedPlant.getName();
            if (plantImages.containsKey(plantName)) {
                // Establecer la imagen en el botón
                button16.setIcon(plantImages.get(plantName));
                button16.revalidate();
                button16.repaint();

            }else{
                System.out.println("no se esta cargando la imagen");
            }
        }  
       
    }//GEN-LAST:event_button16ActionPerformed

    private void button17ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_button17ActionPerformed
        String randomPlant = tablero.getRandomPlant();
        System.out.println("Planta seleccuinada: " + randomPlant);
        Planta selectedPlant = null;
        if (selectedPlant == null ) {
            if(randomPlant.equals("Peashooter")){
                selectedPlant = new LanzaGuisantes(tablero);

            }else if(randomPlant.equals("Nut")) {
                selectedPlant = new Nuez(tablero);

            }else if (randomPlant.equals("Mine")){
                selectedPlant = new Papapum(tablero);
            }
            tablero.addPlant(1, 7, selectedPlant);

            String plantName = selectedPlant.getName();
            if (plantImages.containsKey(plantName)) {
                // Establecer la imagen en el botón
                button17.setIcon(plantImages.get(plantName));
                button17.revalidate();
                button17.repaint();

            }else{
                System.out.println("no se esta cargando la imagen");
            }
        }  
    }//GEN-LAST:event_button17ActionPerformed

    private void button18ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_button18ActionPerformed
        String randomPlant = tablero.getRandomPlant();
        System.out.println("Planta seleccuinada: " + randomPlant);
        Planta selectedPlant = null;
        if (selectedPlant == null ) {
            if(randomPlant.equals("Peashooter")){
                selectedPlant = new LanzaGuisantes(tablero);

            }else if(randomPlant.equals("Nut")) {
                selectedPlant = new Nuez(tablero);

            }else if (randomPlant.equals("Mine")){
                selectedPlant = new Papapum(tablero);
            }
            tablero.addPlant(1, 8, selectedPlant);

            String plantName = selectedPlant.getName();
            if (plantImages.containsKey(plantName)) {
                // Establecer la imagen en el botón
                button18.setIcon(plantImages.get(plantName));
                button18.revalidate();
                button18.repaint();

            }else{
                System.out.println("no se esta cargando la imagen");
            }
        }  
    }//GEN-LAST:event_button18ActionPerformed

    private void button19ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_button19ActionPerformed
        String randomZombie = tablero.getRandomZombie();
        System.out.println("Zombie seleccionado: " + randomZombie);
        Zombie zombieSpawn = null;
        if (randomZombie != null) {
            if(randomZombie.equals("NormalZombie")){
                zombieSpawn = new NormalZombie(tablero);

            }else if(randomZombie.equals("ConoZombie")) {
                zombieSpawn = new ConoZombie(tablero);

            }else if (randomZombie.equals("CubeZombie")){
                zombieSpawn = new CubeZombie(tablero);
            }else if(randomZombie.equals("ECIZombie")){
                zombieSpawn = new ECIZombie(tablero);
            }
            tablero.addZombie(1, 9, zombieSpawn);
            String zombieName = zombieSpawn.getName();
            if (zombieImages.containsKey(zombieName)) {
                // Establecer la imagen en el botón
                button19.setIcon(zombieImages.get(zombieName));
                button19.revalidate();
                button19.repaint();

            }else{
                System.out.println("no se esta cargando la imagen");
            }

        }        // TODO add your handling code here:
    }//GEN-LAST:event_button19ActionPerformed

    private void button21ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_button21ActionPerformed
        String randomPlant = tablero.getRandomPlant();
        System.out.println("Planta seleccuinada: " + randomPlant);
        Planta selectedPlant = null;
        if (selectedPlant == null ) {
            if(randomPlant.equals("Peashooter")){
                selectedPlant = new LanzaGuisantes(tablero);

            }else if(randomPlant.equals("Nut")) {
                selectedPlant = new Nuez(tablero);

            }else if (randomPlant.equals("Mine")){
                selectedPlant = new Papapum(tablero);
            }
            tablero.addPlant(2, 1, selectedPlant);

            String plantName = selectedPlant.getName();
            if (plantImages.containsKey(plantName)) {
                // Establecer la imagen en el botón
                button21.setIcon(plantImages.get(plantName));
                button21.revalidate();
                button21.repaint();

            }else{
                System.out.println("no se esta cargando la imagen");
            }
        }  
    }//GEN-LAST:event_button21ActionPerformed

    private void button22ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_button22ActionPerformed
       String randomPlant = tablero.getRandomPlant();
        System.out.println("Planta seleccuinada: " + randomPlant);
        Planta selectedPlant = null;
        if (selectedPlant == null ) {
            if(randomPlant.equals("Peashooter")){
                selectedPlant = new LanzaGuisantes(tablero);

            }else if(randomPlant.equals("Nut")) {
                selectedPlant = new Nuez(tablero);

            }else if (randomPlant.equals("Mine")){
                selectedPlant = new Papapum(tablero);
            }
            tablero.addPlant(2, 2, selectedPlant);

            String plantName = selectedPlant.getName();
            if (plantImages.containsKey(plantName)) {
                // Establecer la imagen en el botón
                button22.setIcon(plantImages.get(plantName));
                button22.revalidate();
                button22.repaint();

            }else{
                System.out.println("no se esta cargando la imagen");
            }
        }  
    }//GEN-LAST:event_button22ActionPerformed

    private void button23ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_button23ActionPerformed
       String randomPlant = tablero.getRandomPlant();
        System.out.println("Planta seleccuinada: " + randomPlant);
        Planta selectedPlant = null;
        if (selectedPlant == null ) {
            if(randomPlant.equals("Peashooter")){
                selectedPlant = new LanzaGuisantes(tablero);

            }else if(randomPlant.equals("Nut")) {
                selectedPlant = new Nuez(tablero);

            }else if (randomPlant.equals("Mine")){
                selectedPlant = new Papapum(tablero);
            }
            tablero.addPlant(2, 3, selectedPlant);

            String plantName = selectedPlant.getName();
            if (plantImages.containsKey(plantName)) {
                // Establecer la imagen en el botón
                button23.setIcon(plantImages.get(plantName));
                button23.revalidate();
                button23.repaint();

            }else{
                System.out.println("no se esta cargando la imagen");
            }
        }  
    }//GEN-LAST:event_button23ActionPerformed

    private void button24ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_button24ActionPerformed
        String randomPlant = tablero.getRandomPlant();
        System.out.println("Planta seleccuinada: " + randomPlant);
        Planta selectedPlant = null;
        if (selectedPlant == null ) {
            if(randomPlant.equals("Peashooter")){
                selectedPlant = new LanzaGuisantes(tablero);

            }else if(randomPlant.equals("Nut")) {
                selectedPlant = new Nuez(tablero);

            }else if (randomPlant.equals("Mine")){
                selectedPlant = new Papapum(tablero);
            }
            tablero.addPlant(2, 4, selectedPlant);

            String plantName = selectedPlant.getName();
            if (plantImages.containsKey(plantName)) {
                // Establecer la imagen en el botón
                button24.setIcon(plantImages.get(plantName));
                button24.revalidate();
                button24.repaint();

            }else{
                System.out.println("no se esta cargando la imagen");
            }
        }  
    }//GEN-LAST:event_button24ActionPerformed

    private void button25ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_button25ActionPerformed
        String randomPlant = tablero.getRandomPlant();
        System.out.println("Planta seleccuinada: " + randomPlant);
        Planta selectedPlant = null;
        if (selectedPlant == null ) {
            if(randomPlant.equals("Peashooter")){
                selectedPlant = new LanzaGuisantes(tablero);

            }else if(randomPlant.equals("Nut")) {
                selectedPlant = new Nuez(tablero);

            }else if (randomPlant.equals("Mine")){
                selectedPlant = new Papapum(tablero);
            }
            tablero.addPlant(2, 5, selectedPlant);

            String plantName = selectedPlant.getName();
            if (plantImages.containsKey(plantName)) {
                // Establecer la imagen en el botón
                button25.setIcon(plantImages.get(plantName));
                button25.revalidate();
                button25.repaint();

            }else{
                System.out.println("no se esta cargando la imagen");
            }
        }  
    }//GEN-LAST:event_button25ActionPerformed

    private void button26ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_button26ActionPerformed
       String randomPlant = tablero.getRandomPlant();
        System.out.println("Planta seleccuinada: " + randomPlant);
        Planta selectedPlant = null;
        if (selectedPlant == null ) {
            if(randomPlant.equals("Peashooter")){
                selectedPlant = new LanzaGuisantes(tablero);

            }else if(randomPlant.equals("Nut")) {
                selectedPlant = new Nuez(tablero);

            }else if (randomPlant.equals("Mine")){
                selectedPlant = new Papapum(tablero);
            }
            tablero.addPlant(2, 6, selectedPlant);

            String plantName = selectedPlant.getName();
            if (plantImages.containsKey(plantName)) {
                // Establecer la imagen en el botón
                button26.setIcon(plantImages.get(plantName));
                button26.revalidate();
                button26.repaint();

            }else{
                System.out.println("no se esta cargando la imagen");
            }
        }  
    }//GEN-LAST:event_button26ActionPerformed

    private void button27ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_button27ActionPerformed
       String randomPlant = tablero.getRandomPlant();
        System.out.println("Planta seleccuinada: " + randomPlant);
        Planta selectedPlant = null;
        if (selectedPlant == null ) {
            if(randomPlant.equals("Peashooter")){
                selectedPlant = new LanzaGuisantes(tablero);

            }else if(randomPlant.equals("Nut")) {
                selectedPlant = new Nuez(tablero);

            }else if (randomPlant.equals("Mine")){
                selectedPlant = new Papapum(tablero);
            }
            tablero.addPlant(2, 7, selectedPlant);

            String plantName = selectedPlant.getName();
            if (plantImages.containsKey(plantName)) {
                // Establecer la imagen en el botón
                button27.setIcon(plantImages.get(plantName));
                button27.revalidate();
                button27.repaint();

            }else{
                System.out.println("no se esta cargando la imagen");
            }
        }  
    }//GEN-LAST:event_button27ActionPerformed

    private void button28ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_button28ActionPerformed
        String randomPlant = tablero.getRandomPlant();
        System.out.println("Planta seleccuinada: " + randomPlant);
        Planta selectedPlant = null;
        if (selectedPlant == null ) {
            if(randomPlant.equals("Peashooter")){
                selectedPlant = new LanzaGuisantes(tablero);

            }else if(randomPlant.equals("Nut")) {
                selectedPlant = new Nuez(tablero);

            }else if (randomPlant.equals("Mine")){
                selectedPlant = new Papapum(tablero);
            }
            tablero.addPlant(2, 8, selectedPlant);

            String plantName = selectedPlant.getName();
            if (plantImages.containsKey(plantName)) {
                // Establecer la imagen en el botón
                button28.setIcon(plantImages.get(plantName));
                button28.revalidate();
                button28.repaint();

            }else{
                System.out.println("no se esta cargando la imagen");
            }
        }  
    }//GEN-LAST:event_button28ActionPerformed

    private void button29ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_button29ActionPerformed
        String randomZombie = tablero.getRandomZombie();
        System.out.println("Zombie seleccionado: " + randomZombie);
        Zombie zombieSpawn = null;
        if (randomZombie != null) {
            if(randomZombie.equals("NormalZombie")){
                zombieSpawn = new NormalZombie(tablero);

            }else if(randomZombie.equals("ConoZombie")) {
                zombieSpawn = new ConoZombie(tablero);

            }else if (randomZombie.equals("CubeZombie")){
                zombieSpawn = new CubeZombie(tablero);
            }else if(randomZombie.equals("ECIZombie")){
                zombieSpawn = new ECIZombie(tablero);
            }
            tablero.addZombie(2, 9, zombieSpawn);
            String zombieName = zombieSpawn.getName();
            if (zombieImages.containsKey(zombieName)) {
                // Establecer la imagen en el botón
                button29.setIcon(zombieImages.get(zombieName));
                button29.revalidate();
                button29.repaint();

            }else{
                System.out.println("no se esta cargando la imagen");
            }

        }
    }//GEN-LAST:event_button29ActionPerformed

    private void button31ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_button31ActionPerformed
       String randomPlant = tablero.getRandomPlant();
        System.out.println("Planta seleccuinada: " + randomPlant);
        Planta selectedPlant = null;
        if (selectedPlant == null ) {
            if(randomPlant.equals("Peashooter")){
                selectedPlant = new LanzaGuisantes(tablero);

            }else if(randomPlant.equals("Nut")) {
                selectedPlant = new Nuez(tablero);

            }else if (randomPlant.equals("Mine")){
                selectedPlant = new Papapum(tablero);
            }
            tablero.addPlant(3, 1, selectedPlant);

            String plantName = selectedPlant.getName();
            if (plantImages.containsKey(plantName)) {
                // Establecer la imagen en el botón
                button31.setIcon(plantImages.get(plantName));
                button31.revalidate();
                button31.repaint();

            }else{
                System.out.println("no se esta cargando la imagen");
            }
        }  
    }//GEN-LAST:event_button31ActionPerformed

    private void button32ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_button32ActionPerformed
       String randomPlant = tablero.getRandomPlant();
        System.out.println("Planta seleccuinada: " + randomPlant);
        Planta selectedPlant = null;
        if (selectedPlant == null ) {
            if(randomPlant.equals("Peashooter")){
                selectedPlant = new LanzaGuisantes(tablero);

            }else if(randomPlant.equals("Nut")) {
                selectedPlant = new Nuez(tablero);

            }else if (randomPlant.equals("Mine")){
                selectedPlant = new Papapum(tablero);
            }
            tablero.addPlant(3, 2, selectedPlant);

            String plantName = selectedPlant.getName();
            if (plantImages.containsKey(plantName)) {
                // Establecer la imagen en el botón
                button32.setIcon(plantImages.get(plantName));
                button32.revalidate();
                button32.repaint();

            }else{
                System.out.println("no se esta cargando la imagen");
            }
        }  
    }//GEN-LAST:event_button32ActionPerformed

    private void button33ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_button33ActionPerformed
       String randomPlant = tablero.getRandomPlant();
        System.out.println("Planta seleccuinada: " + randomPlant);
        Planta selectedPlant = null;
        if (selectedPlant == null ) {
            if(randomPlant.equals("Peashooter")){
                selectedPlant = new LanzaGuisantes(tablero);

            }else if(randomPlant.equals("Nut")) {
                selectedPlant = new Nuez(tablero);

            }else if (randomPlant.equals("Mine")){
                selectedPlant = new Papapum(tablero);
            }
            tablero.addPlant(3, 3, selectedPlant);

           String plantName = selectedPlant.getName();
            if (plantImages.containsKey(plantName)) {
                // Establecer la imagen en el botón
                button33.setIcon(plantImages.get(plantName));
                button33.revalidate();
                button33.repaint();

            }else{
                System.out.println("no se esta cargando la imagen");
            }
        }  
    }//GEN-LAST:event_button33ActionPerformed

    private void button34ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_button34ActionPerformed
       String randomPlant = tablero.getRandomPlant();
        System.out.println("Planta seleccuinada: " + randomPlant);
        Planta selectedPlant = null;
        if (selectedPlant == null ) {
            if(randomPlant.equals("Peashooter")){
                selectedPlant = new LanzaGuisantes(tablero);

            }else if(randomPlant.equals("Nut")) {
                selectedPlant = new Nuez(tablero);

            }else if (randomPlant.equals("Mine")){
                selectedPlant = new Papapum(tablero);
            }
            tablero.addPlant(3, 4, selectedPlant);

            String plantName = selectedPlant.getName();
            if (plantImages.containsKey(plantName)) {
                // Establecer la imagen en el botón
                button34.setIcon(plantImages.get(plantName));
                button34.revalidate();
                button34.repaint();

            }else{
                System.out.println("no se esta cargando la imagen");
            }
        }  
    }//GEN-LAST:event_button34ActionPerformed

    private void button35ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_button35ActionPerformed
        String randomPlant = tablero.getRandomPlant();
        System.out.println("Planta seleccuinada: " + randomPlant);
        Planta selectedPlant = null;
        if (selectedPlant == null ) {
            if(randomPlant.equals("Peashooter")){
                selectedPlant = new LanzaGuisantes(tablero);

            }else if(randomPlant.equals("Nut")) {
                selectedPlant = new Nuez(tablero);

            }else if (randomPlant.equals("Mine")){
                selectedPlant = new Papapum(tablero);
            }
            tablero.addPlant(3, 5, selectedPlant);

           String plantName = selectedPlant.getName();
            if (plantImages.containsKey(plantName)) {
                // Establecer la imagen en el botón
                button35.setIcon(plantImages.get(plantName));
                button35.revalidate();
                button35.repaint();

            }else{
                System.out.println("no se esta cargando la imagen");
            }
        }  
    }//GEN-LAST:event_button35ActionPerformed

    private void button36ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_button36ActionPerformed
        String randomPlant = tablero.getRandomPlant();
        System.out.println("Planta seleccuinada: " + randomPlant);
        Planta selectedPlant = null;
        if (selectedPlant == null ) {
            if(randomPlant.equals("Peashooter")){
                selectedPlant = new LanzaGuisantes(tablero);

            }else if(randomPlant.equals("Nut")) {
                selectedPlant = new Nuez(tablero);

            }else if (randomPlant.equals("Mine")){
                selectedPlant = new Papapum(tablero);
            }
            tablero.addPlant(3, 6, selectedPlant);

            String plantName = selectedPlant.getName();
            if (plantImages.containsKey(plantName)) {
                // Establecer la imagen en el botón
                button36.setIcon(plantImages.get(plantName));
                button36.revalidate();
                button36.repaint();

            }else{
                System.out.println("no se esta cargando la imagen");
            }
        }  
    }//GEN-LAST:event_button36ActionPerformed

    private void button37ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_button37ActionPerformed
        String randomPlant = tablero.getRandomPlant();
        System.out.println("Planta seleccuinada: " + randomPlant);
        Planta selectedPlant = null;
        if (selectedPlant == null ) {
            if(randomPlant.equals("Peashooter")){
                selectedPlant = new LanzaGuisantes(tablero);

            }else if(randomPlant.equals("Nut")) {
                selectedPlant = new Nuez(tablero);

            }else if (randomPlant.equals("Mine")){
                selectedPlant = new Papapum(tablero);
            }
            tablero.addPlant(3, 7, selectedPlant);

 String plantName = selectedPlant.getName();
            if (plantImages.containsKey(plantName)) {
                // Establecer la imagen en el botón
                button37.setIcon(plantImages.get(plantName));
                button37.revalidate();
                button37.repaint();

            }else{
                System.out.println("no se esta cargando la imagen");
            }
        }  
    }//GEN-LAST:event_button37ActionPerformed

    private void button38ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_button38ActionPerformed
        String randomPlant = tablero.getRandomPlant();
        System.out.println("Planta seleccuinada: " + randomPlant);
        Planta selectedPlant = null;
        if (selectedPlant == null ) {
            if(randomPlant.equals("Peashooter")){
                selectedPlant = new LanzaGuisantes(tablero);

            }else if(randomPlant.equals("Nut")) {
                selectedPlant = new Nuez(tablero);

            }else if (randomPlant.equals("Mine")){
                selectedPlant = new Papapum(tablero);
            }
            tablero.addPlant(3, 8, selectedPlant);
String plantName = selectedPlant.getName();
            if (plantImages.containsKey(plantName)) {
                // Establecer la imagen en el botón
                button38.setIcon(plantImages.get(plantName));
                button38.revalidate();
                button38.repaint();

            }else{
                System.out.println("no se esta cargando la imagen");
            }
        }  
    }//GEN-LAST:event_button38ActionPerformed

    private void button39ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_button39ActionPerformed
        String randomZombie = tablero.getRandomZombie();
        System.out.println("Zombie seleccionado: " + randomZombie);
        Zombie zombieSpawn = null;
        if (randomZombie != null) {
            if(randomZombie.equals("NormalZombie")){
                zombieSpawn = new NormalZombie(tablero);

            }else if(randomZombie.equals("ConoZombie")) {
                zombieSpawn = new ConoZombie(tablero);

            }else if (randomZombie.equals("CubeZombie")){
                zombieSpawn = new CubeZombie(tablero);
            }else if(randomZombie.equals("ECIZombie")){
                zombieSpawn = new ECIZombie(tablero);
            }
            tablero.addZombie(3, 9, zombieSpawn);
            String zombieName = zombieSpawn.getName();
            if (zombieImages.containsKey(zombieName)) {
                // Establecer la imagen en el botón
                button39.setIcon(zombieImages.get(zombieName));
                button39.revalidate();
                button39.repaint();

            }else{
                System.out.println("no se esta cargando la imagen");
            }

        }
    }//GEN-LAST:event_button39ActionPerformed

    private void button41ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_button41ActionPerformed
        String randomPlant = tablero.getRandomPlant();
        System.out.println("Planta seleccuinada: " + randomPlant);
        Planta selectedPlant = null;
        if (selectedPlant == null ) {
            if(randomPlant.equals("Peashooter")){
                selectedPlant = new LanzaGuisantes(tablero);

            }else if(randomPlant.equals("Nut")) {
                selectedPlant = new Nuez(tablero);

            }else if (randomPlant.equals("Mine")){
                selectedPlant = new Papapum(tablero);
            }
            tablero.addPlant(4, 1, selectedPlant);
String plantName = selectedPlant.getName();
            if (plantImages.containsKey(plantName)) {
                // Establecer la imagen en el botón
                button41.setIcon(plantImages.get(plantName));
                button41.revalidate();
                button41.repaint();

            }else{
                System.out.println("no se esta cargando la imagen");
            }
        }  
    }//GEN-LAST:event_button41ActionPerformed

    private void button42ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_button42ActionPerformed
        String randomPlant = tablero.getRandomPlant();
        System.out.println("Planta seleccuinada: " + randomPlant);
        Planta selectedPlant = null;
        if (selectedPlant == null ) {
            if(randomPlant.equals("Peashooter")){
                selectedPlant = new LanzaGuisantes(tablero);

            }else if(randomPlant.equals("Nut")) {
                selectedPlant = new Nuez(tablero);

            }else if (randomPlant.equals("Mine")){
                selectedPlant = new Papapum(tablero);
            }
            tablero.addPlant(4, 2, selectedPlant);
 String plantName = selectedPlant.getName();
            if (plantImages.containsKey(plantName)) {
                // Establecer la imagen en el botón
                button42.setIcon(plantImages.get(plantName));
                button42.revalidate();
                button42.repaint();

            }else{
                System.out.println("no se esta cargando la imagen");
            }
        }  
    }//GEN-LAST:event_button42ActionPerformed

    private void button43ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_button43ActionPerformed
        String randomPlant = tablero.getRandomPlant();
        System.out.println("Planta seleccuinada: " + randomPlant);
        Planta selectedPlant = null;
        if (selectedPlant == null ) {
            if(randomPlant.equals("Peashooter")){
                selectedPlant = new LanzaGuisantes(tablero);

            }else if(randomPlant.equals("Nut")) {
                selectedPlant = new Nuez(tablero);

            }else if (randomPlant.equals("Mine")){
                selectedPlant = new Papapum(tablero);
            }
            tablero.addPlant(4, 3, selectedPlant);
            String plantName = selectedPlant.getName();
            if (plantImages.containsKey(plantName)) {
                // Establecer la imagen en el botón
                button43.setIcon(plantImages.get(plantName));
                button43.revalidate();
                button43.repaint();

            }else{
                System.out.println("no se esta cargando la imagen");
            }
        }  
    }//GEN-LAST:event_button43ActionPerformed

    private void button44ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_button44ActionPerformed
        String randomPlant = tablero.getRandomPlant();
        System.out.println("Planta seleccuinada: " + randomPlant);
        Planta selectedPlant = null;
        if (selectedPlant == null ) {
            if(randomPlant.equals("Peashooter")){
                selectedPlant = new LanzaGuisantes(tablero);

            }else if(randomPlant.equals("Nut")) {
                selectedPlant = new Nuez(tablero);

            }else if (randomPlant.equals("Mine")){
                selectedPlant = new Papapum(tablero);
            }
            tablero.addPlant(4, 4, selectedPlant);
            String plantName = selectedPlant.getName();
            if (plantImages.containsKey(plantName)) {
                // Establecer la imagen en el botón
                button44.setIcon(plantImages.get(plantName));
                button44.revalidate();
                button44.repaint();

            }else{
                System.out.println("no se esta cargando la imagen");
            }
        }  
    }//GEN-LAST:event_button44ActionPerformed

    private void button45ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_button45ActionPerformed
        String randomPlant = tablero.getRandomPlant();
        System.out.println("Planta seleccuinada: " + randomPlant);
        Planta selectedPlant = null;
        if (selectedPlant == null ) {
            if(randomPlant.equals("Peashooter")){
                selectedPlant = new LanzaGuisantes(tablero);

            }else if(randomPlant.equals("Nut")) {
                selectedPlant = new Nuez(tablero);

            }else if (randomPlant.equals("Mine")){
                selectedPlant = new Papapum(tablero);
            }
            tablero.addPlant(4, 5, selectedPlant);
            String plantName = selectedPlant.getName();
            if (plantImages.containsKey(plantName)) {
                // Establecer la imagen en el botón
                button45.setIcon(plantImages.get(plantName));
                button45.revalidate();
                button45.repaint();

            }else{
                System.out.println("no se esta cargando la imagen");
            }
        }  
    }//GEN-LAST:event_button45ActionPerformed

    private void button46ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_button46ActionPerformed
       String randomPlant = tablero.getRandomPlant();
        System.out.println("Planta seleccuinada: " + randomPlant);
        Planta selectedPlant = null;
        if (selectedPlant == null ) {
            if(randomPlant.equals("Peashooter")){
                selectedPlant = new LanzaGuisantes(tablero);

            }else if(randomPlant.equals("Nut")) {
                selectedPlant = new Nuez(tablero);

            }else if (randomPlant.equals("Mine")){
                selectedPlant = new Papapum(tablero);
            }
            tablero.addPlant(4, 6, selectedPlant);

            String plantName = selectedPlant.getName();
            if (plantImages.containsKey(plantName)) {
                // Establecer la imagen en el botón
                button46.setIcon(plantImages.get(plantName));
                button46.revalidate();
                button46.repaint();

            }else{
                System.out.println("no se esta cargando la imagen");
            }
        }  
    }//GEN-LAST:event_button46ActionPerformed

    private void button47ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_button47ActionPerformed
       String randomPlant = tablero.getRandomPlant();
        System.out.println("Planta seleccuinada: " + randomPlant);
        Planta selectedPlant = null;
        if (selectedPlant == null ) {
            if(randomPlant.equals("Peashooter")){
                selectedPlant = new LanzaGuisantes(tablero);

            }else if(randomPlant.equals("Nut")) {
                selectedPlant = new Nuez(tablero);

            }else if (randomPlant.equals("Mine")){
                selectedPlant = new Papapum(tablero);
            }
            tablero.addPlant(4, 7, selectedPlant);

            String plantName = selectedPlant.getName();
            if (plantImages.containsKey(plantName)) {
                // Establecer la imagen en el botón
                button47.setIcon(plantImages.get(plantName));
                button47.revalidate();
                button47.repaint();

            }else{
                System.out.println("no se esta cargando la imagen");
            }
        }  
    }//GEN-LAST:event_button47ActionPerformed

    private void button48ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_button48ActionPerformed
    String randomPlant = tablero.getRandomPlant();
        System.out.println("Planta seleccuinada: " + randomPlant);
        Planta selectedPlant = null;
        if (selectedPlant == null ) {
            if(randomPlant.equals("Peashooter")){
                selectedPlant = new LanzaGuisantes(tablero);

            }else if(randomPlant.equals("Nut")) {
                selectedPlant = new Nuez(tablero);

            }else if (randomPlant.equals("Mine")){
                selectedPlant = new Papapum(tablero);
            }
            tablero.addPlant(4, 8, selectedPlant);
            String plantName = selectedPlant.getName();
            if (plantImages.containsKey(plantName)) {
                // Establecer la imagen en el botón
                button48.setIcon(plantImages.get(plantName));
                button48.revalidate();
                button48.repaint();

            }else{
                System.out.println("no se esta cargando la imagen");
            }
        }  
           
    }//GEN-LAST:event_button48ActionPerformed

    private void button49ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_button49ActionPerformed
        String randomZombie = tablero.getRandomZombie();
        System.out.println("Zombie seleccionado: " + randomZombie);
        Zombie zombieSpawn = null;
        if (randomZombie != null) {
            if(randomZombie.equals("NormalZombie")){
                zombieSpawn = new NormalZombie(tablero);

            }else if(randomZombie.equals("ConoZombie")) {
                zombieSpawn = new ConoZombie(tablero);

            }else if (randomZombie.equals("CubeZombie")){
                zombieSpawn = new CubeZombie(tablero);
            }else if(randomZombie.equals("ECIZombie")){
                zombieSpawn = new ECIZombie(tablero);
            }
            tablero.addZombie(4, 9, zombieSpawn);
            String zombieName = zombieSpawn.getName();
            if (zombieImages.containsKey(zombieName)) {
                // Establecer la imagen en el botón
                button49.setIcon(zombieImages.get(zombieName));
                button49.revalidate();
                button49.repaint();

            }else{
                System.out.println("no se esta cargando la imagen");
            }

        }
    }//GEN-LAST:event_button49ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(TableroDiaMHVSMH.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(TableroDiaMHVSMH.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(TableroDiaMHVSMH.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(TableroDiaMHVSMH.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new TableroDiaMHVSMH(tablero).setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton MenuButton;
    private javax.swing.JButton button00;
    private javax.swing.JButton button01;
    private javax.swing.JButton button02;
    private javax.swing.JButton button03;
    private javax.swing.JButton button04;
    private javax.swing.JButton button05;
    private javax.swing.JButton button06;
    private javax.swing.JButton button07;
    private javax.swing.JButton button08;
    private javax.swing.JButton button09;
    private javax.swing.JButton button10;
    private javax.swing.JButton button11;
    private javax.swing.JButton button12;
    private javax.swing.JButton button13;
    private javax.swing.JButton button14;
    private javax.swing.JButton button15;
    private javax.swing.JButton button16;
    private javax.swing.JButton button17;
    private javax.swing.JButton button18;
    private javax.swing.JButton button19;
    private javax.swing.JButton button20;
    private javax.swing.JButton button21;
    private javax.swing.JButton button22;
    private javax.swing.JButton button23;
    private javax.swing.JButton button24;
    private javax.swing.JButton button25;
    private javax.swing.JButton button26;
    private javax.swing.JButton button27;
    private javax.swing.JButton button28;
    private javax.swing.JButton button29;
    private javax.swing.JButton button30;
    private javax.swing.JButton button31;
    private javax.swing.JButton button32;
    private javax.swing.JButton button33;
    private javax.swing.JButton button34;
    private javax.swing.JButton button35;
    private javax.swing.JButton button36;
    private javax.swing.JButton button37;
    private javax.swing.JButton button38;
    private javax.swing.JButton button39;
    private javax.swing.JButton button40;
    private javax.swing.JButton button41;
    private javax.swing.JButton button42;
    private javax.swing.JButton button43;
    private javax.swing.JButton button44;
    private javax.swing.JButton button45;
    private javax.swing.JButton button46;
    private javax.swing.JButton button47;
    private javax.swing.JButton button48;
    private javax.swing.JButton button49;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenu jMenu2;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JPanel panelTablero;
    public javax.swing.JLabel podadoraFila1;
    public javax.swing.JLabel podadoraFila2;
    public javax.swing.JLabel podadoraFila3;
    public javax.swing.JLabel podadoraFila4;
    public javax.swing.JLabel podadoraFila5;
    // End of variables declaration//GEN-END:variables
}
