package domain;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.Assert.assertArrayEquals;

public class Test2 {
    private Clustering clustering;

    // Método para configurar el estado inicial
    private void ClusteringEstadoInicial() throws ClusteringException {
        char[][] initialBoard = {
            {'.', 'x', '.'},
            {'x', '.', '.'},
            {'.', '.', 'x'}
        };
        // Inicializa el objeto clustering con el tablero inicial
        clustering = new Clustering(initialBoard, true); // Asegúrate de tener el constructor con tablero
    }

    @Test
    public void testTiltRight() throws ClusteringException {
        // Configura el estado inicial
        ClusteringEstadoInicial();

        // Realiza la acción de inclinar hacia la derecha
        clustering.tiltRight();

        // Tablero esperado después de la inclinación
        char[][] esperado = {
            {'.', '.', 'x'},
            {'.', 'x', '.'},
            {'.', '.', 'x'}
        };

        // Verifica que el estado del tablero sea el esperado
        assertArrayEquals(esperado, clustering.board());
    }
    
    @Test
    public void testTiltUp() throws ClusteringException {
        // Configura el estado inicial
        ClusteringEstadoInicial();

        // Realiza la acción de inclinar hacia la derecha
        clustering.tiltUp();

        // Tablero esperado después de la inclinación
        char[][] esperado = {
            {'x', 'x', '.'},
            {'.', '.', 'x'},
            {'.', '.', '.'}
        };

        // Verifica que el estado del tablero sea el esperado
        assertArrayEquals(esperado, clustering.board());
    }
    
    @Test
    public void testTiltDown() throws ClusteringException {
        // Configura el estado inicial
        ClusteringEstadoInicial();

        // Realiza la acción de inclinar hacia la derecha
        clustering.tiltDown();

        // Tablero esperado después de la inclinación
        char[][] esperado = {
            {'.', '.', '.'},
            {'.', 'x', '.'},
            {'x', '.', 'x'}
        };

        // Verifica que el estado del tablero sea el esperado
        assertArrayEquals(esperado, clustering.board());
    }
    
    @Test
    public void testTiltLeft() throws ClusteringException {
        // Configura el estado inicial
        ClusteringEstadoInicial();

        // Realiza la acción de inclinar hacia la derecha
        clustering.tiltLeft();

        // Tablero esperado después de la inclinación
        char[][] esperado = {
            {'x', '.', '.'},
            {'x', '.', '.'},
            {'.', 'x', '.'}
        };

        // Verifica que el estado del tablero sea el esperado
        assertArrayEquals(esperado, clustering.board());
    }
}