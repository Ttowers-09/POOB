

package domain;

//import  presentation.ClusteringGUI;

public class Clustering {
    
    public static final int MAX_SCORE = 100; // Puntaje máximo ajustable según la lógica de puntuación


    public char[][] board;
    public int height;
    public int width;
    public int score;
    public int tiltings;
    
    
    // Constructor para inicializar el tablero
    public Clustering(int height, int width, int percentage) throws ClusteringException {
        if (height <= 0 || width <= 0 || percentage < 0 || percentage > 100) {
            throw new ClusteringException("Parámetros inválidos para inicializar el tablero.");
        }
        this.height = height;
        this.width = width;
        this.score = 0;
        this.tiltings = 0;

        // Inicializa el tablero con un porcentaje de celdas ocupadas
        this.board = new char[height][width];
        initializeBoard(percentage);
    }

    // Método para inicializar el tablero con un porcentaje de celdas ocupadas
    public void initializeBoard(int percentage) {
        for (int i = 0; i < height; i++) {
            for (int j = 0; j < width; j++) {
                if (Math.random() * 100 < percentage) {
                    board[i][j] = 'X'; // Ficha ocupada
                } else {
                    board[i][j] = '.'; // Celda vacía
                }
            }
        }
    }

        /**
         * Inclina las fichas del tablero en la dirección especificada.
         * 
         * @param direction 'u' para arriba, 'd' para abajo, 'r' para la derecha, 'l' para la izquierda
         */
        // Método para mover las fichas hacia la izquierda (una casilla por fila)
    // Método para mover las fichas hacia la izquierda (una casilla por fila)
    // Método para mover las fichas hacia la izquierda (una casilla por fila)
    public void tiltLeft() {
        for (int row = 0; row < height; row++) {
            for (int col = 0; col < width - 1; col++) {
                if (board[row][col] == '.' && board[row][col + 1] != '.') {
                    // Mueve la ficha una casilla hacia la izquierda
                    board[row][col] = board[row][col + 1];
                    board[row][col + 1] = '.';
                }
            }
        }
    }
    
    public void tiltRight() {
        for (int row = 0; row < height; row++) {
            for (int col = width - 1; col > 0; col--) {
                if (board[row][col] == '.' && board[row][col - 1] != '.') {
                    // Mueve la ficha una casilla hacia la derecha
                    board[row][col] = board[row][col - 1];
                    board[row][col - 1] = '.';
                }
            }
        }
    }

    
    // Método para mover las fichas hacia arriba (una casilla por columna)
    // Método para mover las fichas hacia arriba (una casilla por columna)
    public void tiltUp() {
        for (int col = 0; col < width; col++) {
            for (int row = 0; row < height - 1; row++) {
                if (board[row][col] == '.' && board[row + 1][col] != '.') {
                    // Mueve la ficha una casilla hacia arriba
                    board[row][col] = board[row + 1][col];
                    board[row + 1][col] = '.';
                }
            }
        }
    }


    public void tiltDown() {
        for (int col = 0; col < width; col++) {
            for (int row = height - 1; row > 0; row--) {
                if (board[row][col] == '.' && board[row - 1][col] != '.') {
                    // Mueve la ficha una casilla hacia abajo
                    board[row][col] = board[row - 1][col];
                    board[row - 1][col] = '.';
                }
            }
        }
    }

    
    // Método para mover las fichas hacia la derecha (una casilla por fila)
    // Método para mover las fichas hacia la derecha (una casilla por fila)
    


    // Método para calcular el puntaje (ejemplo simple)
    public int score() {
        int score = 0;
        for (int i = 0; i < height; i++) {
            for (int j = 0; j < width; j++) {
                if (board[i][j] == 'X') {
                    score++; // Incrementa por cada celda ocupada
                }
            }
        }
        return score;
    }

    // Método para obtener el número de inclinaciones realizadas
    public int tiltings() {
        return tiltings;
    }

    // Método para obtener el estado del tablero
    public char[][] board() {
        return board;
    }

    public Clustering(char[][] board, boolean isTest) throws ClusteringException {
        if (board == null || board.length == 0 || board[0].length == 0) {
            throw new ClusteringException("El tablero proporcionado no es válido.");
        }
        this.height = board.length;
        this.width = board[0].length;
        this.board = board;
        this.score = 0;
        this.tiltings = 0;
    
        if (!isTest) {
            throw new ClusteringException("Este constructor es solo para pruebas.");
        }
    }
}
