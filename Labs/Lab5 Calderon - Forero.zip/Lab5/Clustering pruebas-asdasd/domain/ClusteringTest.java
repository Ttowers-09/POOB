package domain;

import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

public class ClusteringTest {

    private Clustering clustering;

    // Este método se ejecutará antes de cada prueba
    @Before
    public void setUp() throws ClusteringException {
        // Inicializa el objeto Clustering para cada prueba
        clustering = new Clustering(3, 3, 50);  // Puedes cambiar estos valores si es necesario
    }

    @Test
    public void testConstructorValidParameters() throws ClusteringException {
        assertNotNull(clustering); // Verifica que el objeto no sea null
        assertEquals(3, clustering.board().length); // Verifica la altura del tablero
        assertEquals(3, clustering.board()[0].length); // Verifica el ancho del tablero
    }

    @Test
    public void testConstructorInvalidHeight() {
        try {
            new Clustering(0, 5, 50); // Debe lanzar una excepción debido a la altura inválida
            fail("Se esperaba una ClusteringException debido a la altura inválida");
        } catch (ClusteringException e) {
            // Se espera la excepción, no hacemos nada aquí
        }
    }

    @Test
    public void testConstructorInvalidWidth() {
        try {
            new Clustering(5, 0, 50); // Debe lanzar una excepción debido al ancho inválido
            fail("Se esperaba una ClusteringException debido al ancho inválido");
        } catch (ClusteringException e) {
            // Se espera la excepción, no hacemos nada aquí
        }
    }

    @Test
    public void testConstructorInvalidPercentage() {
        try {
            new Clustering(5, 5, -1); // Debe lanzar una excepción debido al porcentaje negativo
            fail("Se esperaba una ClusteringException debido al porcentaje negativo");
        } catch (ClusteringException e) {
            // Se espera la excepción, no hacemos nada aquí
        }

        try {
            new Clustering(5, 5, 101); // Debe lanzar una excepción debido al porcentaje mayor a 100
            fail("Se esperaba una ClusteringException debido al porcentaje mayor a 100");
        } catch (ClusteringException e) {
            // Se espera la excepción, no hacemos nada aquí
        }
    }


    @Test
    public void testScore() throws ClusteringException {
        int score = clustering.score();
        
        int expectedScore = 0;
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                if (clustering.board()[i][j] == 'X') {
                    expectedScore++;
                }
            }
        }
        
        assertEquals(expectedScore, score); // Verificar que el puntaje calculado sea correcto
    }


}