package presentation;
import domain.*;
import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.File;
import java.util.Random;
import javax.swing.JButton;
import javax.swing.JColorChooser;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;



public class ClusteringGUI extends JFrame {
    
    // Atributos para el tablero
    private int largo_tablero = 4;
    private int ancho_tablero = 4;
    private JPanel panelTablero;
    private int porcentaje = 50;
    private static final int CELDA_SIZE = 50;
    public Color[][] tablero = new Color[largo_tablero][ancho_tablero];
    private Random rand = new Random();
    private Color[] colors = {Color.RED, Color.GREEN, Color.YELLOW, Color.BLUE};
    private int totalTiles = ((largo_tablero * ancho_tablero)*porcentaje)/100 ;

    //ciclo 4
    private int selectedX = -1;
    private int selectedY = -1;
    //Ciclo 6
     private Clustering clustering;
    //Ciclo 7
    private Color[][] tableroInicial = new Color[largo_tablero][ancho_tablero];

    public ClusteringGUI() {
        setTitle("Clustering GUI");
        //Utilizado para el tamaño de la ventana y mensaje de confirmacion
        prepareElements();
        //Utilizado para el boton de exit, tambie para botones siguientes
        prepareAction();
        prepareElementsMenu();
        prepareActionMenu();
        prepareElementsBoard();
    }

    public static void main(String[] args) {
        ClusteringGUI gui = new ClusteringGUI();
        gui.setVisible(true);
        gui.setLocationRelativeTo(null);
    }

    public void prepareElements() {
        Dimension tamañoPantalla = Toolkit.getDefaultToolkit().getScreenSize();
        int alturaPantalla = tamañoPantalla.height;
        int anchoPantalla = tamañoPantalla.width;
        setSize(anchoPantalla / 2, alturaPantalla / 2);
        try {
            clustering = new Clustering(largo_tablero, ancho_tablero, 50); // 50% de baldosas ocupadas
            
        } catch (ClusteringException e) {
            e.printStackTrace();
        }

        // Para el menú
        prepareElementsMenu();
        // Para tener la forma del tablero
        prepareElementsBoard();
        prepareMovementButton();
        // Asginar las fichas al tablero
        asignTiles();


        // ciclo4
        prepareChangeColorButton();

    }

    public void prepareAction() {
        //Aca podemos agregar el codigo necesario para habilitar el cierre de la ventana
        //Utilizamos por defecto el metodo setDefaulCloseOperation incorporado en JFrame
        //Lo que pretendemos es que el usuario al darle click en el boton de cerrar se cierre de manera automatica
        setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);

        //Si quisieramos que la aplicacion se cerrara sin ningun tipo de verificación
        //setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                exit();
            }
        });
    }

    public void exit() {
        int answer = JOptionPane.showConfirmDialog(this,
                "¿Estas seguro deseas salir del programa?",
                "Confirmar cierre del programa", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);  
        
        if (answer == JOptionPane.YES_OPTION) {
            dispose();
        }
    }

    public void prepareElementsMenu() {
        JMenuBar menuBar = new JMenuBar();
        JMenu menuOptions = new JMenu("Options");

        JMenuItem itemNuevo = new JMenuItem("Nuevo");
        JMenuItem itemSalir = new JMenuItem("Salir");
        JMenuItem itemSalvar = new JMenuItem("Salvar");
        JMenuItem itemAbrir = new JMenuItem("Abrir");
        JMenuItem itemReiniciar = new JMenuItem("Reiniciar");

        menuOptions.add(itemNuevo);
        menuOptions.add(itemSalir);
        menuOptions.add(itemSalvar);
        menuOptions.add(itemAbrir);
        menuOptions.add(itemReiniciar);

        menuBar.add(menuOptions);
        setJMenuBar(menuBar);
    }

    public void prepareActionMenu() {
        JMenuBar menuBar = getJMenuBar();
        JMenu menuOptions = menuBar.getMenu(0); 
        JMenuItem itemSalir = menuOptions.getItem(1);

        //añadidos en ciclo 2
        JMenuItem itemSalvar = menuOptions.getItem(2);
        JMenuItem itemAbrir = menuOptions.getItem(3);
        JMenuItem itemReiniciar = menuOptions.getItem(4);

        itemSalir.addActionListener(e -> exit());

        //añadido ciclo 2
        itemSalvar.addActionListener(e -> saveFile());
        itemAbrir.addActionListener(e -> openFile());
        itemReiniciar.addActionListener(e -> restartTable());
    }

    public void openFile() {
        JFileChooser SeleccionarArchivo = new JFileChooser();
        int answer = SeleccionarArchivo.showOpenDialog(this);
        if (answer == JFileChooser.APPROVE_OPTION) {
            File archivoSeleccionado = SeleccionarArchivo.getSelectedFile();
            JOptionPane.showMessageDialog(this, "Elemento en construcción " + archivoSeleccionado.getName(), "Archivo por abrir", JOptionPane.INFORMATION_MESSAGE);
        }
    }

    public void saveFile() {
        JFileChooser SeleccionarArchivo = new JFileChooser();
        int answer = SeleccionarArchivo.showSaveDialog(this);
        if (answer == JFileChooser.APPROVE_OPTION) {
            File archivoSeleccionado = SeleccionarArchivo.getSelectedFile();
            JOptionPane.showMessageDialog(this, "Elemento en construcción " + archivoSeleccionado.getName(), "Archivo por salvar", JOptionPane.INFORMATION_MESSAGE);
        }
    }

    //Ciclo 3
    public void prepareElementsBoard() {
        //Preparar el panel para el tablero
        panelTablero = new JPanel() {
            //Se sobreescribe un metodo de la clase JPanle para pintar los componentes del 
            //tablero
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                //Dibuja la cuadricula del tablero
                drawBoard(g);
                //Dibuja las fichas que fueron asignadas por asignTiles
                drawTiles(g);
            }
        };
        //Se asigna un tamaño al panel
        panelTablero.setPreferredSize(new Dimension(largo_tablero * CELDA_SIZE, ancho_tablero * CELDA_SIZE));
        getContentPane().add(panelTablero);

        // Hacer que se pueda hacer clic en las celdas
        panelTablero.addMouseListener(new MouseListener() {
            @Override
            public void mousePressed(MouseEvent e) {
                selectedX = e.getX() / CELDA_SIZE;
                selectedY = e.getY() / CELDA_SIZE;
            }
        
            @Override
            public void mouseClicked(MouseEvent e) {}
        
            @Override
            public void mouseReleased(MouseEvent e) {}
        
            @Override
            public void mouseEntered(MouseEvent e) {}
        
            @Override
            public void mouseExited(MouseEvent e) {}
        });
    }

    public void drawBoard(Graphics g) {
        //Se dibuja las lineas verticales y horizontales
        for (int c = 0; c <= largo_tablero; c++) {
            g.drawLine(c * CELDA_SIZE, 0, c * CELDA_SIZE, ancho_tablero * CELDA_SIZE);
        }
        for (int f = 0; f <= ancho_tablero; f++) {
            g.drawLine(0, f * CELDA_SIZE, largo_tablero * CELDA_SIZE, f * CELDA_SIZE);
        }
    }
    public void asignTiles() {
        // Llenar el tablero con celdas vacías inicialmente
        for (int i = 0; i < largo_tablero; i++) {
            for (int j = 0; j < ancho_tablero; j++) {
                tablero[i][j] = null; 
            }
        }
        // Contador de fichas que hay en el tablero actualmente
        int placedTiles = 0;
        while (placedTiles != totalTiles) {
            //Asgina posiciones aleatorias para colocar la ficha
            int x = rand.nextInt(largo_tablero);
            int y = rand.nextInt(ancho_tablero);
            // Si el espacio es vacio, permite colocar la ficha
            if (tablero[x][y] == null) {
                // Coloca un color aleatorio de la lista colors
                tablero[x][y] = colors[rand.nextInt(colors.length)];
                placedTiles++;
            }
        }

        //Ciclo 7
        // Se hace una copia del tablero que se esta crenado
        for (int i = 0; i < largo_tablero; i++) {
            for (int j = 0; j < ancho_tablero; j++) {
                tableroInicial[i][j] = tablero[i][j]; 
            }
        }
    }
    //Se encarga de dibujar las fichas que fueron asignadas
    public void drawTiles(Graphics g) {
        for (int i = 0; i < largo_tablero; i++) {
            for (int j = 0; j < ancho_tablero; j++) {
                if (tablero[i][j] != null) {
                    g.setColor(tablero[i][j]);
                    g.fillRect(i * CELDA_SIZE + 5, j * CELDA_SIZE + 5, CELDA_SIZE - 10, CELDA_SIZE - 10);
                }
            }
        }
    }

    public void prepareMovementButton() {
        //Se estan creando los botones para mover las fichas
        JButton Upbutton = new JButton("Up");
        JButton Downbutton = new JButton("Down");
        JButton Leftbutton = new JButton("Left");
        JButton Rightbutton = new JButton("Right");
         //Se le asigno un color de fonfo
        Upbutton.setBackground(Color.YELLOW);
        Downbutton.setBackground(Color.BLUE);
        Leftbutton.setBackground(Color.RED);
        Rightbutton.setBackground(Color.GREEN);
        //Se añadio el boton al JFrame
        getContentPane().add(Upbutton);
        getContentPane().add(Downbutton);
        getContentPane().add(Leftbutton);
        getContentPane().add(Rightbutton);
        //Se le asigno la medida
        Upbutton.setBounds(300, 35, 60, 60);
        Downbutton.setBounds(300, 100, 60, 60);
        Leftbutton.setBounds(235, 100, 60, 60);
        Rightbutton.setBounds(365, 100, 60, 60);
        
         Upbutton.addActionListener(e -> {
            clustering.tiltUp();  // Mover hacia arriba
            panelTablero.repaint(); // Repinta el tablero
        });

        Downbutton.addActionListener(e -> {
            clustering.tiltDown();  // Mover hacia abajo
            panelTablero.repaint(); // Repinta el tablero
        });

        Leftbutton.addActionListener(e -> {
            clustering.tiltLeft();  // Mover hacia la izquierda
            panelTablero.repaint(); // Repinta el tablero
        });

        Rightbutton.addActionListener(e -> {
            clustering.tiltRight();  // Mover hacia la derecha
            panelTablero.repaint(); // Repinta el tablero
        });
        }

    //Ciclo 4
    public void prepareChangeColorButton() {
        JButton changeColor = new JButton("Change Color");
        changeColor.setBackground(Color.RED);
        getContentPane().add(changeColor);
        changeColor.setBounds(300, 200, 100, 60);
    
        changeColor.addActionListener(e -> {
            if (selectedX != -1 && selectedY != -1) {
                Color selectedColor = JColorChooser.showDialog(this, "Selecciona un color", tablero[selectedX][selectedY]);
                if (selectedColor != null) {
                    tablero[selectedX][selectedY] = selectedColor;
                    panelTablero.repaint(selectedX * CELDA_SIZE, selectedY * CELDA_SIZE, CELDA_SIZE, CELDA_SIZE);
                }
            } else {
                JOptionPane.showMessageDialog(this, "Por favor selecciona una celda primero.", "Advertencia", JOptionPane.WARNING_MESSAGE);
            }
        });
    }


     //Ciclo 6
     public void refresh(){
        //Se crea un nuevo tablero
        tablero = new Color[largo_tablero][ancho_tablero];
        //Se asignan las fichas al tablero
        asignTiles();
        //Se actualiza el tablero
        panelTablero.repaint();
    }
    

//Ciclo 7
    public void restartTable(){
        //Deja el talbero inicial como el tablero actual
        for (int i = 0; i < largo_tablero; i++) {
            for (int j = 0; j < ancho_tablero; j++) {
                tablero[i][j] = tableroInicial[i][j]; 
            }
        }
    
        // Actualiza el tablero
        panelTablero.repaint();
    }
    //Ciclo 8
        public void prepareChangeSizeButton() {
        // Crear un botón para cambiar el tamaño del tablero
        JButton changeSizeButton = new JButton("Cambiar Tamaño");

        changeSizeButton.setBackground(Color.CYAN);
        getContentPane().add(changeSizeButton);
        changeSizeButton.setBounds(300, 270, 150, 60); 
        changeSizeButton.addActionListener(e -> cambiarTamanoTablero());
    }
    public void cambiarTamanoTablero() {
        //Asigna nuevos parametros para el nuevo tablero
        int nuevoAlto = Integer.parseInt(JOptionPane.showInputDialog(this, "Introduce el nuevo alto del tablero (filas):", largo_tablero));
        int nuevoAncho = Integer.parseInt(JOptionPane.showInputDialog(this, "Introduce el nuevo ancho del tablero (columnas):", ancho_tablero));
        int nuevoPorcentaje = Integer.parseInt(JOptionPane.showInputDialog(this, "Introduce el nuevo porcentaje :", porcentaje));
        try {
                largo_tablero= nuevoAlto;
                ancho_tablero= nuevoAncho;
                porcentaje = nuevoPorcentaje;
                if (nuevoAlto <= 0 || nuevoAncho <= 0) {
                    JOptionPane.showMessageDialog(this, "Las dimensiones deben ser mayores que cero.", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                if (nuevoPorcentaje <= 0) {
                    JOptionPane.showMessageDialog(this, "El porcentaje debe ser mayor que cero.", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }
        
                // Asignar el nuevo tablero
                tablero = new Color[largo_tablero][ancho_tablero];
                tableroInicial = new Color[largo_tablero][ancho_tablero];
                totalTiles = ((largo_tablero * ancho_tablero)*porcentaje)/100 ;
                // Asignar las fichas al nuevo tablero
                asignTiles();
                // Actualizar la interfaz gráfica
                panelTablero.setPreferredSize(new Dimension(largo_tablero * CELDA_SIZE, ancho_tablero * CELDA_SIZE));
                panelTablero.repaint(); 
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(this, "Por favor, ingresa números válidos.", "Error de formato", JOptionPane.ERROR_MESSAGE);
            }
    }
}