package domain;

public class ClusteringException extends Exception {

    public ClusteringException(String message){
        super(message);
    }
    
}
