package domain;
//import  presentation.ClusteringGUI;

public class Clustering {
    
    public static final int MAX_SCORE = 100; // Puntaje máximo ajustable según la lógica de puntuación

    private char[][] board;
    private int height;
    private int width;
    private int score;
    private int tiltings;

    // Constructor para inicializar el tablero
    public Clustering(int height, int width, int percentage) throws ClusteringException {
        if (height <= 0 || width <= 0 || percentage < 0 || percentage > 100) {
            throw new ClusteringException("Parámetros inválidos para inicializar el tablero.");
        }
        this.height = height;
        this.width = width;
        this.score = 0;
        this.tiltings = 0;

        // Inicializa el tablero con un porcentaje de celdas ocupadas
        this.board = new char[height][width];
        initializeBoard(percentage);
    }

    // Método para inicializar el tablero con un porcentaje de celdas ocupadas
    private void initializeBoard(int percentage) {
        for (int i = 0; i < height; i++) {
            for (int j = 0; j < width; j++) {
                if (Math.random() * 100 < percentage) {
                    board[i][j] = 'X'; // Ficha ocupada
                } else {
                    board[i][j] = '.'; // Celda vacía
                }
            }
        }
    }

    /**
     * Inclina las fichas del tablero en la dirección especificada.
     * 
     * @param direction 'u' para arriba, 'd' para abajo, 'r' para la derecha, 'l' para la izquierda
     */
    // Método para mover las fichas hacia la izquierda (una casilla por fila)
public void tiltLeft() {
    for (int row = 0; row < height; row++) {
        // Iterar por cada fila y mover las fichas hacia la izquierda
        for (int i = 0; i < width - 1; i++) {
            if (board[row][i] != '.' && board[row][i + 1] == '.') {
                // Mueve la ficha una casilla a la izquierda
                board[row][i + 1] = board[row][i];
                board[row][i] = '.';
                break; // Solo mover una ficha en esa fila
            }
        }
    }
}

// Método para mover las fichas hacia la derecha (una casilla por fila)
public void tiltRight() {
    for (int row = 0; row < height; row++) {
        // Iterar por cada fila y mover las fichas hacia la derecha
        for (int i = width - 1; i > 0; i--) {
            if (board[row][i] != '.' && board[row][i - 1] == '.') {
                // Mueve la ficha una casilla a la derecha
                board[row][i - 1] = board[row][i];
                board[row][i] = '.';
                break; // Solo mover una ficha en esa fila
            }
        }
    }
}

// Método para mover las fichas hacia arriba (una casilla por columna)
public void tiltUp() {
    for (int col = 0; col < width; col++) {
        // Iterar por cada columna y mover las fichas hacia arriba
        for (int i = 0; i < height - 1; i++) {
            if (board[i][col] != '.' && board[i + 1][col] == '.') {
                // Mueve la ficha una casilla hacia arriba
                board[i + 1][col] = board[i][col];
                board[i][col] = '.';
                break; // Solo mover una ficha en esa columna
            }
        }
    }
}

// Método para mover las fichas hacia abajo (una casilla por columna)
public void tiltDown() {
    for (int col = 0; col < width; col++) {
        // Iterar por cada columna y mover las fichas hacia abajo
        for (int i = height - 1; i > 0; i--) {
            if (board[i][col] != '.' && board[i - 1][col] == '.') {
                // Mueve la ficha una casilla hacia abajo
                board[i - 1][col] = board[i][col];
                board[i][col] = '.';
                break; // Solo mover una ficha en esa columna
            }
        }
    }
}

    // Método para calcular el puntaje (ejemplo simple)
    public int score() {
        int score = 0;
        for (int i = 0; i < height; i++) {
            for (int j = 0; j < width; j++) {
                if (board[i][j] == 'X') {
                    score++; // Incrementa por cada celda ocupada
                }
            }
        }
        return score;
    }

    // Método para obtener el número de inclinaciones realizadas
    public int tiltings() {
        return tiltings;
    }

    // Método para obtener el estado del tablero
    public char[][] board() {
        return board;
    }


}
