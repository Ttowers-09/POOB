

import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * The test class RelationTest.
 *
 * @author  CIS
 * @version 2024-2
 */
public class RelationTest
{
    private RelationalCalculator calc;
    
    
    /**
     * Default constructor for test class RelationTest
     */
    public RelationTest(){
    }

    /**
     * Sets up the test fixture.
     * Called before every test case method.
     */
    @Before
    public void setUp(){
        calc = new RelationalCalculator();
    }


    @Test
    public void shouldCreateAValidRelation(){
        String [] attributes={"song", "artist", "album", "year"};
        Relation songs= new Relation(attributes);
        assertEquals(songs.columns(),4);
        assertEquals(songs.tuples(),0);
    }    
    
    @Test
    public void shouldCreateAEmptyRelationIfError(){
        String [] attributes={"song", "artist", "song", "year"};
        Relation songs= new Relation(attributes);
        assertEquals(songs.columns(),0);
        assertEquals(songs.tuples(),0);
    }     
    

    @Test
    public void shouldInsertTuples(){
        String [] attributes={"song", "artist", "album", "year"};
        String [] acrostico={"Acróstico", "Shakira", "Las mujeres ya no lloran", "2023"};
        String [] negra={"La Camisa Negra", "Juanes", "Mi Sangre", "2004"};   
        Relation songs= new Relation(attributes);
        songs.insert(acrostico);
        assertEquals(songs.columns(),4);
        assertEquals(songs.tuples(),1);
    } 
    
    @Test
    public void shouldNotInsertInvalidTuples(){
        String [] attributes={"song", "artist", "album", "year"};
        String [] acrostico={"Acrostico", "Shakira", "Las Mujeres Ya No Lloran", "2023"};
        String [] negra={"La Camisa Negra", "Juanes", "Mi Sangre"};
        Relation songs= new Relation(attributes);
        songs.insert(acrostico);
        assertEquals(songs.columns(),4);
        assertEquals(songs.tuples(),1);
    }     
    

    @Test
    public void shouldNotInsertRepeatedTuples(){
        String [] attributes={"song", "artist", "album", "year"};
        String [] acrostico={"Acrostico", "Shakira", "Las Mujeres Ya No Lloran", "2023"};
        String [] ocrostico={"ACROSTICO", "SHAKIRA", "Las Mujeres Ya No Lloran", "2023"};
        Relation songs= new Relation(attributes);
        songs.insert(acrostico);
        songs.insert(ocrostico);        
        assertEquals(songs.columns(),4);
        assertEquals(songs.tuples(),1);
    }    
    
    // Mini Ciclo 1

    @Test
    public void shouldAssignAndRetrieveRelation() {
        String[] attributes = {"song", "artist", "album", "year"};
        calc.asignacion("Songs", attributes);

        Relation relation = calc.getRelation("Songs");

        assertNotNull(relation); // Verifica que la relación no sea nula
        assertEquals(4, relation.columns()); // Verifica el número de columnas
        assertEquals(0, relation.tuples()); // Verifica que no haya tuplas aún
    }

    @Test
    public void shouldReturnNullForNonExistentRelation() {
        Relation relation = calc.getRelation("NonExistent");

        assertNull(relation); // Verifica que la relación no existe
    }

    @Test
    public void shouldPrintRelation() {
        String[] attributes = {"song", "artist", "album", "year"};
        calc.asignacion("Songs", attributes);

        calc.printRelation("Songs");
    }

    
    
    // Mini Ciclo 2
    @Test
    public void shouldInsertTuple() {
        String[] attributes = {"song", "artist", "album", "year"};
        calc.asignacion("Songs", attributes);

        String[] tuple = {"Acróstico", "Shakira", "Las mujeres ya no lloran", "2023"};
        calc.update("Songs", 'i', tuple);

        Relation relation = calc.getRelation("Songs");

        assertNotNull(relation); 
        assertEquals(1, relation.tuples()); 
    }

    @Test
    public void shouldNotInsertInvalidTuple() {
        String[] attributes = {"song", "artist", "album", "year"};
        calc.asignacion("Songs", attributes);

        // Tupla con número incorrecto de atributos
        String[] invalidTuple = {"Acrostico", "Shakira", "Las Mujeres Ya No Lloran"};
        calc.update("Songs", 'i', invalidTuple);

        Relation relation = calc.getRelation("Songs");

        assertNotNull(relation); // Verifica que la relación no sea nula
        assertEquals(0, relation.tuples()); // Verifica que no se haya insertado la tupla inválida
    }

    @Test
    public void shouldDeleteTuple() {
        String[] attributes = {"song", "artist", "album", "year"};
        calc.asignacion("Songs", attributes);

        // Insertar una tupla antes de eliminarla
        String[] tuple = {"Acróstico", "Shakira", "Las mujeres ya no lloran", "2023"};
        calc.update("Songs", 'i', tuple);

        // Eliminar la tupla
        calc.update("Songs", 'd', tuple);

        Relation relation = calc.getRelation("Songs");

        assertNotNull(relation); // Verifica que la relación no sea nula
        assertEquals(0, relation.tuples()); // Verifica que la tupla haya sido eliminada
    }

    @Test
    public void shouldNotDeleteNonExistentTuple() {
        String[] attributes = {"song", "artist", "album", "year"};
        calc.asignacion("Songs", attributes);

        // Tupla que no ha sido insertada
        String[] nonExistentTuple = {"Non-existent Song", "Unknown Artist", "Unknown Album", "2024"};
        calc.update("Songs", 'd', nonExistentTuple);

        Relation relation = calc.getRelation("Songs");

        assertNotNull(relation); 
        assertEquals(0, relation.tuples()); 
    }

    
    
    
    /**
     * Tears down the test fixture.
     *
     * Called after every test case method.
     */
    @After
    public void tearDown(){
    }
    
}
