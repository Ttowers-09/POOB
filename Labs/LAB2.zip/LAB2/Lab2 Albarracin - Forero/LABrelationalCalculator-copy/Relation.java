import java.util.*;

/**
 * Ivan F. Torres
 * Sebastian Albarracin Silva
 */

public class Relation {

    // Array de nombres de atributos para esta relación
    private String[] attributes;
    // Lista de tuplas en la relación
    private List<String[]> tuples;
    // Bandera que indica el éxito de la última operación
    private boolean ok;

    /**
     * Construye una relación con los atributos especificados.
     * La relación es válida si todos los nombres de atributos son únicos.
     *
     * @param attributes un array de nombres de atributos
     */
    public Relation(String[] attributes) {
        // Asegura que los atributos sean únicos
        Set<String> uniqueAttributes = new HashSet<>(Arrays.asList(attributes));
        if (uniqueAttributes.size() == attributes.length) {
            this.attributes = attributes;
            this.tuples = new ArrayList<>();
            this.ok = true;
        } else {
            this.attributes = new String[0];
            this.tuples = new ArrayList<>();
            this.ok = false;
        }
    }

    /**
     * Inserta una tupla en la relación si es válida y no está ya presente.
     *
     * @param tuple un array que representa la tupla a insertar
     * @return la instancia actual de Relation para encadenar métodos
     */
    public Relation insert(String[] tuple) {
        // Verifica que la longitud de la tupla coincida con el número de atributos y evita duplicados
        if (tuple.length == this.attributes.length && !in(tuple)) {
            this.tuples.add(tuple);
            this.ok = true;
        } else {
            this.ok = false;
        }
        return this;
    }

    /**
     * Devuelve el número de columnas (atributos) en la relación.
     *
     * @return el número de columnas
     */
    public int columns() {
        return this.attributes.length;
    }

    /**
     * Devuelve el número de tuplas actualmente en la relación.
     *
     * @return el número de tuplas
     */
    public int tuples() {
        return this.tuples.size();
    }

    /**
     * Devuelve el array de nombres de atributos de la relación.
     *
     * @return un array de nombres de atributos
     */
    public String[] attributes() {
        return this.attributes;
    }

    /**
     * Verifica si la tupla especificada ya está presente en la relación.
     *
     * @param tuple un array que representa la tupla a verificar
     * @return true si la tupla está presente, false en caso contrario
     */
    public boolean in(String[] tuple) {
        for (String[] t : this.tuples) {
            if (compareTuples(t, tuple)) {
                return true;
            }
        }
        return false;
    }

    /**
     * Compara dos tuplas para verificar su igualdad, ignorando diferencias de mayúsculas y minúsculas.
     *
     * @param tuple1 la primera tupla
     * @param tuple2 la segunda tupla
     * @return true si las tuplas son iguales (sin considerar mayúsculas/minúsculas), false en caso contrario
     */
    private boolean compareTuples(String[] tuple1, String[] tuple2) {
        if (tuple1.length != tuple2.length) {
            return false;
        }
        for (int i = 0; i < tuple1.length; i++) {
            if (!tuple1[i].equalsIgnoreCase(tuple2[i])) {
                return false;
            }
        }
        return true;
    }

    /**
     * Verifica si esta relación es igual a otro objeto.
     * Dos relaciones se consideran iguales si tienen los mismos atributos y tuplas.
     *
     * @param other el objeto con el que comparar
     * @return true si el objeto es una instancia de Relation y es igual a esta instancia, false en caso contrario
     */
    @Override
    public boolean equals(Object other) {
        if (this == other) return true;
        if (!(other instanceof Relation)) return false;
        Relation otherRelation = (Relation) other;
        return Arrays.equals(this.attributes, otherRelation.attributes) &&
               this.tuples.equals(otherRelation.tuples);
    }

    /**
     * Devuelve una representación en cadena de la relación.
     * La salida incluye primero los nombres de los atributos seguidos por las tuplas.
     *
     * @return una representación en cadena de la relación
     */
    @Override
    public String toString() {
        StringBuilder result = new StringBuilder();
        result.append(String.join(", ", attributes)).append("\n");
        for (String[] tuple : tuples) {
            result.append(String.join(", ", tuple)).append("\n");
        }
        return result.toString();
    }
    
    //eliminar una tupla
    public void delete(String[] tuple) {
        // Eliminamos la tupla si coincide con una de las existentes
        tuples.removeIf(existingTuple -> Arrays.equals(existingTuple, tuple));
    }
}