import static org.junit.Assert.*; // Importamos las funciones de aserción de JUnit
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * Clase de prueba para la clase Relation.
 * En esta clase probamos varias funcionalidades de la calculadora relacional y la clase Relation.
 *
 * @author  CIS
 * @version 2024-2
 */
public class RelationTest {
    // Instancia de la calculadora relacional para realizar pruebas.
    private RelationalCalculator calc;

    /**
     * Constructor por defecto de la clase de prueba RelationTest.
     * No hace nada en particular, pero es necesario para crear una instancia de la clase de prueba.
     */
    public RelationTest() {
    }

    // --- Casos de prueba punto 5 ---

    /** Prueba para un caso que debe pasar exitosamente.
     * Aquí estamos verificando si 5 es mayor que 3, lo cual siempre será cierto.
     */
    @Test
    public void shouldPass() {
        assertTrue(5 > 3); // Verificamos que 5 sea mayor que 3
    }

    /** Prueba que debería fallar.
     * Intentamos verificar que 5 sea igual a 3, lo cual no es cierto, por lo que fallará.
     */
    @Test
    public void shouldFail() {
        assertEquals(5, 3); // Esto fallará porque 5 no es igual a 3
    }

    /** Prueba que producirá un error.
     * Intentamos acceder a un índice fuera de los límites del array, lo que generará una excepción.
     */
    @Test
    public void shouldError() {
        int[] numbers = {1, 2, 3, 4, 5, 6};
        int numberNeed = numbers[145]; // Esto causará un ArrayIndexOutOfBoundsException
    }

    // --- Configuración antes de cada prueba ---

    /** Configuración del entorno de prueba.
     * Este método se ejecuta antes de cada prueba para inicializar el objeto `calc`.
     */
    @Before
    public void setUp() {
        calc = new RelationalCalculator(); // Inicializamos la calculadora relacional
    }

    // --- Casos de prueba para la clase Relation ---

    /** Prueba para crear una relación válida.
     * Verificamos que se pueda crear una relación con los atributos especificados y que tenga 0 tuplas inicialmente.
     */
    @Test
    public void shouldCreateAValidRelation() {
        String[] attributes = {"song", "artist", "album", "year"};
        Relation songs = new Relation(attributes); // Creamos una nueva relación con los atributos dados
        assertEquals(songs.columns(), 4); // Verificamos que tenga 4 columnas
        assertEquals(songs.tuples(), 0); // Verificamos que no tenga tuplas al inicio
    }

    /** Prueba para manejar errores al crear una relación.
     * Verificamos que si se crean atributos duplicados, la relación no sea válida y tenga 0 columnas.
     */
    @Test
    public void shouldCreateAEmptyRelationIfError() {
        String[] attributes = {"song", "artist", "song", "year"}; // Aquí hay atributos duplicados
        Relation songs = new Relation(attributes);
        assertEquals(songs.columns(), 0); // La relación no debe tener columnas
        assertEquals(songs.tuples(), 0); // Tampoco debe tener tuplas
    }

    /** Prueba para insertar tuplas en una relación válida.
     * Verificamos que al insertar una tupla válida, se agregue correctamente a la relación.
     */
    @Test
    public void shouldInsertTuples() {
        String[] attributes = {"song", "artist", "album", "year"};
        String[] acrostico = {"Acróstico", "Shakira", "Las mujeres ya no lloran", "2023"};
        Relation songs = new Relation(attributes);
        songs.insert(acrostico); // Insertamos la tupla
        assertEquals(songs.columns(), 4); // Verificamos que la relación tenga 4 columnas
        assertEquals(songs.tuples(), 1); // Verificamos que ahora tenga 1 tupla
    }

    /** Prueba para evitar insertar tuplas inválidas.
     * Verificamos que no se pueda insertar una tupla que no coincida con el número de columnas de la relación.
     */
    @Test
    public void shouldNotInsertInvalidTuples() {
        String[] attributes = {"song", "artist", "album", "year"};
        String[] acrostico = {"Acrostico", "Shakira", "Las Mujeres Ya No Lloran", "2023"};
        String[] negra = {"La Camisa Negra", "Juanes", "Mi Sangre"}; // Tupla con menos columnas
        Relation songs = new Relation(attributes);
        songs.insert(acrostico);
        assertEquals(songs.columns(), 4); // Verificamos que la relación siga teniendo 4 columnas
        assertEquals(songs.tuples(), 1); // Solo se debió insertar 1 tupla válida
    }

    /** Prueba para evitar la inserción de tuplas duplicadas.
     * Verificamos que al intentar insertar una tupla duplicada (con el mismo valor), no se agregue a la relación.
     */
    @Test
    public void shouldNotInsertRepeatedTuples() {
        String[] attributes = {"song", "artist", "album", "year"};
        String[] acrostico = {"Acrostico", "Shakira", "Las Mujeres Ya No Lloran", "2023"};
        String[] ocrostico = {"ACROSTICO", "SHAKIRA", "Las Mujeres Ya No Lloran", "2023"}; // Tupla duplicada
        Relation songs = new Relation(attributes);
        songs.insert(acrostico);
        songs.insert(ocrostico);        
        assertEquals(songs.columns(), 4);
        assertEquals(songs.tuples(), 1); // Solo debe haber 1 tupla, ya que la segunda es un duplicado
    }

    // --- Mini Ciclo 1: Pruebas de la calculadora relacional ---

    /** Prueba para asignar y recuperar una relación.
     * Verificamos que se pueda asignar una relación a una variable y luego recuperarla.
     */
    @Test
    public void shouldAssignAndRetrieveRelation() {
        String[] attributes = {"song", "artist", "album", "year"};
        calc.asignacion("Songs", attributes); // Asignamos una nueva relación a "Songs"

        Relation relation = calc.getRelation("Songs");
        assertNotNull(relation); // Verificamos que la relación no sea nula
        assertEquals(4, relation.columns()); // Verificamos el número de columnas
        assertEquals(0, relation.tuples()); // Verificamos que no haya tuplas aún
    }

    /** Prueba para manejar relaciones no existentes.
     * Verificamos que al intentar obtener una relación que no existe, el resultado sea `null`.
     */
    @Test
    public void shouldReturnNullForNonExistentRelation() {
        Relation relation = calc.getRelation("NonExistent");
        assertNull(relation); // La relación no debe existir
    }

    /** Prueba para imprimir una relación.
     * Verificamos que se pueda imprimir correctamente una relación asignada.
     */
    @Test
    public void shouldPrintRelation() {
        String[] attributes = {"song", "artist", "album", "year"};
        calc.asignacion("Songs", attributes);
        calc.printRelation("Songs"); // Esto debería imprimir la relación en la consola
    }

    // --- Mini Ciclo 2: Actualización de relaciones ---

    /** Prueba para insertar una tupla en una relación.
     * Verificamos que se pueda insertar una tupla válida en una relación.
     */
    @Test
    public void shouldInsertTuple() {
        String[] attributes = {"song", "artist", "album", "year"};
        calc.asignacion("Songs", attributes);

        String[] tuple = {"Acróstico", "Shakira", "Las mujeres ya no lloran", "2023"};
        calc.update("Songs", 'i', tuple); // Insertamos la tupla en la relación

        Relation relation = calc.getRelation("Songs");
        assertNotNull(relation);
        assertEquals(1, relation.tuples()); // Verificamos que la tupla se haya insertado
    }

    /** Prueba para evitar insertar una tupla inválida.
     * Verificamos que no se pueda insertar una tupla con un número incorrecto de atributos.
     */
    @Test
    public void shouldNotInsertInvalidTuple() {
        String[] attributes = {"song", "artist", "album", "year"};
        calc.asignacion("Songs", attributes);

        String[] invalidTuple = {"Acrostico", "Shakira", "Las Mujeres Ya No Lloran"}; // Falta un atributo
        calc.update("Songs", 'i', invalidTuple);

        Relation relation = calc.getRelation("Songs");
        assertNotNull(relation); 
        assertEquals(0, relation.tuples()); // La tupla no debería insertarse
    }

    /** Prueba para eliminar una tupla.
     * Verificamos que se pueda eliminar una tupla de la relación.
     */
    @Test
    public void shouldDeleteTuple() {
        String[] attributes = {"song", "artist", "album", "year"};
        calc.asignacion("Songs", attributes);

        String[] tuple = {"Acróstico", "Shakira", "Las mujeres ya no lloran", "2023"};
        calc.update("Songs", 'i', tuple); // Insertamos la tupla

        calc.update("Songs", 'd', tuple); // La eliminamos

        Relation relation = calc.getRelation("Songs");
        assertNotNull(relation);
        assertEquals(0, relation.tuples()); // Verificamos que la tupla se haya eliminado
    }

    /** Prueba para evitar la eliminación de una tupla no existente.
     * Verificamos que no se pueda eliminar una tupla que no ha sido previamente insertada.
     */
    @Test
    public void shouldNotDeleteNonExistentTuple() {
        String[] attributes = {"song", "artist", "album", "year"};
        calc.asignacion("Songs", attributes);

        String[] nonExistentTuple = {"Non-existent Song", "Unknown Artist", "Unknown Album", "2024"};
        calc.update("Songs", 'd', nonExistentTuple); // Intentamos eliminar una tupla que no existe

        Relation relation = calc.getRelation("Songs");
        assertNotNull(relation); 
        assertEquals(0, relation.tuples()); // No debería haber cambios
    }

    // --- Limpieza después de cada prueba ---

    /** Método que se ejecuta después de cada prueba.
     * Aquí podríamos limpiar o reiniciar variables si fuera necesario.
     */
    @After
    public void tearDown() {
    }
}
