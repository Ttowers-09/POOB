import java.util.TreeMap;

/** Relational Calculator
 * Esta es la clase principal que modela una calculadora de relaciones.
 * La calculadora almacena variables de tipo `Relation`, que representan tablas de datos.
 * Utiliza un `TreeMap` para guardar las variables y las operaciones se basan en la manipulación
 * y consulta de estas relaciones.
 * 
 * @author CIS 2024-02
 */
public class RelationalCalculator {
    
    // TreeMap para almacenar las variables. Cada variable es de tipo `Relation`.
    private TreeMap<String, Relation> variables;

    // --- Mini Ciclo 1 ---
    /** Constructor de la clase RelationalCalculator
     * Inicializa el TreeMap para almacenar las variables.
     */
    public RelationalCalculator(){
        // Inicializamos el TreeMap que contendrá las variables.
        variables = new TreeMap<>();
    }

    /** Método para asignar una relación a una variable.
     * @param name El nombre de la variable.
     * @param attributes Los atributos (columnas) de la relación que se va a asignar.
     */
    public void asignacion(String name, String[] attributes) {
        // Usamos el método `put` del TreeMap para asignar una nueva relación.
        variables.put(name, new Relation(attributes));
    }

    /** Método para obtener una relación almacenada en una variable.
     * @param name El nombre de la variable a consultar.
     * @return La relación asociada al nombre dado, o null si no existe.
     */
    public Relation getRelation(String name) {
        // Recuperamos la relación usando el nombre de la variable.
        return variables.get(name);
    }

    /** Método para imprimir una relación en la consola.
     * @param name El nombre de la variable cuya relación se va a imprimir.
     */
    public void printRelation(String name) {
        // Obtenemos la relación correspondiente a la variable.
        Relation relation = variables.get(name);
        
        // Si la relación existe, la imprimimos.
        if (relation != null) {
            System.out.println(relation);
        }
    }
    
    // --- Mini Ciclo 2 ---
    /** Método para actualizar una relación utilizando operaciones unarias.
     * @param a El nombre de la variable a actualizar.
     * @param unary El operador unario ('i' para insertar, 'd' para eliminar).
     * @param tuple La tupla (fila de datos) que se va a insertar o eliminar.
     */
    public void update(String a, char unary, String[] tuple) {
        // Obtenemos la relación a partir del nombre de la variable.
        Relation relation = variables.get(a);
        
        // Si la relación existe, aplicamos la operación unaria.
        if (relation != null) {
            switch (unary) {
                case 'i':  // Insertar una nueva tupla en la relación.
                    relation.insert(tuple);
                    break;
                case 'd':  // Eliminar una tupla de la relación.
                    relation.delete(tuple);
                    break;
                default:
                    // Si se ingresa un operador no válido, mostramos un mensaje de error.
                    System.out.println("Operador no válido.");
            }
        }
    }

    // --- Mini Ciclo 3 ---
    /** Asigna una relación vacía a una variable.
     * @param name El nombre de la variable.
     * @param attributes Los atributos de la nueva relación vacía.
     */
    public void assign(String name, String attributes[] ) {
        // Este método podría definir una nueva relación vacía.
    }    

    /** Método para asignar el resultado de una operación binaria entre relaciones.
     * @param a El nombre de la variable que recibirá el resultado.
     * @param b El nombre de la primera relación.
     * @param operator El operador binario ('p' para proyectar, 's' para seleccionar, 'm' para multiplicar).
     * @param c El nombre de la segunda relación, que se usará según el operador.
     */
    public void assign(String a, String b, char operator, String c) {
        // Aquí se implementarían las operaciones de proyección, selección y multiplicación.
    }

    /** Método para consultar los nombres de las variables almacenadas.
     * @return Un arreglo de cadenas con los nombres de las variables.
     */
    public String[] variables() {
        // Aquí devolveríamos los nombres de las variables almacenadas.
        return null;
    }

    /** Método para obtener una representación de cadena de una relación.
     * @param variable El nombre de la variable cuya relación se va a convertir en cadena.
     * @return Una cadena que representa la relación (las columnas deben estar alineadas).
     */
    public String toString(String variable) {
        // Aquí devolveríamos una representación en cadena de la relación.
        return null;
    }

    /** Método para verificar si la última operación fue exitosa.
     * @return true si la última operación fue exitosa, false en caso contrario.
     */
    public boolean ok() {
        // Aquí verificaríamos si la última operación fue exitosa.
        return false;
    }
}
