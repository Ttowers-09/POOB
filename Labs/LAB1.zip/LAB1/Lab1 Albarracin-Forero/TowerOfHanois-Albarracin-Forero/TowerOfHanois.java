import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

public class TowerOfHanois extends JPanel {
    private ArrayList<Integer>[] diskSizes;
    private ArrayList<Color>[] diskColors;
    private int[] towerXPositions = {100, 300, 500};
    private int y = 400;
    private static final int DISK_HEIGHT = 20;
    private static final int BASE_HEIGHT = 10;
    private int selectedTower = -1;
    private JFrame frame;

    public TowerOfHanois(int maxDisks) {
        this.diskSizes = new ArrayList[3];
        this.diskColors = new ArrayList[3];

        for (int i = 0; i < 3; i++) {
            diskSizes[i] = new ArrayList<>();
            diskColors[i] = new ArrayList<>();
        }

        this.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                handleTowerSelection(e.getX());
            }
        });

        push(maxDisks, 0);
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        drawBase(g);
        drawDisks(g);
    }

    private void drawBase(Graphics g) {
        g.setColor(Color.DARK_GRAY);
        for (int i = 0; i < 3; i++) {
            g.fillRect(towerXPositions[i] - 120, y, 240, BASE_HEIGHT);
            g.fillRect(towerXPositions[i] - 10, y - 200, 20, 200);
        }
    }

    private void drawDisks(Graphics g) {
        for (int t = 0; t < 3; t++) {
            for (int i = 0; i < diskSizes[t].size(); i++) {
                g.setColor(diskColors[t].get(i));
                g.fillRect(towerXPositions[t] - diskSizes[t].get(i) / 2,
                           y - (diskSizes[t].size() - i) * DISK_HEIGHT - BASE_HEIGHT,
                           diskSizes[t].get(i), DISK_HEIGHT);
            }
        }
    }

    public void makeVisible() {
        frame = new JFrame("Tower of Hanoi");
        frame.add(this);
        frame.setSize(700, 500);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }

    public void makeInvisible() {
        if (frame != null) {
            frame.setVisible(false);
            frame.dispose();
        }
    }

    public void moveDisk(int fromTower, int toTower) {
        if (isValidMove(fromTower, toTower)) {
            int diskSize = diskSizes[fromTower].remove(diskSizes[fromTower].size() - 1);
            Color diskColor = diskColors[fromTower].remove(diskColors[fromTower].size() - 1);
            diskSizes[toTower].add(diskSize);
            diskColors[toTower].add(diskColor);
            repaint();
        } else {
            displayError("Movimiento inválido. No se puede colocar un disco grande sobre uno pequeño.");
        }
    }

    private boolean isValidMove(int fromTower, int toTower) {
        if (diskSizes[fromTower].isEmpty()) {
            return false;
        }
        if (diskSizes[toTower].isEmpty()) {
            return true;
        }
        return diskSizes[fromTower].get(diskSizes[fromTower].size() - 1) <
               diskSizes[toTower].get(diskSizes[toTower].size() - 1);
    }

    private void displayError(String message) {
        JOptionPane.showMessageDialog(this, message, "Error", JOptionPane.ERROR_MESSAGE);
    }

    private void handleTowerSelection(int mouseX) {
        int clickedTower = -1;
        for (int i = 0; i < 3; i++) {
            if (Math.abs(mouseX - towerXPositions[i]) < 60) {
                clickedTower = i;
                break;
            }
        }

        if (clickedTower != -1) {
            if (selectedTower == -1) {
                selectedTower = clickedTower;
            } else {
                moveDisk(selectedTower, clickedTower);
                selectedTower = -1;
            }
        }
    }

    public void push(int count, int towerIndex) {
        if (count + diskSizes[towerIndex].size() > 20) {
            displayError("No se pueden agregar más de 20 discos en total.");
            return;
        }
        for (int i = 0; i < count; i++) {
            diskSizes[towerIndex].add(60 + (diskSizes[towerIndex].size() * 20));
            diskColors[towerIndex].add(getRandomColor());
        }
        repaint();
    }

    public void pop(int count, int towerIndex) {
        if (count > diskSizes[towerIndex].size()) {
            displayError("No hay suficientes discos para eliminar.");
            count = diskSizes[towerIndex].size();
        }

        for (int i = 0; i < count; i++) {
            diskSizes[towerIndex].remove(diskSizes[towerIndex].size() - 1);
            diskColors[towerIndex].remove(diskColors[towerIndex].size() - 1);
        }
        repaint();
    }

    private Color getRandomColor() {
        Color[] colors = {Color.RED, Color.YELLOW, Color.BLUE, Color.GREEN, Color.MAGENTA, Color.BLACK};
        int index = (int) (Math.random() * colors.length);
        return colors[index];
    }

    public static void main(String[] args) {
        TowerOfHanois tower = new TowerOfHanois(9);
        tower.makeVisible();
    }
}
