package UnitTest;


import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import java.awt.Color;

import domain.AManufacturing;
import domain.HorizontalKiller;
import domain.Cell;
import domain.Poison;

public class PoisonTest {
    private AManufacturing am; // Supongamos que ya tienes un objeto AManufacturing
    private Poison poison;

    @Before
    public void setUp() {
        // Inicializamos el objeto AManufacturing y la celda Poison antes de cada test.
        am = new AManufacturing(); // Inicializa tu objeto AManufacturing
        poison = new Poison(am, 0, 0); // Crea una celda Poison en la posición (0,0)
    }

    @Test
    public void testChangeColorCyclically() {
        Color initialColor = poison.color; // Color inicial

        // Llamamos a change varias veces y comprobamos que el color cambia.
        for (int i = 0; i < Poison.listaColores.length; i++) {
            poison.change(); // Cambia el estado y el color de la celda

            // Verifica que el color es el esperado
            assertEquals(Poison.listaColores[(i + 1) % Poison.listaColores.length], poison.color);
        }
    }

}
