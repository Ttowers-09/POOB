package UnitTest;


import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import domain.AManufacturing;
import domain.HorizontalKiller;
import domain.Cell;

/**
 * Clase de prueba para la clase HorizontalKiller.
 * Utiliza el framework JUnit para realizar pruebas unitarias.
 */
public class HorizontalKillerTest {
    private AManufacturing am; // Tablero de AManufacturing
    private HorizontalKiller hk; // Célula HorizontalKiller

    /**
     * Configuración inicial antes de cada prueba.
     * Se crea una nueva instancia de AManufacturing y una de HorizontalKiller.
     */
    @Before
    public void setUp() {
        am = new AManufacturing(); 
        hk = new HorizontalKiller(am, 2, 3, true); // Inicializa HorizontalKiller en la posición (2, 3)
        am.setThing(2, 3, hk); // Añade HorizontalKiller al tablero en la posición especificada
    }

    /**
     * Prueba que verifica si el método move() de HorizontalKiller
     * elimina otra célula en la posición adyacente.
     */
    @Test
    public void testEliminateOtherCell() {
        Cell prueba = new Cell(am, 2, 2, true); // Crea una nueva célula en (2, 2)
        am.setThing(2, 2, prueba); // Añade la célula al tablero
        hk.move(); // Llama al método move() de HorizontalKiller
        assertNull(am.getThing(2, 3)); // Verifica que la posición (2, 3) ahora está vacía
    }
    
    /**
     * Prueba que verifica el movimiento de HorizontalKiller
     * y su cambio de posición en el tablero.
     */
    @Test
    public void testMovement(){
        hk.move(); // Llama al método move() de HorizontalKiller
        // Verifica que la posición de HorizontalKiller ha cambiado correctamente
        assertEquals(2, hk.row); // La fila debe permanecer igual
        assertEquals(4, hk.column); // La columna debe haber cambiado a 4
        assertEquals(hk, am.getThing(2, 4)); // Verifica que ahora está en la posición (2, 4)
    }
}
