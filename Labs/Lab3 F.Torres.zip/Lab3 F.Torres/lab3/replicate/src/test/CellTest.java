package UnitTest;

import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;
import java.awt.Color;
import domain.Cell; // Cambiado para importar tu propia clase Cell
import domain.AManufacturing;
import domain.Artefact;

public class CellTest {
    private AManufacturing mockManufacturing; // Suponiendo que tienes un mock o una implementación de prueba
    private Cell cell; // Declaración de la variable cell

    @Before
    public void setUp() {
        mockManufacturing = new AManufacturing(); // Inicializa el entorno de manufactura (puedes usar un mock)
        cell = new Cell(mockManufacturing, 1, 1, true); // Crea una celda activa en la posición (1, 1)
    }


    @Test
    public void testObtenerColor() {
        assertEquals(Color.black, cell.getColor()); // Verifica que el color inicial sea negro
    }

    @Test
    public void testDecidirConPasosPares() {
        // Simular pasos
        cell.step(); // Supongamos que el método step incrementa el número de pasos
        cell.step(); // Ahora debería ser par
        cell.decide(); // Decide el siguiente estado
        assertEquals(Artefact.ACTIVE, cell.nextState); // Verifica que el próximo estado sea activo
    }

    @Test
    public void testDecidirConPasosImpares() {
        // Simular pasos
        cell.step(); // Supongamos que el método step incrementa el número de pasos
        cell.decide(); // Decide el siguiente estado
        assertEquals(Artefact.INACTIVE, cell.nextState); // Verifica que el próximo estado sea inactivo
    }


}
