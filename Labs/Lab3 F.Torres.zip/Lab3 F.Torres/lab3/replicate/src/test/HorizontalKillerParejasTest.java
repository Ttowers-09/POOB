package UnitTest;

import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;


import domain.AManufacturing;
import domain.HorizontalKiller;
import domain.Cell;

/**
 * Clase de prueba para la interacción entre dos instancias de HorizontalKiller.
 * Utiliza el framework JUnit para realizar pruebas unitarias.
 */
public class HorizontalKillerParejasTest {
    private AManufacturing am; // Tablero de AManufacturing
    private HorizontalKiller ivan; // Célula HorizontalKiller de Iván
    private HorizontalKiller santiago; // Célula HorizontalKiller de Santiago

    /**
     * Configuración inicial antes de cada prueba.
     * Se crean nuevas instancias de AManufacturing y dos de HorizontalKiller.
     */
    @Before
    public void setUp() {
        am = new AManufacturing(); 
        ivan = new HorizontalKiller(am, 3, 3, true); // Inicializa HorizontalKiller de Iván en la posición (3, 3)
        santiago = new HorizontalKiller(am, 1, 5, true); // Inicializa HorizontalKiller de Santiago en la posición (1, 5)

        am.setThing(3, 3, ivan); // Añade HorizontalKiller de Iván al tablero
        am.setThing(1, 5, santiago); // Añade HorizontalKiller de Santiago al tablero
    }

    /**
     * Prueba que verifica si ambos HorizontalKiller eliminan correctamente 
     * otras celdas en sus respectivas posiciones después de múltiples movimientos.
     */
    @Test
    public void pruebasPareja() {
        int n = 0; // Contador para el número de movimientos
        Cell prueba2 = new Cell(am, 3, 2, true); // Crea una nueva célula en (3, 2)
        Cell prueba3 = new Cell(am, 1, 4, true); // Crea una nueva célula en (1, 4)

        // Añade las celdas de prueba al tablero
        am.setThing(3, 2, prueba2); 
        am.setThing(1, 4, prueba3); 

        // Realiza 100 movimientos de ambos HorizontalKiller
        while (n < 100) {
            ivan.move(); // Llama al método move() de HorizontalKiller de Iván
            santiago.move(); // Llama al método move() de HorizontalKiller de Santiago
            
            n++;
        }

        // Verifica que las posiciones de las celdas de prueba ahora están vacías
        assertNull(am.getThing(3, 2)); // Verifica que (3, 2) esté vacía
        assertNull(am.getThing(1, 4)); // Verifica que (1, 4) esté vacía
    }
}
