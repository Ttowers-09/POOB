package presentation;

import domain.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

/**
 * La clase AManufacturingGUI es una interfaz gráfica de usuario (GUI) que
 * permite interactuar con el sistema de manufactura celular. Proporciona
 * un botón para ejecutar la acción de "tic-tac" y representa gráficamente
 * el estado del sistema.
 */
public class AManufacturingGUI extends JFrame {
    public static final int SIDE = 11; // Tamaño de cada celda en píxeles

    public final int SIZE; // Tamaño de la rejilla
    private JButton ticTacButton; // Botón para ejecutar la acción de tic-tac
    private JPanel controlPanel; // Panel de control (actualmente no utilizado)
    private PhotoAManufacturing photo; // Componente gráfico que muestra el estado de la manufactura
    protected AManufacturing aManufacturing; // Objeto de manufactura que se está representando

    /**
     * Constructor de la clase AManufacturingGUI. Inicializa la interfaz gráfica
     * y el objeto de manufactura.
     */
    private AManufacturingGUI() {
        aManufacturing = new AManufacturing(); // Inicializa el sistema de manufactura
        SIZE = aManufacturing.getSize(); // Obtiene el tamaño de la rejilla
        prepareElements(); // Prepara los elementos gráficos
        prepareActions(); // Prepara las acciones para los eventos
    }

    /**
     * Prepara los elementos gráficos de la interfaz.
     */
    private void prepareElements() {
        setTitle("aManufacturing celular"); // Título de la ventana
        photo = new PhotoAManufacturing(this); // Inicializa el componente gráfico
        ticTacButton = new JButton("Tic-tac"); // Inicializa el botón tic-tac
        setLayout(new BorderLayout()); // Configura el layout
        add(photo, BorderLayout.NORTH); // Agrega el componente gráfico al norte
        add(ticTacButton, BorderLayout.SOUTH); // Agrega el botón al sur
        setSize(new Dimension(SIDE * SIZE + 15, SIDE * SIZE + 72)); // Establece el tamaño de la ventana
        setResizable(false); // La ventana no es redimensionable
        photo.repaint(); // Fuerza a repintar el componente gráfico
    }

    /**
     * Prepara las acciones para los eventos de la interfaz.
     */
    private void prepareActions() {
        setDefaultCloseOperation(EXIT_ON_CLOSE); // Acción al cerrar la ventana
        ticTacButton.addActionListener(new ActionListener() { // Añade un listener al botón
            public void actionPerformed(ActionEvent e) {
                ticTacButtonAction(); // Acción al pulsar el botón
            }
        });
    }

    /**
     * Acción que se ejecuta al pulsar el botón tic-tac.
     * Invoca el método ticTac del objeto de manufactura
     * y repinta el componente gráfico.
     */
    private void ticTacButtonAction() {
        aManufacturing.ticTac(); // Ejecuta el tic-tac
        photo.repaint(); // Repinta el componente gráfico
    }

    /**
     * Devuelve el objeto AManufacturing asociado a la interfaz.
     *
     * @return El objeto AManufacturing.
     */
    public AManufacturing getaManufacturing() {
        return aManufacturing; // Retorna el objeto de manufactura
    }

    /**
     * Método principal que inicia la aplicación.
     *
     * @param args Argumentos de la línea de comandos.
     */
    public static void main(String[] args) {
        AManufacturingGUI ca = new AManufacturingGUI(); // Crea una nueva instancia de la GUI
        ca.setVisible(true); // Hace visible la ventana
    }
}

/**
 * La clase PhotoAManufacturing es un componente gráfico que extiende JPanel
 * y se encarga de dibujar la rejilla de manufactura y sus componentes.
 */
class PhotoAManufacturing extends JPanel {
    private AManufacturingGUI gui; // Referencia a la GUI principal

    /**
     * Constructor de la clase PhotoAManufacturing.
     *
     * @param gui La instancia de AManufacturingGUI asociada.
     */
    public PhotoAManufacturing(AManufacturingGUI gui) {
        this.gui = gui; // Inicializa la referencia a la GUI
        setBackground(Color.white); // Establece el fondo blanco
        setPreferredSize(new Dimension(gui.SIDE * gui.SIZE + 10, gui.SIDE * gui.SIZE + 10)); // Establece el tamaño preferido
    }

    /**
     * Método que dibuja la rejilla y los componentes de manufactura.
     *
     * @param g El objeto Graphics utilizado para dibujar.
     */
    public void paintComponent(Graphics g) {
        AManufacturing aManufacturing = gui.getaManufacturing(); // Obtiene el objeto de manufactura
        super.paintComponent(g); // Llama al método paintComponent de JPanel

        // Dibuja las líneas de la rejilla
        for (int c = 0; c <= aManufacturing.getSize(); c++) {
            g.drawLine(c * gui.SIDE, 0, c * gui.SIDE, aManufacturing.getSize() * gui.SIDE);
        }
        for (int f = 0; f <= aManufacturing.getSize(); f++) {
            g.drawLine(0, f * gui.SIDE, aManufacturing.getSize() * gui.SIDE, f * gui.SIDE);
        }

        // Dibuja los componentes de manufactura
        for (int f = 0; f < aManufacturing.getSize(); f++) {
            for (int c = 0; c < aManufacturing.getSize(); c++) {
                if (aManufacturing.getThing(f, c) != null) { // Verifica si hay un componente en la celda
                    g.setColor(aManufacturing.getThing(f, c).getColor()); // Establece el color del componente
                    if (aManufacturing.getThing(f, c).shape() == Thing.SQUARE) {
                        // Dibuja un cuadrado si el componente es cuadrado
                        if (aManufacturing.getThing(f, c).isActive()) {
                            g.fillRoundRect(gui.SIDE * c + 1, gui.SIDE * f + 1, gui.SIDE - 2, gui.SIDE - 2, 2, 2);
                        } else {
                            g.drawRoundRect(gui.SIDE * c + 1, gui.SIDE * f + 1, gui.SIDE - 2, gui.SIDE - 2, 2, 2);
                        }
                    } else {
                        // Dibuja un círculo si el componente es circular
                        if (aManufacturing.getThing(f, c).isActive()) {
                            g.fillOval(gui.SIDE * c + 1, gui.SIDE * f + 1, gui.SIDE - 2, gui.SIDE - 2);
                        } else {
                            g.drawOval(gui.SIDE * c + 1, gui.SIDE * f + 1, gui.SIDE - 2, gui.SIDE - 2);
                        }
                    }
                }
            }
        }
    }
}
