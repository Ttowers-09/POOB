package domain;

import java.awt.Color;

/**
 * La clase TouristCell representa una celda de tipo turista dentro del sistema de manufactura.
 * Esta celda puede moverse hacia el centro de la rejilla cuando está activa y hacia los bordes
 * cuando está inactiva. Su color cambia según su estado.
 */
public class TouristCell extends Cell {
    
    // Atributos de la celda
    private String name; // Nombre de la celda (actualmente no se utiliza)
    private boolean canMove; // Indica si la celda puede moverse
    private AManufacturing AManufacturing; // Referencia al objeto AManufacturing

    /**
     * Constructor para crear una celda de tipo TouristCell.
     *
     * @param am El objeto AManufacturing que representa la rejilla.
     * @param row La fila donde se ubicará la celda.
     * @param column La columna donde se ubicará la celda.
     */
    public TouristCell(AManufacturing am, int row, int column) {
        super(am, row, column, true); // Inicializa la celda como activa
        this.AManufacturing = am;
        this.canMove = true; // Inicialmente puede moverse
        updateColor(); // Actualiza el color de la celda
    }

    /**
     * Actualiza el color de la celda en función de su estado.
     * La celda es naranja si está activa y amarilla si está inactiva.
     */
    private void updateColor() {
        this.color = isActive() ? Color.ORANGE : Color.YELLOW;
    }

    /**
     * Lógica de decisión para determinar el movimiento de la celda.
     * Si la celda está activa, se mueve hacia el centro de la rejilla.
     * Si está inactiva, se mueve hacia los bordes de la rejilla.
     */
    @Override
    public void decide() {
        super.decide(); // Llama al método decide de la clase padre

        int targetRow, targetColumn; // Variables para las coordenadas objetivo
        int center = AManufacturing.getSize() / 2; // Encuentra el centro de la rejilla

        // Determina la posición objetivo según el estado de la celda
        if (isActive()) {
            targetRow = center; // Mueve hacia el centro si está activa
            targetColumn = center;
        } else {
            targetRow = (row < center) ? 0 : AManufacturing.getSize() - 1; // Mueve hacia el borde
            targetColumn = (column < center) ? 0 : AManufacturing.getSize() - 1;
        }

        // Calcula el movimiento
        int dr = Integer.compare(targetRow, row);
        int dc = Integer.compare(targetColumn, column);
        int newRow = row + dr;
        int newColumn = column + dc;

        // Verifica si puede moverse a la nueva posición
        if (AManufacturing.isEmpty(newRow, newColumn)) {
            canMove = true; // Puede moverse
            row = newRow; // Actualiza la posición
            column = newColumn;
        } else {
            canMove = false; // No puede moverse
        }
    }

    /**
     * Cambia el estado de la celda y actualiza su color.
     * Si la celda puede moverse, actualiza su posición en la rejilla.
     */
    @Override
    public void change() {
        super.change(); // Llama al método change de la clase padre
        updateColor(); // Actualiza el color

        // Actualiza la rejilla si puede moverse
        if (canMove) {
            AManufacturing.setThing(row, column, this); // Establece la celda en la nueva posición
            AManufacturing.setThing(row - 1, column - 1, null); // Limpia la posición anterior
            AManufacturing.setThing(row, column - 1, null);
        }
    }

    /**
     * Devuelve el color actual de la celda.
     *
     * @return El color de la celda.
     */
    @Override
    public Color getColor() {
        return this.color; // Retorna el color de la celda
    }
}
