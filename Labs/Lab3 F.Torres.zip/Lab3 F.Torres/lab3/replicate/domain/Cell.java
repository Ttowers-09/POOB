package domain;

import java.awt.Color;

/**
 * Información sobre una celda en el sistema de manufactura. 
 * Representa una celda que tiene atributos como su fila, columna, estado, color, entre otros.
 * Hereda de la clase `Artefact` e implementa la interfaz `Thing`.
 */
public class Cell extends Artefact implements Thing {
    public char nextState;        // Siguiente estado de la celda (activa o inactiva)
    public Color color;           // Color de la celda
    public AManufacturing aManufactuing; // Referencia a la fábrica a la que pertenece la celda
    public int row, column;          // Fila y columna de la celda
    public boolean active;           // Estado actual de la celda (si está activa o no)

    /**
     * Constructor de la clase `Cell`. Crea una nueva celda en una posición dada dentro de un entorno de manufactura.
     * 
     * @param am       Objeto que describe el tipo de entorno de manufactura.
     * @param row      Fila donde se encuentra la celda.
     * @param column   Columna donde se encuentra la celda.
     * @param active   Estado inicial de la celda (true si está activa, false si no).
     */
    public Cell(AManufacturing am, int row, int column, boolean active) {
        aManufactuing = am;
        this.row = row;
        this.column = column;
        state = (active ? Artefact.ACTIVE : Artefact.INACTIVE); // Establece el estado inicial de la celda
        nextState = (active ? Artefact.ACTIVE : Artefact.INACTIVE); // Define el siguiente estado
        aManufactuing.setThing(row, column, (Thing) this);  // Asocia la celda al entorno de manufactura
        color = Color.black;  // Color inicial de la celda
    }

    /** Retorna la fila de la celda.
     * @return int
     */
    public int getRow() {
        return row;
    }

    /** Retorna la columna de la celda.
     * @return int
     */
    public int getColumn() {
        return column;
    }

    /** Retorna el color de la celda.
     * @return Color
     */
    public Color getColor() {
        return color;
    }

    /**
     * Decide el próximo estado de la celda en base al número de pasos.
     * Si el número de pasos es par, la celda estará activa; si es impar, estará inactiva.
     */
    public void decide() {
        nextState = (getSteps() % 2 == 0 ? Artefact.ACTIVE : Artefact.INACTIVE);
    }

    /**
     * Cambia el estado actual de la celda al siguiente estado calculado previamente.
     */
    public void change() {
        step();  // Incrementa el número de pasos
        state = nextState;  // Cambia el estado actual al siguiente estado
    }

    /**
     * Calcula la cantidad de vecinos activos alrededor de la celda.
     * 
     * @return int Cantidad de vecinos activos.
     */
    public int neighborsActive() {
        return aManufactuing.neighborsActive(row, column);
    }

    /**
     * Verifica si un vecino en una dirección dada (dr, dc) está vacío.
     * 
     * @param dr Desplazamiento en filas.
     * @param dc Desplazamiento en columnas.
     * @return boolean `true` si la celda vecina está vacía, `false` en caso contrario.
     */
    public boolean neighborIsEmpty(int dr, int dc) {
        return aManufactuing.isEmpty(row + dr, column + dc);
    }

    /**
     * Establece si la celda está activa o inactiva.
     * 
     * @param active `true` para activar la celda, `false` para desactivarla.
     */
    public void setActive(boolean active) {
        this.active = active;
    }

    /**
     * Establece una nueva fila para la celda.
     * 
     * @param row Nueva fila.
     */
    public void setRow(int row) {
        this.row = row;
    }

    /**
     * Establece una nueva columna para la celda.
     * 
     * @param column Nueva columna.
     */
    public void setColumn(int column) {
        this.column = column;
    }

    /**
     * Cambia el color de la celda.
     * 
     * @param color Nuevo color de la celda.
     */
    public void setColor(Color color) {
        this.color = color;
    }
}
