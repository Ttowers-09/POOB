package domain;

import java.awt.Color;

/**
 * Clase abstracta `Artefact` que representa un artefacto en el sistema de manufactura.
 * Contiene propiedades y métodos comunes para los artefactos, como el estado y el conteo de pasos.
 */
public abstract class Artefact {
    
    public final static char UNKNOWN = 'u'; // Estado desconocido
    public final static char ACTIVE = 'a'; // Estado activo
    public final static char INACTIVE = 'd'; // Estado inactivo
    public char state; // Estado actual del artefacto
    public int steps; // Contador de pasos realizados

    /**
     * Constructor que crea un nuevo artefacto con estado desconocido y pasos en cero.
     */
    public Artefact() {
        state = UNKNOWN; // Inicializa el estado como desconocido
        steps = 0; // Inicializa el contador de pasos en cero
    }

    /**
     * Método protegido que incrementa el contador de pasos en uno.
     * Este método es llamado internamente para contabilizar los pasos.
     */
    public void step() {
        steps++; // Incrementa el contador de pasos
    }    
    
    /**
     * Método que devuelve el número de pasos realizados por el artefacto.
     * 
     * @return int Número de pasos realizados
     */
    public final int getSteps() {
        return steps; // Retorna el contador de pasos
    }    

    /**
     * Método que verifica si el artefacto está activo.
     * 
     * @return boolean `true` si el estado es ACTIVO, `false` en caso contrario
     */
    public final boolean isActive() {
        return (state == Artefact.ACTIVE); // Retorna si el artefacto está activo
    }
}
