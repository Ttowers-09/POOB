package domain;

import java.util.*;

/**
 * Clase `AManufacturing` que representa una estructura de manufactura compuesta por celdas.
 * Esta clase gestiona una rejilla (lattice) de objetos de tipo `Thing`, 
 * permitiendo el manejo y la actualización de sus estados.
 */
public class AManufacturing {
    static private int SIZE = 50; // Tamaño de la rejilla (50x50)
    protected Thing[][] lattice; // Rejilla de objetos de tipo Thing

    /**
     * Constructor de la clase `AManufacturing`.
     * Inicializa la rejilla y llena cada posición con `null`.
     */
    public AManufacturing() {
        lattice = new Thing[SIZE][SIZE];
        for (int r = 0; r < SIZE; r++) {
            for (int c = 0; c < SIZE; c++) {
                lattice[r][c] = null; // Inicializa la rejilla vacía
            }
        }
        someThings(); // Método para inicializar algunas celdas
    }

    /**
     * Obtiene el tamaño de la rejilla.
     * 
     * @return El tamaño de la rejilla.
     */
    public int getSize() {
        return SIZE;
    }

    /**
     * Obtiene el objeto `Thing` en la posición especificada de la rejilla.
     * 
     * @param r Fila de la rejilla.
     * @param c Columna de la rejilla.
     * @return El objeto `Thing` en la posición (r, c).
     */
    public Thing getThing(int r, int c) {
        return lattice[r][c];
    }

    /**
     * Establece un objeto `Thing` en la posición especificada de la rejilla.
     * 
     * @param r Fila de la rejilla.
     * @param c Columna de la rejilla.
     * @param e El objeto `Thing` a establecer.
     */
    public void setThing(int r, int c, Thing e) {
        lattice[r][c] = e;
    }

    /**
     * Método para inicializar algunas celdas dentro de la rejilla.
     * Crea instancias de celdas en posiciones específicas.
     */
    public void someThings() {
        new Cell(this, 10, 10, true);
        new Cell(this, 15, 15, true);
        
        new Poison(this, 0, 0);
        new Poison(this, 0, 49);
        
        new TouristCell(this, 8, 5);
        
        new HorizontalKiller(this, 20, 5, true);
    }

    /**
     * Cuenta el número de celdas activas vecinas en las posiciones adyacentes a (r, c).
     * 
     * @param r Fila de la celda a verificar.
     * @param c Columna de la celda a verificar.
     * @return El número de celdas activas vecinas.
     */
    public int neighborsActive(int r, int c) {
        int num = 0;
        for (int dr = -1; dr < 2; dr++) {
            for (int dc = -1; dc < 2; dc++) {
                if ((dr != 0 || dc != 0) && inLatice(r + dr, c + dc) &&
                    (lattice[r + dr][c + dc] != null) && (lattice[r + dr][c + dc].isActive()))
                    num++;
            }
        }
        return (inLatice(r, c) ? num : 0);
    }

    /**
     * Verifica si una celda en la posición (r, c) está vacía.
     * 
     * @param r Fila de la celda a verificar.
     * @param c Columna de la celda a verificar.
     * @return `true` si la celda está vacía; `false` en caso contrario.
     */
    public boolean isEmpty(int r, int c) {
        return (inLatice(r, c) && lattice[r][c] == null);
    }

    /**
     * Verifica si las coordenadas (r, c) están dentro de los límites de la rejilla.
     * 
     * @param r Fila a verificar.
     * @param c Columna a verificar.
     * @return `true` si (r, c) está dentro de la rejilla; `false` en caso contrario.
     */
    protected boolean inLatice(int r, int c) {
        return ((0 <= r) && (r < SIZE) && (0 <= c) && (c < SIZE));
    }

    /**
     * Método `ticTac` que actualiza el estado de las celdas en la rejilla.
     * Llama al método `decide` de cada celda y maneja el movimiento de `HorizontalKiller`.
     */
    public void ticTac() {
        for (int r = 0; r < SIZE; r++) {
            for (int c = 0; c < SIZE; c++) {
                if (lattice[r][c] != null) {
                    lattice[r][c].decide(); // Se decide la acción de la celda
                    
                    if (lattice[r][c] instanceof TouristCell) {
                        TouristCell turista = (TouristCell) lattice[r][c];
                        turista.change();
                    } else if (lattice[r][c] instanceof Poison) {
                        Poison poisonCell = (Poison) lattice[r][c];
                        poisonCell.change(); 
                    } else {
                        lattice[r][c].change(); 
                    }

                    if (lattice[r][c] instanceof HorizontalKiller) {
                        HorizontalKiller hk = (HorizontalKiller) lattice[r][c];
                        hk.move(); // Mueve la celda HorizontalKiller
                    }
                }
            }
        }
    }
}
