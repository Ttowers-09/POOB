package domain;

import java.awt.Color;

/**
 * Clase `HorizontalKiller` que representa una célula que se mueve horizontalmente 
 * en el sistema de manufactura. Esta célula se activa y se mueve hacia la derecha 
 * hasta que alcanza el borde del área, revirtiendo su dirección cuando eso ocurre.
 */
public class HorizontalKiller extends Cell {
    private AManufacturing AManufacturing; // Referencia al objeto de manufactura
    private int direccion; // Dirección en la que se mueve (1 para derecha, -1 para izquierda)

    /**
     * Constructor para crear una nueva instancia de `HorizontalKiller`.
     * 
     * @param am Objeto de tipo `AManufacturing` que representa el sistema de manufactura
     * @param row Fila en la que se ubicará la célula
     * @param column Columna en la que se ubicará la célula
     * @param active Estado inicial de la célula (activa o inactiva)
     */
    public HorizontalKiller(AManufacturing am, int row, int column, boolean active) {
        super(am, row, column, active);
        this.color = Color.RED; // Color de la célula
        this.AManufacturing = am; // Inicializa la referencia al sistema de manufactura
        this.direccion = 1; // Inicialmente se mueve hacia la derecha
    }

    /**
     * Método que decide el próximo estado de la célula.
     * En este caso, se deja vacío para que la célula siempre esté activa.
     */
    @Override
    public void decide() {
        // Se deja vacío para que la célula siempre esté activa
    }

    /**
     * Método que mueve la célula en la dirección establecida.
     * Si la célula alcanza el borde, cambia su dirección.
     */
    public void move() {
        int newRow = this.row; // Fila actual
        int newColumn = this.column + direccion; // Columna a la que se moverá

        // Verifica si la nueva posición es válida
        if (isValidPosition(newRow, newColumn)) {
            AManufacturing.setThing(this.row, this.column, null); // Limpia la posición anterior
            this.row = newRow; // Actualiza la fila
            this.column = newColumn; // Actualiza la columna
            AManufacturing.setThing(newRow, newColumn, this); // Establece la nueva posición de la célula
        } else {
            // Cambia la dirección al llegar al borde
            direccion = -direccion; 
            newColumn = this.column + direccion; // Calcula la nueva columna

            // Verifica si la nueva posición es válida nuevamente
            if (isValidPosition(newRow, newColumn)) {
                AManufacturing.setThing(this.row, this.column, null); // Limpia la posición anterior
                this.row = newRow; // Actualiza la fila
                this.column = newColumn; // Actualiza la columna
                AManufacturing.setThing(newRow, newColumn, this); // Establece la nueva posición de la célula
            }
        }
    }

    /**
     * Método que verifica si una posición dada es válida dentro del área de manufactura.
     * 
     * @param row Fila de la posición a verificar
     * @param column Columna de la posición a verificar
     * @return boolean `true` si la posición es válida, `false` en caso contrario
     */
    private boolean isValidPosition(int row, int column) {
        int size = AManufacturing.getSize(); // Tamaño del área de manufactura
        return (row >= 0 && row < size && column >= 0 && column < size); // Verifica los límites
    }
}
