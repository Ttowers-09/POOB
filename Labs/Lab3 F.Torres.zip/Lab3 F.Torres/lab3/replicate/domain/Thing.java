package domain;

import java.awt.Color;

/**
 * Interfaz `Thing` que define las características básicas de un objeto dentro de un sistema.
 * Esta interfaz establece ciertos métodos y constantes que deben ser implementados por las clases que la utilicen.
 */
public interface Thing {
    public static final int ROUND = 1;  // Constante que representa una forma redonda
    public static final int SQUARE = 2; // Constante que representa una forma cuadrada

    /**
     * Método abstracto para tomar decisiones sobre el próximo estado del objeto.
     * Debe ser implementado por cualquier clase que implemente esta interfaz.
     */
    public abstract void decide();

    /**
     * Método predeterminado para cambiar el estado del objeto.
     * No es obligatorio que las clases que implementen la interfaz lo sobrescriban.
     */
    default void change() {
    }

    /**
     * Método predeterminado que devuelve la forma del objeto.
     * Por defecto, devuelve `SQUARE` (cuadrado).
     * @return int Representa la forma del objeto (1 para redondo, 2 para cuadrado).
     */
    default int shape() {
        return SQUARE;
    }

    /**
     * Método abstracto para obtener el color del objeto.
     * Debe ser implementado por cualquier clase que implemente esta interfaz.
     * 
     * @return Color Retorna el color actual del objeto.
     */
    Color getColor();

    /**
     * Método abstracto para establecer el color del objeto.
     * Debe ser implementado por cualquier clase que implemente esta interfaz.
     * 
     * @param color El nuevo color que se asignará al objeto.
     */
    void setColor(Color color);

    /**
     * Método predeterminado para verificar si el objeto está activo.
     * Por defecto, devuelve `false` (el objeto no está activo).
     * @return boolean `true` si el objeto está activo, `false` en caso contrario.
     */
    default boolean isActive() {
        return false;
    }
}
