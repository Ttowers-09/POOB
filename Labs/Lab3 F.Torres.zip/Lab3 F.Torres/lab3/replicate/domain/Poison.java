package domain;

import java.awt.Color;
import java.util.Random;

/**
 * Clase `Poison` que representa una celda envenenada en el sistema de manufactura.
 * Esta celda cambia de color cíclicamente entre varios colores cada vez que se activa.
 */
public class Poison extends Cell {
    public static final Color[] listaColores = {Color.red, Color.orange, Color.yellow, Color.green, Color.blue, Color.magenta, Color.cyan}; // Lista de colores para la célula
    public int colorIndex; // indice del color actual

    /**
     * Constructor de la clase `Poison`.
     * 
     * @param am El objeto de tipo AManufacturing que contiene esta celda.
     * @param row La fila donde se encuentra la celda.
     * @param column La columna donde se encuentra la celda.
     */
    public Poison(AManufacturing am, int row, int column) {
        super(am, row, column, true); // Inicializa la celda como activa
        
        Random random = new Random(); // Crea un objeto Random para generar números aleatorios
        colorIndex = random.nextInt(listaColores.length); // Selecciona un índice aleatorio para el color inicial
        color = listaColores[colorIndex]; // Asigna el color basado en el índice aleatorio
    }

    /**
     * Método que cambia el estado de la célula y actualiza su color.
     * Este método se llama cada vez que la celda se activa.
     */
    @Override
    public void change() {
        super.change(); // Llama al método change de la clase base (Cell)
        
        colorIndex = (colorIndex + 1) % listaColores.length; // Cambia al siguiente color de forma cíclica
        color = listaColores[colorIndex]; // Actualiza el color de la celda
    }
}
