package domain;

public class HalloweenShopException extends Exception
{
    //Este esta en los Test
    public final static String COMPLETE_EMPTY= "Este disfraz esta vacio";
    public final static String PRICE_ERROR = "El precio es negativo";
    public final static String PRICE_UNKNOWN = "No registra precio";
    
    /**
     * Constructor for objects of class CostumeException
     */
    public HalloweenShopException(String message)
    {
        super(message);
    }
}
