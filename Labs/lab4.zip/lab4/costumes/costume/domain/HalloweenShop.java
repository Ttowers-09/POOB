package domain; 

import java.util.ArrayList;
import java.util.TreeMap;
import domain.Log;

import javax.swing.JOptionPane;

/**
 * CostumeShop
 * @author POOB  
 * @version ECI 2024
 */

public class HalloweenShop{
    private ArrayList<Costume> costumes;
    private TreeMap<String,Basic> basics;

    /**
     * Create a HalloweenShop
     */
    public HalloweenShop(){
        costumes = new ArrayList<Costume>();
        basics = new TreeMap<String,Basic>();
        addSome();
    }
    
    public Basic getBasicName (String name){
        return basics.get(name.toUpperCase()); //el upperCase me estallo casi todos los test
    }
    
    //Como modificamos los metodos de add ahora aca marca un error, como adiconamos excepciones java recomienda hacer un bloqe try
    //catch
    private void addSome(){
        String [][] basics = {{"Camisa blanca","5000","10"},
                              {"Pantalon negro","10000","20"},
                              {"Capa negra","15000","0"}};
        
        try{
            for (String [] c: basics){
                addBasic(c[0],c[1],c[2]);
            }
            String [][] Complete = {{"Zorro", "2000","0","Camisa blanca\nPantalon negro\nCapa negra"}};
            for (String [] s: Complete){
                addComplete(s[0],s[1],s[2],s[3]);
            }  
        }catch(HalloweenShopException e){
            e.getMessage();
            Log.record(e);
            JOptionPane.showMessageDialog(null, e.getMessage(), "Error", JOptionPane.WARNING_MESSAGE);
        }
    }


    /**
     * Consult a costume
     * @param name
     * @return 
     */
    public Costume consult(String name){
        Costume c=null;
        for(int i=0;i<costumes.size() && c == null;i++){
            if (costumes.get(i).name().compareToIgnoreCase(name)==0) 
               c=costumes.get(i);
        }
        return c;
    }

    
    /**
     * Add a new basic costume
     * @param name 
     * @param price
     * @param discount
     * 
     * Este método fue modificado para la parte de robusto
    */
    public void addBasic(String name, String price, String discount)throws HalloweenShopException{
        try{
            int newPrice = Integer.parseInt(price);
            int newDiscount = Integer.parseInt(discount);
            if (basics.containsKey(name.toUpperCase())) {
                throw new HalloweenShopException(HalloweenShopException.ELEMENT_REPEAT);
            }
            
            if (newDiscount < 0 || newDiscount > 100){
                System.out.println(HalloweenShopException.DISCOUNT_OVER_LIMITS);
            } else{
                Basic nc = new Basic (name, newPrice, newDiscount);
                costumes.add(nc);
                basics.put(name.toUpperCase(),nc); 
            }
        }catch (NumberFormatException e){
            throw new HalloweenShopException(HalloweenShopException.INVALID_NUMERIC_DATA);
        }
    }
    
    /**
     * Add a new Complete costume
     * @param name 
     * @param makeUp
     * @param basics
    */
    public void addComplete(String name, String makeUp, String discount, String theBasics) throws HalloweenShopException{ 
        try{
            int newDiscount = Integer.parseInt(discount);
            int newMakeUp = Integer.parseInt(makeUp);
            if (newDiscount < 0 || newDiscount > 100){
                System.out.println(HalloweenShopException.DISCOUNT_OVER_LIMITS);
            } else{
                Complete c = new Complete (name, newMakeUp, newDiscount);
                String [] aBasics= theBasics.split("\n");
                for (String p : aBasics){
                    Basic element = getBasicName(p.trim());
                    if (element != null){
                        c.addBasic(element);
                    } else{
                        throw new HalloweenShopException(HalloweenShopException.UNKNOW_PIECE);
                    }
                }
                costumes.add(c);
            }
        }catch (NumberFormatException e){
            throw new HalloweenShopException(HalloweenShopException.INVALID_NUMERIC_DATA);
        }
    }

    /**
     * Consults the costumes that start with a prefix
     * @param  
     * @return 
     */
    public ArrayList<Costume> select(String prefix){
        ArrayList <Costume> answers=new ArrayList<Costume>();
        
        if(prefix != null){
            prefix=prefix.toUpperCase();
            for(int i=0;i<=costumes.size()-1;i++){
                if(costumes.get(i).name().toUpperCase().startsWith(prefix)){
                    answers.add(costumes.get(i));
                }   
            }
        }
        return answers;
    }


    
    /**
     * Consult selected costumes
     * @param selected
     * @return  
     */
    public String data(ArrayList<Costume> selected){
        StringBuffer answer=new StringBuffer();
        answer.append(costumes.size()+ " disfraces\n");
        for(Costume p : selected) {
            try{
                answer.append('>' + p.data());
                answer.append("\n");
            }catch(HalloweenShopException e){
                answer.append("**** "+e.getMessage());
            }
        }    
        return answer.toString();
    }
    
    
    /**
     * Return the data of costumes with a prefix
     * @param prefix
     * @return  
     */ 
    public String search(String prefix)throws HalloweenShopException{
        
        if(prefix == null){
            throw new HalloweenShopException(HalloweenShopException.PREFIX_NULL);
        }
        ArrayList<Costume> results = select(prefix);
        
        if(results.isEmpty()){
            throw new HalloweenShopException(HalloweenShopException.COSTUME_NOT_FOUND);
        }
        return data(results);
    }

    
    
    /**
     * Return the data of all costumes
     * @return  
     */    
    public String toString(){
        return data(costumes);
    }
    
    /**
     * Consult the number of costumes
     * @return 
     */
    public int numberCostumes(){
        return costumes.size();
    }
    
}
