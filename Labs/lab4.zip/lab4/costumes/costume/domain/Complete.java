package domain;  
 
import java.util.ArrayList;

public class Complete extends Costume{
   

    private int makeUp;
    private ArrayList<Basic> pieces;
    
    /**
     * Constructs a new complete custom
     * @param name 
     * @param makeUp
     * @param discount 
     */
    public Complete(String name, int makeUp, int discount){
        super(name,discount);
        this.makeUp=makeUp;
        pieces= new ArrayList<Basic>();
    }


     /**
     * Add a new basic piece
     * @param b
     */   
    public void addBasic(Basic b){
        pieces.add(b);
    }
       
 
    
    /**
     * Calcula el precio total del conjunto de piezas más el maquillaje,
     * aplicando un descuento si es necesario.
     * @return El precio total calculado después de aplicar el maquillaje y el descuento.
     * @throws HalloweenShopException Si la lista de piezas está vacía.
     */
    @Override
    public int price() throws HalloweenShopException {
        // Verifica si la lista de piezas está vacía y lanza una excepción en caso afirmativo
        if (pieces.isEmpty()) {
            throw new HalloweenShopException(HalloweenShopException.COMPLETE_EMPTY);
        }
        if (discount < 0 || discount > 100) {
            throw new HalloweenShopException(HalloweenShopException.DISCOUNT_OVER_LIMITS);
        }
        int totalPrice = 0;
        // Calcula el precio total sumando el precio de cada pieza
        for (Basic piece : pieces) {
            totalPrice += piece.price();
        }
        // Agrega el precio del maquillaje al total
        totalPrice += makeUp;
        // Aplica el descuento al precio total
        totalPrice = (totalPrice * (100 - discount)) / 100;
        // Asegura que el precio total no sea negativo, estableciéndolo en 0 si es menor a 0
        if (totalPrice < 0) {
            totalPrice = 0;
        }
        // Retorna el precio total calculado
        return totalPrice;
    }

    
    
    /**
     * Calcula un precio estimado para el conjunto de piezas, aplicando un valor
     * para piezas cuyo precio es desconocido o tiene un error.
     * 
     * @param unknown Valor que se asume para las piezas de precio desconocido.
     * @param error Valor que se asume para piezas con error en el precio.
     * @return El precio total estimado después de aplicar el maquillaje y el descuento.
     * @throws HalloweenShopException COMPLETE_EMPTY si no hay piezas en la lista.
     * @throws HalloweenShopException PRICE_ERROR si el valor de 'unknown' o 'error' es negativo.
     */
    public int price(int unknown, int error) throws HalloweenShopException {
        // Verifica si la lista de piezas está vacía y lanza una excepción en caso afirmativo
        if (pieces.isEmpty()) {
            throw new HalloweenShopException(HalloweenShopException.COMPLETE_EMPTY);
        }
        // Verifica que los valores de 'unknown' y 'error' sean válidos (no negativos)
        if (unknown < 0 || error < 0) {
            throw new HalloweenShopException(HalloweenShopException.PRICE_ERROR);
        }
        int totalPrice = 0;
        // Calcula el precio total, usando 'unknown' y 'error' cuando corresponda
        for (Basic piece : pieces) {
            totalPrice += calculatePiecePrice(piece, unknown, error);
        }
        // Agrega el precio del maquillaje al total
        totalPrice += makeUp;
        // Aplica el descuento al precio total
        totalPrice = (totalPrice * (100 - discount)) / 100;
        // Asegura que el precio total no sea negativo, estableciéndolo en 0 si es menor a 0
        if (totalPrice < 0) {
            totalPrice = 0;
        }
        // Retorna el precio total calculado
        return totalPrice;
    }

    
    private int calculatePiecePrice(Basic piece, int unknown, int error) throws HalloweenShopException {
        try {
            return piece.price();
        }catch (HalloweenShopException e) {
            if (e.getMessage().equals(HalloweenShopException.PRICE_UNKNOWN)) {
                return unknown;
            }else if (e.getMessage().equals(HalloweenShopException.PRICE_ERROR)) {
                return error;
            } else {
                throw e; 
            }
        }
    }

    
    
    /**
     * Calcula un precio estimado para el conjunto de piezas, utilizando el valor 
     * máximo o mínimo de las otras piezas cuando alguna tenga un precio desconocido.
     * 
     * @param maximum Indica si se debe usar el valor máximo (true) o mínimo (false) de las piezas conocidas.
     * @return El precio total estimado después de aplicar ajustes para piezas con precio desconocido.
     * @throws HalloweenShopException COMPLETE_EMPTY si no hay piezas en la lista.
     * @throws HalloweenShopException PRICE_ERROR si alguna pieza tiene un error en el precio.
     */
    public int price(boolean maximum) throws HalloweenShopException {
        // Verifica si la lista de piezas está vacía y lanza una excepción en caso afirmativo
        if (pieces.isEmpty()) {
            throw new HalloweenShopException(HalloweenShopException.COMPLETE_EMPTY);
        }
        int knownTotal = 0;       // Suma de precios conocidos de las piezas
        Integer minPrice = null;  // Precio mínimo encontrado entre las piezas
        Integer maxPrice = null;  // Precio máximo encontrado entre las piezas
        // Itera sobre cada pieza para calcular precios conocidos y detectar valores mínimos y máximos
        for (Basic piece : pieces) {
            try {
                int piecePrice = piece.price();
                knownTotal += piecePrice;
                // Actualiza el precio mínimo si es nulo o se encuentra uno menor
                if (minPrice == null || piecePrice < minPrice) {
                    minPrice = piecePrice;
                }
                // Actualiza el precio máximo si es nulo o se encuentra uno mayor
                if (maxPrice == null || piecePrice > maxPrice) {
                    maxPrice = piecePrice;
                }
    
            } catch (HalloweenShopException e) {
                // Lanza la excepción si hay un error en el precio de una pieza
                if (e.getMessage().equals(HalloweenShopException.PRICE_ERROR)) {
                    throw e;
                }
            }
        }
        // Determina el precio asumido según la opción de máximo o mínimo
        int assumedPrice = determineAssumedPrice(maximum, minPrice, maxPrice);
        // Calcula el ajuste en base al precio asumido para piezas desconocidas
        int adjustment = calculateAdjustmentForUnknownPrices(assumedPrice);
        // Retorna el precio final, ajustado según los precios conocidos y desconocidos
        return calculateFinalPrice(knownTotal, adjustment);
    }

    private int determineAssumedPrice(boolean maximum, Integer minPrice, Integer maxPrice) {
        int assumedPrice = 0;
        if (maximum) {
            if (maxPrice != null) {
                assumedPrice = maxPrice;
            }
        } else {
            if (minPrice != null) {
                assumedPrice = minPrice;
            }
        }
        return assumedPrice;
    }
    
    private int calculateAdjustmentForUnknownPrices(int assumedPrice) {
        int adjustment = 0;
        for (Basic piece : pieces) {
            try {
                piece.price();
            } catch (HalloweenShopException e) {
                if (e.getMessage().equals(HalloweenShopException.PRICE_UNKNOWN)) {
                    adjustment += assumedPrice;
                }
            }
        }
        return adjustment;
    }
    
    private int calculateFinalPrice(int knownTotal, int adjustment) {
        int totalPrice = knownTotal + adjustment + makeUp;
        totalPrice = (totalPrice * (100 - discount)) / 100;
        if (totalPrice < 0) {
            return 0;
        } else {
            return totalPrice;
        }
    }
    @Override
    public String data() throws HalloweenShopException{
        StringBuffer answer=new StringBuffer();
        answer.append(name+". Maquillaje "+ makeUp+". Descuento: "+ discount);
        for(Basic b: pieces) {
            answer.append("\n\t"+b.data());
        }
        return answer.toString();
    } 
    

}
