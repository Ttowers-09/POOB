package domain;

public class HalloweenShopException extends Exception
{
    //Este esta en los Test
    public final static String COMPLETE_EMPTY= "Este disfraz esta vacio";
    public final static String PRICE_ERROR = "El precio es negativo";
    public final static String PRICE_UNKNOWN = "No registra precio";
    
    // AGREGAMOS LAS EXCEPCIONES NECESARIAS PARA EL ROBUSTO
    public final static String DISCOUNT_OVER_LIMITS = "El descuento es menor a 0 o mayor a 100";
    public final static String INVALID_NUMERIC_DATA = "El precio o el descuento no son valores de tipo numericos";
    public final static String UNKNOW_PIECE = "el disfraz es nulo";
    public final static String ELEMENT_REPEAT = "El disfraz ya esta registrado";
    public final static String COSTUME_NOT_FOUND = "El disfraz no essta registrado";
    public final static String PREFIX_NULL = "El prefijo es null";
    /**
     * Constructor for objects of class CostumeException
     */
    public HalloweenShopException(String message)
    {
        super(message);
    }
}
