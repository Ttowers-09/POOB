package test;

import domain.HalloweenShop;
import domain.Basic;
import domain.Complete;
import domain.Costume;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;


public class ListarDomainTest
{
    public ListarDomainTest()
    {
    }

    @Test
    public void containsElementsTest() {
        HalloweenShop shop = new HalloweenShop();
        String result = shop.toString();
        assertTrue(result.contains("Zorro"));
    }

    @Test
    public void notContainsElementsTest() {
        HalloweenShop shop = new HalloweenShop();
        String result = shop.toString();
        assertFalse(result.contains("Captain"));
    }
    
    @Test
    public void elementNotContainsUnknownTest() {
        HalloweenShop shop = new HalloweenShop();
        String result = shop.toString();
        assertTrue(result.contains("Police"));
    }
}
