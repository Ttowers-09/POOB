package test;
import domain.Costume;
import domain.Basic;
import domain.HalloweenShop;
import domain.Complete;
import domain.HalloweenShopException;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class RobustoTest
{
    private HalloweenShop shop;

    @BeforeEach
    public void setUp() {
        shop = new HalloweenShop(); 
    }

    @Test
    public void existCostume() {
        try {
            shop.addBasic("Sombrero", "3000", "5");
            shop.addBasic("Sombrero", "3000", "5"); 
            fail("Se esperaba una excepción al agregar un disfraz con nombre repetido."); 
        } catch (HalloweenShopException e) {
            
        }
        assertEquals(5, shop.numberCostumes()); // Solo debería haber un disfraz
    }
    
    @Test
    public void invalidNumericValues(){
        Complete c = new Complete ("Police", 10, 0);
        try{
            shop.addBasic("Gun", "este precio es invalido", "0");
        }catch(HalloweenShopException e){
            
        }
        assertEquals(4, shop.numberCostumes());
    }
    @Test
    public void overNumber100 () throws domain.HalloweenShopException{
        Complete c = new Complete("Superhero", 1000, 200);
        c.addBasic(new Basic("Cape", 5000, 200));
        //Se le aolica el descuento a basic, el resultado se le suma al maquillaje y se hace el descuento desde ahi
        //Da como resultado 4000 pero tiene que dar como resultado 0
        assertEquals(4, shop.numberCostumes());
    }
    
    @Test
    public void newConditionForMe() throws HalloweenShopException{
        Complete c = new Complete("Disfraz con Nulo", 1000, 10);
        c.addBasic(null); // Intenta agregar una pieza nula
        assertEquals(4, shop.numberCostumes());
    }
    
    
}
