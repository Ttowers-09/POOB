package test;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import domain.Basic;
import domain.Complete;
import domain.HalloweenShopException;
/**
 * The test class PriceUknowTest.
 *
 * @author  (your name)
 * @version (a version number or a date)
 */
public class PriceunknownTest
{
    /**
     * Default constructor for test class PriceUknowTest
     */
    public PriceunknownTest()
    {
    }

    @Test
    public void testPriceunknown() {
        Complete c = new Complete("police", 1000, 0); //maquillaje
        
        c.addBasic(new Basic("gun", 5000, 0));
        c.addBasic(new Basic("Mask", null, 0));
        c.addBasic(new Basic("Suit", 10000, 0));
        try {
            assertEquals(18000, c.price(2000,0)); //Con la implementacion de este price le asignamos 2000 a null
        } catch (HalloweenShopException e) {
            System.out.println("No se esta asignando correctamente el valor");
        }
    }
    
    @Test
    public void testPriceError(){
        Complete c = new Complete ("Seguridad", 2000, 0);
        c.addBasic (new Basic("gun", -100,0));
        c.addBasic (new Basic("motorbike", -100,0));
        try{
            assertEquals(3000, c.price(10,500)); //Como el valor es negativo se le asigna el valor del error
        }catch(HalloweenShopException e){
            System.out.println("No se esta asignando correctamente el valor");
        }
    }
}
