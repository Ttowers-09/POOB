package test;
import domain.HalloweenShop;
import domain.HalloweenShopException;
import presentation.HalloweenShopGUI;

import domain.HalloweenShop;
import domain.HalloweenShopException;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class PatronesTest {

    @Test
    public void testNoExisteElemento() {
        HalloweenShop s = new HalloweenShop();
        try {
            s.search("B");
            fail("Se esperaba una excepción de tipo HalloweenShopException con mensaje COSTUME_NOT_FOUND");
        } catch (HalloweenShopException e) {
            assertEquals(HalloweenShopException.COSTUME_NOT_FOUND, e.getMessage(), "Excepción esperada con mensaje COSTUME_NOT_FOUND.");
        }
    }
    @Test
    public void testNoExistePrefijo() {
        HalloweenShop s = new HalloweenShop();
        try {
            s.search(" ");
            fail("Se esperaba una excepción de tipo HalloweenShopException con mensaje COSTUME_NOT_FOUND");
        } catch (HalloweenShopException e) {
            assertEquals(HalloweenShopException.COSTUME_NOT_FOUND, e.getMessage(), "Excepción esperada con mensaje COSTUME_NOT_FOUND.");
        }
    }
    @Test
    public void TestPrefijoNull() {
        HalloweenShop s = new HalloweenShop();
        try {
            s.search(null);
            fail("Se esperaba una excepción de tipo HalloweenShopException con mensaje PREFIX_NULL");
        } catch (HalloweenShopException e) {
            assertEquals(HalloweenShopException.PREFIX_NULL, e.getMessage(), "Excepción esperada con mensaje PREFIX_NULL.");
        }
    }
}
