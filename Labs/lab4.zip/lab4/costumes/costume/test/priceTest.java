package test;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import domain.Complete;
import domain.Basic;
import domain.HalloweenShopException;

/**
 * The test class priceTest.
 *
 * @author  (your name)
 * @version (a version number or a date)
 */
public class priceTest
{
    /**
     * Default constructor for test class priceTest
     */
    public priceTest()
    {
    }

    @Test
    public void testCalcularPrice() throws HalloweenShopException {
        Complete c = new Complete("Superhero", 1000, 0);
        c.addBasic(new Basic("Cape", 5000, 0));
        c.addBasic(new Basic("Mask", 2000, 0));
        c.addBasic(new Basic("Suit", 10000, 0));
        assertEquals(18000, c.price());
    }
    
    @Test
    public void testPriceSinPiezas() {
        Complete c = new Complete("Superhero", 1000, 0); //Maquillaje
        // aca no contiene piezas
        try {
            c.price();
        } catch (HalloweenShopException e) {
            System.out.println(HalloweenShopException.COMPLETE_EMPTY);
        }
    }
    
    @Test
    public void testPriceNegativo() {
        Complete c = new Complete("Superhero", -1000, 0);
        c.addBasic(new Basic("Cape", -5000, 0));
        c.addBasic(new Basic("Mask", -2000, 0));
        c.addBasic(new Basic("Suit", -10000, 0));
        try {
            assertEquals(0, c.price());
        } catch (HalloweenShopException e) {
            System.out.println(HalloweenShopException.PRICE_ERROR);
        }
    }
    
    @Test 
    public void testPriceNegativosAlgunos() throws HalloweenShopException{
        Complete c = new Complete ("Captitan", 200, 0);
        c.addBasic(new Basic ("sombrero", 100, 0));
        c.addBasic(new Basic ("piernera", -1000, 0));
        
        try{
            assertEquals(300, c.price());
        }catch (HalloweenShopException e) {
            System.out.println(HalloweenShopException.PRICE_ERROR);
        }
    }
}
