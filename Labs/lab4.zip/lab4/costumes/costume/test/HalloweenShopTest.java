package test; // Asegúrate de que este es el paquete correcto

import domain.HalloweenShop;
import domain.Basic;
import domain.Complete;
import domain.Costume;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;

public class HalloweenShopTest {
    private HalloweenShop shop;

    @BeforeEach
    public void setUp() {
        shop = new HalloweenShop(); 
    }

    // Prueba para el método addBasic
    @Test
    public void testAddBasic() {
        // Vamos a agregar sombrero
        shop.addBasic("Sombrero", "3000", "5");

        //como sabemos que hay 4 costumes iniciales si añadimo uno mas serian 5
        assertEquals(5, shop.numberCostumes());
        Costume basic = shop.consult("Sombrero");
        assertEquals ("Sombrero", basic.name());
    }
    
    @Test
    public void testNotAddBasic() {
        shop.addBasic("Peluca", "300", "0");
        assertEquals(4, shop.numberCostumes());
        Costume basic = shop.consult("Peluca");
        assertEquals("Peluca", basic.name());
    }
    @Test
    public void testAddBasicWithDiscount() {
        shop.addBasic("Máscara", "2000", "10");
        assertEquals(5, shop.numberCostumes(), "Debería haber 5 disfraces en la lista después de agregar uno.");
        Costume basic = shop.consult("Máscara");
        assertEquals("Máscara", basic.name());
    }
    @Test
    public void testAddMultipleBasics() {
        shop.addBasic("Sombrero", "3000", "5");
        shop.addBasic("Peluca", "300", "0");
        shop.addBasic("Máscara", "2000", "10");
        assertEquals(7, shop.numberCostumes(), "Debería haber 7 disfraces en la lista después de agregar tres.");
        Costume basic1 = shop.consult("Sombrero");
        Costume basic2 = shop.consult("Peluca");
        Costume basic3 = shop.consult("Máscara");
        assertEquals("Sombrero", basic1.name());
        assertEquals("Peluca", basic2.name());
        assertEquals("Máscara", basic3.name());
    }
    
    //ahora vamos con complete
    @Test
    public void testAddComplete() {
        // Llamar al método addComplete con valores de prueba
        shop.addComplete("Vampiro", "3000", "5", "Camisa blanca\nPantalon negro");
    
        // Verificar que el disfraz completo se ha agregado a la lista de costumes
        assertEquals(5, shop.numberCostumes(), "Debería haber 5 disfraces en la lista después de agregar uno.");
        Costume complete = shop.consult("Vampiro");
        assertEquals("Vampiro", complete.name());
    }
    @Test
    public void testNotAddComplete() {
        shop.addComplete("Fantasma", "1000", "0", "Capa negra");
        assertEquals(1, shop.numberCostumes());
        Costume complete = shop.consult("Fantasma");
        assertEquals("Fantasma", complete.name());
    }

}
